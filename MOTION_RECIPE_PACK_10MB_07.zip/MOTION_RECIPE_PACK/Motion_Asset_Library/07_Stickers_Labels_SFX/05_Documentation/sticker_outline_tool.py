#!/usr/bin/env python3
"""
sticker_outline_tool.py  -  Motion Asset Library, Step 7A (supplementary extra, not one of the 15 numbered assets)

Applies the Step 7A sticker-outline and glow styles to YOUR OWN transparent cutout so the outline hugs the real
silhouette (the numbered PNGs in this pack are generic rounded-square frames).

Needs: Python 3, numpy, opencv-python, Pillow.   pip install numpy opencv-python pillow

Examples
  python sticker_outline_tool.py cutout.png --style outline_white
  python sticker_outline_tool.py cutout.png --style all --out-dir out
  python sticker_outline_tool.py cutout.png --style glow_neon --layer-only      (effect only, no subject)
  python sticker_outline_tool.py small.png  --style outline_black --scale 0.5   (thinner line for a small cutout)

Styles: outline_white outline_black outline_doodle outline_double outline_colorful
        glow_soft glow_neon glow_amber glow_cool glow_rainbow
--scale multiplies line widths and glow sizes (1.0 is tuned for a subject about 1200 px across).
Output PNGs are RGBA with true alpha. The canvas is padded so nothing is clipped.
"""
import argparse
import os
import sys

import cv2
import numpy as np
from PIL import Image

# ----------------------------------------------------------------------------- geometry helpers

def sdf_from_mask(m, scale=1):
    """Signed distance in pixels: positive outside the shape, negative inside, 0 on the edge."""
    m = m.astype(np.uint8)
    d_out = cv2.distanceTransform(1 - m, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)
    d_in = cv2.distanceTransform(m, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)
    d = np.where(m == 1, -(d_in - 0.5), d_out - 0.5).astype(np.float32)
    return d / scale


def smooth_sdf(d, sigma=1.0):
    return cv2.GaussianBlur(d, (0, 0), sigma)


def fill_holes(mask):
    cnts, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    out = np.zeros(mask.shape, np.uint8)
    cv2.drawContours(out, cnts, -1, 1, thickness=cv2.FILLED)
    return out


def band(d, a, b):
    """Anti-aliased region a <= d <= b (a, b may be arrays)."""
    return np.clip(d - a + 0.5, 0, 1) * np.clip(b - d + 0.5, 0, 1)


def shift(arr, dx, dy):
    h, w = arr.shape[:2]
    M = np.float32([[1, 0, dx], [0, 1, dy]])
    return cv2.warpAffine(arr, M, (w, h), flags=cv2.INTER_LINEAR, borderValue=0)


def blur(a, s):
    return cv2.GaussianBlur(a, (0, 0), max(s, 0.3))


def noise(shape, sigma, seed):
    rng = np.random.default_rng(seed)
    n = rng.standard_normal(shape).astype(np.float32)
    n = cv2.GaussianBlur(n, (0, 0), max(sigma, 0.8))
    return n / (n.std() + 1e-6)


def gprof(d, s_out, s_in, peak):
    """Smooth gaussian glow centred on the edge: s_out outside the shape, s_in inside."""
    out = np.exp(-(np.clip(d, 0, None) / s_out) ** 2)
    inn = np.exp(-(np.clip(-d, 0, None) / s_in) ** 2)
    return (peak * np.where(d >= 0, out, inn)).astype(np.float32)


def hue_rgb(hue_deg, s, v):
    hsv = np.dstack([hue_deg.astype(np.float32),
                     np.full(hue_deg.shape, s, np.float32),
                     np.full(hue_deg.shape, v, np.float32)])
    return cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB) * 255.0


class Layers:
    """Premultiplied float compositor."""

    def __init__(self, shape):
        self.rgb = np.zeros((shape[0], shape[1], 3), np.float32)
        self.a = np.zeros(shape, np.float32)

    def over(self, color, alpha):
        c = np.asarray(color, np.float32)
        if c.ndim == 1:
            c = c[None, None, :]
        al = np.clip(alpha, 0, 1).astype(np.float32)
        self.rgb = c * al[..., None] + self.rgb * (1 - al[..., None])
        self.a = al + self.a * (1 - al)

    def scale_alpha(self, f):
        self.rgb *= f[..., None]
        self.a *= f

    def to_rgba(self):
        rgb = self.rgb / np.maximum(self.a[..., None], 1e-6)
        out = np.dstack([np.clip(rgb, 0, 255), np.clip(self.a * 255.0, 0, 255)])
        return np.rint(out).astype(np.uint8)


# ----------------------------------------------------------------------------- colours
WHITE = (255, 255, 255)
INK = (20, 20, 31)
BLACK = (14, 14, 20)
PINK = (255, 61, 127)
BLUE = (47, 91, 255)

# ----------------------------------------------------------------------------- outline styles (d = signed distance)

def st_outline_white(d, k, c):
    L = Layers(d.shape)
    ring = band(d, 0, 64 * k)
    sh = blur(shift(band(d, 0, 68 * k), 0, 10 * k), 16 * k) * 0.28 * np.clip(d + 0.5, 0, 1)
    L.over((0, 0, 0), sh)
    L.over(WHITE, ring)
    return L


def st_outline_black(d, k, c):
    L = Layers(d.shape)
    L.over(BLACK, band(d, 0, 84 * k))
    return L


def st_outline_doodle(d, k, c):
    """Hand-drawn marker: wobbling edge, uneven pen width, slightly rough edge, plus a thin sketch pass."""
    L = Layers(d.shape)
    d1 = d + 8 * k * noise(d.shape, 70 * k, 11) + 0.9 * k * noise(d.shape, 4 * k, 15)
    w = (44 + 9 * noise(d.shape, 90 * k, 12)) * k
    ring = band(d1, 0, w)
    d2 = d + 11 * k * noise(d.shape, 80 * k, 13) + 0.7 * k * noise(d.shape, 4 * k, 16)
    present = np.clip((noise(d.shape, 110 * k, 14) + 1.3) * 2.2, 0, 1)
    ring2 = band(d2, 70 * k, 79 * k) * present * 0.85
    L.over(INK, ring2)
    L.over(INK, ring)
    return L


def st_outline_double(d, k, c):
    L = Layers(d.shape)
    L.over(BLACK, band(d, 96 * k, 106 * k))
    L.over(WHITE, band(d, 62 * k, 96 * k))
    L.over(BLACK, band(d, 52 * k, 62 * k))
    L.over(WHITE, band(d, 0, 52 * k))
    return L


def st_outline_colorful(d, k, c):
    L = Layers(d.shape)
    hard = shift(band(d, 0, 58 * k), 26 * k, 26 * k) * np.clip(d + 0.5, 0, 1)
    L.over(BLUE, hard)
    L.over(PINK, band(d, 0, 58 * k))
    L.over(WHITE, band(d, 0, 9 * k))
    return L


# ----------------------------------------------------------------------------- glow styles

def st_glow_soft(d, k, c):
    L = Layers(d.shape)
    L.over(WHITE, gprof(d, 140 * k, 60 * k, 0.18))
    L.over((236, 232, 255), gprof(d, 70 * k, 36 * k, 0.60))
    return L


def st_glow_neon(d, k, c):
    L = Layers(d.shape)
    L.over((140, 60, 255), gprof(d, 130 * k, 90 * k, 0.40))
    L.over((255, 46, 196), gprof(d, 55 * k, 40 * k, 0.85))
    L.over((255, 46, 196), band(d, -17 * k, 17 * k))
    L.over((255, 228, 250), band(d, -6 * k, 6 * k))
    return L


def st_glow_amber(d, k, c):
    L = Layers(d.shape)
    L.over((255, 110, 20), gprof(d, 120 * k, 70 * k, 0.35))
    L.over((255, 176, 32), gprof(d, 62 * k, 45 * k, 0.80))
    L.over((255, 226, 150), band(d, -5 * k, 5 * k) * 0.95)
    return L


def st_glow_cool(d, k, c):
    L = Layers(d.shape)
    L.over((47, 91, 255), gprof(d, 130 * k, 80 * k, 0.45))
    L.over((61, 220, 255), gprof(d, 58 * k, 42 * k, 0.85))
    L.over((205, 248, 255), band(d, -5 * k, 5 * k) * 0.95)
    return L


def st_glow_rainbow(d, k, c):
    L = Layers(d.shape)
    h, w = d.shape
    yy, xx = np.indices((h, w), dtype=np.float32)
    ang = (np.degrees(np.arctan2(yy - c[1], xx - c[0])) + 180.0) % 360.0
    L.over(hue_rgb((ang + 70) % 360, 0.45, 1.0), gprof(d, 130 * k, 80 * k, 0.30))
    L.over(hue_rgb(ang, 0.60, 1.0), gprof(d, 62 * k, 45 * k, 0.80))
    L.over(hue_rgb(ang, 0.22, 1.0), band(d, -6 * k, 6 * k) * 0.95)
    return L


STYLES = {
    "outline_white": st_outline_white,
    "outline_black": st_outline_black,
    "outline_doodle": st_outline_doodle,
    "outline_double": st_outline_double,
    "outline_colorful": st_outline_colorful,
    "glow_soft": st_glow_soft,
    "glow_neon": st_glow_neon,
    "glow_amber": st_glow_amber,
    "glow_cool": st_glow_cool,
    "glow_rainbow": st_glow_rainbow,
}


# ----------------------------------------------------------------------------- applying to a real cutout

def apply_to_cutout(img, style, k=1.0, pad=None, layer_only=False, holes=True):
    img = img.convert("RGBA")
    pad = int(pad if pad is not None else 300 * k)
    arr = np.array(img)
    arr = np.pad(arr, ((pad, pad), (pad, pad), (0, 0)))
    alpha = arr[..., 3]
    mask = alpha >= 128
    if not mask.any():
        raise SystemExit("The image has no opaque pixels - is it a transparent cutout?")
    if holes:
        mask = fill_holes(mask).astype(bool)
    d = smooth_sdf(sdf_from_mask(mask))
    ys, xs = np.nonzero(mask)
    center = ((xs.min() + xs.max()) / 2.0, (ys.min() + ys.max()) / 2.0)
    layer = Image.fromarray(STYLES[style](d, k, center).to_rgba(), "RGBA")
    if layer_only:
        return layer
    layer.alpha_composite(Image.fromarray(arr, "RGBA"))
    return layer


def main():
    ap = argparse.ArgumentParser(description="Apply Step 7A outline/glow styles to a transparent cutout PNG.")
    ap.add_argument("input")
    ap.add_argument("--style", default="outline_white", help="a style name or 'all'")
    ap.add_argument("--scale", type=float, default=1.0)
    ap.add_argument("--out-dir", default=".")
    ap.add_argument("--layer-only", action="store_true")
    ap.add_argument("--keep-holes", action="store_true", help="outline holes inside the subject too")
    a = ap.parse_args()
    names = list(STYLES) if a.style == "all" else [a.style]
    for n in names:
        if n not in STYLES:
            sys.exit("Unknown style: %s" % n)
    img = Image.open(a.input)
    os.makedirs(a.out_dir, exist_ok=True)
    base = os.path.splitext(os.path.basename(a.input))[0]
    for n in names:
        out = apply_to_cutout(img, n, a.scale, layer_only=a.layer_only, holes=not a.keep_holes)
        p = os.path.join(a.out_dir, "%s_%s.png" % (base, n))
        out.save(p)
        print("saved", p, out.size)


if __name__ == "__main__":
    main()
