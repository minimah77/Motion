MOTION ASSET LIBRARY - PACK 07A: STICKER OUTLINES, GLOWING STICKERS & MINI LABELS
================================================================================

15 transparent PNG elements for Reels / TikTok edits, in 3 categories. Earlier packs are untouched.
This is Step 7A only; Step 7B has not been started.

IMPORTANT: WHAT THESE ARE
- All 15 numbered assets are STATIC PNGs. Animate them with your editor's keyframes (position, scale, rotation, opacity).
- The 10 sticker outlines and glows are GENERIC ROUNDED-SQUARE FRAMES with a transparent centre. They do not
  auto-fit your subject. Scale the frame until its inner opening matches your subject (see FITTING below), or
  use the included script to make an outline that hugs your real cutout.
- The 5 mini labels are BLANK on purpose. No words are baked in, so you add your own text as an editable text layer.
- Previews and their backgrounds are for browsing only; they are never part of the PNG files.

FOLDERS
01_Sticker_Outlines/   5   2048x2048, frame opening about 1200x1200 px, centred
02_Glowing_Stickers/   5   2048x2048, same opening, glow fades to zero well before the canvas edge
03_Mini_Labels/        5   2048x640
04_Previews/           MASTER_contact_sheet.png + one sheet per category (dark, light, and in-use rows)
05_Documentation/      this README, manifest_stickers_labels_07A.csv, QC_report.txt, sticker_outline_tool.py

STICKER OUTLINES (colour: use)
sticker_outline_white     white, with a soft contact shadow outside the line. Classic die-cut sticker edge.
sticker_outline_black     near-black (#0E0E14), bold. Good on bright or pastel footage.
sticker_outline_doodle    ink (#14141F) marker line with uneven width and a thin sketch line. Procedurally drawn.
sticker_outline_double    white band split by a black keyline, black outer line. Reads on most backgrounds.
sticker_outline_colorful  pink (#FF3D7F) ring with white keyline and a hard blue (#2F5BFF) offset shadow.

GLOWING STICKERS
sticker_glow_soft     white-lavender halo, subtle. Nearly invisible on light footage.
sticker_glow_neon     magenta tube with white-hot core, pink glow, violet halo.
sticker_glow_amber    amber (#FFB020) glow with a thin warm line.
sticker_glow_cool     cyan (#3DDCFF) glow with an electric-blue (#2F5BFF) halo.
sticker_glow_rainbow  iridescent pastel colours that shift around the shape.
The glow straddles the edge of the frame: part of it falls inside the opening, so place the glow BEHIND your
subject if you want the inner part hidden, or on top if you want the glow to wrap over the subject's edge.

MINI LABELS (suggested text colour)
label_pill_minimal     white pill. Dark text (#14141F).
label_tape_caption     cream washi tape, torn ends, slight tilt. Dark brown or ink text.
label_retro_digital    black camera plate with REC dot, battery icon, amber corner brackets. Amber text (#FF8A00),
                       monospace or digital-style font, e.g. a date.
label_technical        callout box with crosshair, leader line and ruler ticks. Small white monospace text.
                       White linework is weak on light footage.
label_handwritten      marker-drawn yellow highlight box, pink squiggle, blue sparkle. Dark handwriting-style text.

IMPORTING INTO CAPCUT (phone or desktop)
1. Put your video on the main track.
2. Overlay > Add overlay (desktop: drag onto a track above the video) and pick the PNG. Transparency is kept.
3. For labels: add a text layer above the label, centre it in the blank area, and group or keep the two together.
   Menu names differ slightly by app version; any editor that reads PNG alpha works the same way.
4. Pinch/drag to size. Keep the label's edge away from the screen edges and the app's caption/button zones
   on vertical video.
5. Optional: opacity, blend mode (Screen or Lighten suits glows on dark footage) and keyframes.

FITTING A FRAME TO A SUBJECT
Put your cutout on one track and the frame on the track above (outline) or below (glow). Scale the frame
uniformly until the empty opening is just larger than the subject. If the subject is not square, the
rounded square will not match it closely; use the script below for a close fit.

ANIMATION IDEAS (all with standard keyframes)
- Pop in: scale 70% to 105% to 100% over about 6 frames, with a quick fade in.
- Glow pulse: opacity 100% to 65% to 100% on a 0.8 to 1.2 second loop.
- Doodle outline: step the rotation by 1 to 2 degrees every 3 to 4 frames for a boiling-line look.
- Tape caption: slide in from the left while straightening a few degrees.
- Technical label: wipe in left to right, then fade the text in.
- Retro digital: flicker opacity for 3 frames when it appears.

HUGGING YOUR OWN CUTOUT: sticker_outline_tool.py (supplementary extra, not one of the 15)
Requires Python 3 and:  pip install numpy opencv-python pillow
    python sticker_outline_tool.py my_cutout.png --style outline_white
    python sticker_outline_tool.py my_cutout.png --style all --out-dir out
    python sticker_outline_tool.py my_cutout.png --style glow_neon --layer-only    (effect only, no subject)
    python sticker_outline_tool.py small.png --style outline_black --scale 0.5     (thinner for a small cutout)
Styles: outline_white outline_black outline_doodle outline_double outline_colorful
        glow_soft glow_neon glow_amber glow_cool glow_rainbow
Input must be a PNG with transparency. Holes inside the subject (for example lenses) are filled by the outline colour
like sticker backing; add --keep-holes to outline them instead. Output is padded so nothing is clipped.
It was tested on one stand-in cutout; results on very thin or very detailed silhouettes are not guaranteed.

FILE FORMAT
PNG, RGBA, true alpha. Transparent wherever there is no graphic. Glows keep smooth alpha falloff and reach zero
before the canvas edge. See QC_report.txt for the checks that were actually run and what was not tested.
