MOTION ASSET LIBRARY - PACK 07B: SOUND-EFFECT LETTERING & IMPACT GRAPHICS
================================================================================

10 transparent PNG sound-effect graphics for Reels / TikTok edits. Packs 01-07A are untouched.
This is Step 7B only; nothing after it has been started.

IMPORTANT: WHAT THESE ARE
- All 10 assets are STATIC PNGs (RGBA, true alpha). Animate them with your editor's keyframes (scale, rotation, position, opacity).
- Unlike the blank mini labels in 07A, the WORD IS PART OF THE ARTWORK. It cannot be edited or changed to another word.
- Each file is one finished composition (lettering + burst / shape + accents), tightly cropped with 100 px of transparent padding on every side.
- Every graphic has a dark ink outline plus a white outer keyline so it stays readable on both light and dark footage.
- Preview backgrounds (dark / light) are for browsing only; they are never part of the PNG files.

FOLDERS (added by this batch; nothing existing was changed)
04_Sound_Effect_Lettering/   10 PNGs, 1665-2170 px wide (tight crops, sizes differ per file)
04_Previews/                 preview_sound_effect_lettering_07B.png (contact sheet, half dark / half light tiles)
                             preview_sfx_mobile_size_test_07B.png (1080x1920 frame, assets at about 500 px wide)
05_Documentation/            README_07B.txt, manifest_sound_effect_lettering_07B.csv, QC_report_07B.txt
Note: the folder number 04 is shared by 04_Sound_Effect_Lettering and the existing 04_Previews, because the request named
04_Sound_Effect_Lettering. The names differ, so nothing collides. The 07A README/QC/manifest files were not edited.

THE 10 ASSETS (look: use)
sfx_boom     orange/yellow jagged explosion burst with halftone, red 3D lettering. Explosions, big reveals, hard cuts.
sfx_pop      compact scalloped pink burst, white lettering with blue hard shadow, confetti dashes. Small reveals, light beats.
sfx_pow      blue ray burst with cyan halftone, yellow lettering with red extrusion. Punches, impacts, transitions.
sfx_wow      glossy violet-to-pink lettering with a bouncing, larger middle O, sparkles and emphasis dashes. Reactions, reveals.
sfx_ouch     irregular jagged yellow splat shape, red lettering with pink and cyan vibration ghosts. Fails, bumps, cringe beats.
sfx_bang     red asymmetric burst with a long flare spike, white condensed lettering, retro halftone print look. Loud hits, slams.
sfx_zap      yellow italic lettering with cyan outline, blue lightning bolts and jagged arcs, soft cyan glow. Power-ups, shocks, tech.
sfx_click    blue UI button with window dots, white lettering, mouse cursor, click ripples. App demos, tutorials, button presses.
sfx_whoosh   italic white lettering, horizontal speed lines and long curved sweep streaks. Swipes, slides, scene transitions.
sfx_yeah     four differently coloured bouncing letters (pink, amber, cyan, violet), sparkles, dashes, squiggle. Wins, celebrations.

Palette follows the earlier packs: ink #14141F, pink #FF3D7F, blue #2F5BFF, amber #FFB020, cyan #3DDCFF, plus warm red/orange/yellow
for the comic bursts and violet for WOW and YEAH.

IMPORTING INTO CAPCUT (phone or desktop)
1. Put your video on the main track.
2. Overlay > Add overlay (desktop: drag onto a track above the video) and pick the PNG. Transparency is kept.
3. Pinch/drag to size. Keep the graphic away from the screen edges and the app's caption/button zones on vertical video.
4. Optional: keyframes, opacity, or a sound effect from your editor's audio library timed to the pop-in.
Menu names differ slightly by app version; any editor that reads PNG alpha works the same way.

ANIMATION IDEAS (all with standard keyframes)
- Impact pop (boom, pow, bang, ouch): scale 40% to 115% to 100% over about 6 frames, 3-4 frame rotation shake, hold 0.4 to 0.8 s, fade or scale out.
- Pop / wow / yeah: bouncy scale 70% to 110% to 100%, then a slow 2-3% scale pulse while it holds.
- Zap: flicker opacity for 3 frames on entry, then hold.
- Click: scale down to 92% and back (button press) when the cursor lands.
- Whoosh: slide in from the left with a fast ease-out, slide out to the right.

KNOWN LIMITS
- sfx_zap has a soft cyan glow (partial alpha). On light footage the glow is faint; the ink and white outlines still carry the word.
- Lettering is rendered from system fonts and procedural shapes; no font is needed to use the PNGs.
- Tested in an image viewer only, not in a video editor. See QC_report_07B.txt.

FILE FORMAT
PNG, RGBA, true alpha. Fully transparent (alpha 0) around the artwork, partial alpha only on anti-aliased edges and the ZAP glow.
