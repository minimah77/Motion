# Motion Asset Library - Step 6B: Target Graphics & HUD Overlays

Ten transparent PNG overlays for vertical video (Reels, TikTok, Shorts): five target graphics and five futuristic HUDs, all 1080x1920 RGBA. The five targets also come as tight standalone crops. Place a layer on top of your clip, blend mode Normal. Everything that is not drawn is genuinely transparent (real alpha, no checkerboard), and each asset keeps a clear zone for your subject.

## Folder layout

```
Motion_Asset_Library/06_Frames_HUD_Targets/
  03_Target_Graphics/   target_simple_crosshair.png, target_lock_on.png, target_corner_brackets.png,
                        target_radar_scan.png, target_tracking_box.png
    standalone/         <same five names>_standalone.png  (tight crops, centred on the target)
  04_HUDs/              hud_minimal_tech.png, hud_data_panels.png, hud_circular_interface.png,
                        hud_technical_grid.png, hud_sci_fi_overlay.png
  contact_sheet_6B.png, manifest_6B.csv, QC_report_6B.md, README_6B.md
```

Unzip into the folder that holds your existing Motion_Asset_Library. This batch only adds new files and replaces nothing; Step 6A (01_Film_Frames, 02_Viewfinders and its documents) is untouched.

## Assets

| file | what it is | clear area |
|---|---|---|
| target_simple_crosshair.png | Four-arm crosshair with an open centre gap, tick graduations on every arm, four broken outer arcs and red arm tips | disc r=40 px at (540,960) |
| target_lock_on.png | Broken outer ring, thin guide ring, three-segment inner ring, 10-degree tick ring, four inward pointers, LOCKED / TGT-01 98.4% / AZ 042 / EL 008 readouts | disc r=100 px at (540,960) |
| target_corner_brackets.png | 600x760 px frame: heavy corner brackets, inner thin brackets, midpoint ticks and dashed side lines; interior fully open | 512x672 px rect at (284,624) |
| target_radar_scan.png | Circular radar: 3 range rings with 100/200/300 M labels, cross and diagonal lines, bearing ticks and 000/090/180/270 labels, a fading sweep wedge with bright leading edge, three blips with labels | disc r=70 px at (540,960) |
| target_tracking_box.png | 480x640 px box: thin border, heavy corner accents, 16 px measurement rulers on all four sides, TRK 01 tag, W 480 / H 640 / CONF 96% / TRACKING readouts | 400x560 px rect at (340,680) |
| hud_minimal_tech.png | Four chamfered corner brackets with fine inner hairlines, top hairline with centre notch, bottom tick ruler, edge tick groups and tiny SYS.01 / SIG / LAT / LON labels | 840x1260 px rect at (120,330) |
| hud_data_panels.png | Six small panels (SYSTEM bars, SIGNAL sparkline, LOAD bars, PWR gauge, TELEMETRY, STATUS chips) joined by hairline connectors, arranged around an empty centre | 620x1220 px rect at (230,380) |
| hud_circular_interface.png | Five concentric layers (hairline ring with 3-degree ticks, thick arc segments, dashed ring, segmented inner ring, thin guide ring), magenta accents, N/S pointers, SCAN 74% and SYNC LOCKED labels | disc r=340 px at (540,960) |
| hud_technical_grid.png | 60 px minor and 120 px major grid that fades to nothing toward the centre, framed by pixel rulers with numbers, registration crosses, 780 PX and 1320 safe-area dimension lines, scale and size labels | 780x1320 px rect at (150,300) |
| hud_sci_fi_overlay.png | Chamfered double-line corner frames with glow, SECTOR 07 - ACTIVE top tab with slanted segment bars, left segment strip with pointer, right data ticks, ENERGY 84% bottom tab with segment meter and coordinate readout | 740x1240 px rect at (170,360) |

## Standalone target crops

The five targets are also supplied as tight crops in 03_Target_Graphics/standalone/. Each crop is centred exactly on the target, so scaling or rotating the layer around its own centre keeps it locked to the point you place it on. They are pixel-identical to the full-frame files.

| file | size |
|---|---|
| target_simple_crosshair_standalone.png | 496x498 px |
| target_lock_on_standalone.png | 834x726 px |
| target_corner_brackets_standalone.png | 650x812 px |
| target_radar_scan_standalone.png | 874x850 px |
| target_tracking_box_standalone.png | 846x870 px |

## Using them

- Targets: drop the standalone crop onto the track above your clip, move it onto the subject and scale it around its centre. The full-frame versions are the same artwork centred on the 1080x1920 canvas, for use when the subject is already in the middle.
- HUDs: set the project to 1080x1920 and place the PNG at 100% scale; do not stretch it. Each HUD leaves a large clear zone (see the table) for the subject and captions.
- Quick fade-ins look best (6 to 10 frames). The radar sweep, REC-style blinks and the numbers in the readouts are baked into the pixels; if you want them animated, duplicate the layer and mask or fade parts of it.
- Reels and TikTok cover the bottom and right edge with their own interface. The HUD footers (data panels, technical grid, minimal tech, sci-fi) sit at about y=1660 to 1860; nudge the layer up if a footer gets covered.
- Text is legible but small by HUD convention (16 to 26 px at 1080 wide); keep the layers at 100% on phones.

## Notes

- All colours and text are baked in. No fonts are needed to use the files.
- Every graphic has a thin dark outline and soft shadow built into its edge pixels so it stays readable on bright footage; that is why a few semi-transparent pixels surround each line.
- No brand names or logos are used. Existing packs were not touched.
- See QC_report_6B.md for the measured checks and limitations, and manifest_6B.csv for per-asset data.
