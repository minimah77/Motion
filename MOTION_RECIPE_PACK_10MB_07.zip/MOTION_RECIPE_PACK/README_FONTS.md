# FONTS (Persian + Latin)

Folder `fonts/<Family>/` holds static TTFs (+ OFL.txt where supplied). `fonts.css` has ready @font-face rules (family names = keys in `fonts.json`). `fonts.json` lists weights and measured coverage. `specimen.png` shows each family with a Persian line and a Latin line.

| Family | Weights | Notes |
|---|---|---|
| Vazirmatn | 100-900 | Persian + Latin, complete |
| IBM Plex Sans Arabic | 100-700 | Persian + Latin; no ZWNJ glyph |
| Markazi Text | 400-700 | Persian + Latin (serif style); no ZWNJ glyph |
| Playpen Sans Arabic | 100-800 | Persian + Latin (handwritten style) |
| Lalezar | 400 | Persian + Latin (display); no ZWNJ glyph |
| Parastoo | 400-700 | Persian + Latin |
| Lora | 400-700, with italics | **Latin only (English serif).** No Persian |
| Nanum Myeongjo | 400, 700, 800 | **Latin only (serif, Korean font).** No Persian |
| SF Arabic | 100-900 | **Persian only. No Latin letters or digits.** Pair it with another family for Latin: `font-family: "SF Arabic", "Vazirmatn", sans-serif;` |

## Checked (measured)
The 7 Persian families have every Persian letter (including پ چ ژ گ ک ی), Persian digits ۰-۹ and « » ، ؟ ؛, and Arabic joining features. In the Pillow/Raqm specimen, joined letters and the half-space in «می‌خواهم» render correctly, even in the 3 families with no ZWNJ glyph.

Lora and Nanum Myeongjo are for English words only. Use a Persian family for Persian text and one of these for the English accent word, e.g. `font-family: "Lora", serif`.

## Not checked
Rendering inside Remotion/Chromium. Check the first video's Persian text by eye. Use the real ZWNJ character (U+200C) in the script, not a space.
Omitted on purpose: variable fonts, web formats (.eot/.woff), and `Ios_15_Medium.ttf` (byte-identical to SFArabic-Medium.ttf). The Markazi Text and Playpen Sans Arabic files in your latest zip were identical to the ones already packed.
`SFArabic- Bold.ttf` was renamed `SFArabic-Bold.ttf` (the space breaks CSS paths). SF Arabic is Apple's font, not OFL.
