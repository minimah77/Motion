# Glass FX — Revision 01

Motion-design compositing assets: real optical distortion, heavy-blur colour fields, refracted-light overlays.
No cards, bubbles, UI containers, shadows or checkerboards. Built from scratch (not a recolour of the earlier set).

NOTE: the earlier "preview glass filters 08" image and its asset files were not present in the workspace this was built in,
so nothing was overwritten or compared against. This folder is self-contained; keep your originals wherever they live.

## Contents
| Folder | What | Format |
|---|---|---|
| `svg_filters/` | 5 filters, each as a runnable demo SVG + PNG render + before/after; `glass_filters_library.svg` = bare filters to drop in | SVG, PNG 1080×1920 |
| `displacement_maps/` | The exact noise map each filter uses, for After Effects / Resolve / Premiere / Nuke | PNG 1080×1920 (+SVG) |
| `gradient_meshes/` | 4 full-canvas blurred colour fields | PNG 1080×1920 + editable SVG |
| `caustics/` | 5 refracted-light overlays | RGBA PNG 1080×1920, **real alpha**, white light |
| `review/contact_sheet.png` | Review sheet on dark neutral (background is NOT in any asset) | PNG |
| `tests/` | Measurements + backdrop-filter test pages/renders | JSON, HTML, PNG |
| `src/` | Generators (Python + headless Chromium). Re-run to regenerate | py |

## The 5 SVG filters (all tested on a dense grid/ring/type/colour-bar pattern)
| # | id | Effect | Key parameters |
|---|---|---|---|
| 01 | `gf-wavy-optical` | Long optical swells + chromatic dispersion (3 displacement passes, R/G/B differ) | scale 74/62/50 · noise 0.0016×0.0062 |
| 02 | `gf-liquid-refraction` | Smooth liquid warp + diffuse shading + broad specular sheen | scale 96 · noise 0.0042 · surfaceScale 40 |
| 03 | `gf-heat-wave` | Mostly-horizontal shimmer + faint horizontal smear | scale 30 · noise 0.0035×0.028 |
| 04 | `gf-organic-refractive` | Cell/crease refraction (cracked-ice / uneven pane) + sparse glints | scale 44 + 12 · crease noise 0.0062 |
| 05 | `gf-frosted-scatter` | Micro-scatter + two-scale blur (σ3 core / σ13 halo) + milky lift + grain | scatter 34 · blur 60/40 mix |

Tune strength via `feDisplacementMap@scale` (px), blur via `stdDeviation`. Displacement = `scale × (map − 0.5)`.
Noise maps are contrast-stretched and re-centred to 0.5 (measured) so there is no net image drift.

## Gradient meshes
01 Nebula Bloom (additive, `plus-lighter`) · 02 Abyss Light (depth column + light shafts) · 03 Ember Flow (turbulence-warped ribbons)
· 04 Pearl Oil-Slick (pastel base + thin-film colour bands). Blur σ 62–150, plus a faint grain overlay to prevent banding.
The **PNG is the reference render**. The SVGs use `mix-blend-mode` and SVG filters, which Illustrator/Figma/Affinity import
inconsistently — open them in a browser/Inkscape-with-filters, or edit then re-render with `src/common.py:render`.

## Caustics
Not drawn: simulated. A uniform grid of photons is refracted through a random height field and splatted where it lands, so
brightness comes from real ray convergence (fold lines, cusps). 01 network (mid scale) · 02 ripples (fine interference) ·
03 soft flow (directional, blurred; a low-alpha veil, only ~1% fully clear) · 04 glass fold edges (large luminous folds) ·
05 rainbow (R/G/B refracted with ±7% strength = dispersion, restrained to edges).
Files are white RGB + straight (non-premultiplied) alpha. Tint with a Color/Fill effect; use **Screen / Add / Overlay**.
Use as-is for 01–04; for 05 do not tint (it carries colour).

## HOW TO USE THE SVG FILTERS — and the real limits
SVG filters process **their own rendered content** and do not exist in most video apps.

Supported pipelines
1. **Browser / Chromium (tested):** `filter="url(#id)"` or CSS `filter:url(#id)` on `<img>`, `<video>`, `<canvas>`, text, SVG groups.
   Include `glass_filters_library.svg` inline in the page (the `<defs>` must be in the same document).
2. **Chromium `backdrop-filter:url(#id)` (tested):** distorts whatever is *behind* an element, including `<video>`. Chromium-only.
3. **Offline render:** play footage in headless Chromium (Playwright/Puppeteer/Remotion), apply the filter, capture frames.
4. **After Effects / Premiere / Resolve / FCP:** SVG filters are NOT imported. Use the `displacement_maps/*.png` as the map layer
   in Displacement Map (AE) / Displace (Fusion/Nuke): 128-grey = no shift; max displacement ≈ `scale / 2` px (verify by eye);
   chromatic version = one displacement per channel with strengths 74/62/50 (÷2). Frost = Gaussian Blur 3 + 13 mix, +7% lift, grain.
   Lighting highlights in 02/04 have no direct equivalent; approximate with Bevel/Emboss or a lit height-map.

Known limitations (observed, not theoretical)
- `feDisplacementMap` uses nearest-pixel sampling → thin 1-px lines can alias/jag under strong warp. Filters 02/04 pre-blur 0.5 px to hide this.
- Filter region is fixed at x/y −200, 1480×2320 for a 1080×1920 canvas; **input needs ≥200 px overscan** or edges pull transparent/blank pixels. If you change canvas size, change `x y width height` on every `<filter>`.
- `color-interpolation-filters="sRGB"` is required; linearRGB (default) shifts the 0.5 neutral and the image drifts.
- Results are resolution-dependent (user-space px units). At 4K scale `scale`, `stdDeviation`, `baseFrequency` accordingly.
- Safari/Firefox render these filters with small differences; only Chromium 153 was verified here. `backdrop-filter:url()` is Chromium-only.
- Large blurs/lighting on big regions are CPU-heavy in browsers; not real-time at 4K.
- 8-bit pipeline: smooth lighting from blurred 8-bit height can show faint stair-stepping.
- Gradient SVGs: blend modes/filters may not survive import into design tools (see above).
- Caustic PNGs are stills; they tile only approximately. Slide/scale/rotate slowly (or crossfade 2) for motion; not a seamless loop.

## Test report (see `tests/`)
Rendered and visually inspected in Chromium 153 (Playwright), 1080×1920:
| Test | Result |
|---|---|
| 5 filters distort test pattern (grid-line shift, mean) | 01: 10 px · 02: 24 px · 03: 6 px · 04: 11 px · 05: scatter 8 px + blur — PASS (`tests/filter_measurements.json`) |
| 5 filters via `backdrop-filter:url()` over an image | PASS — only the band changes, 0.0 diff outside (`tests/backdrop_filter_results.json`) |
| Gradient meshes render, no outline/border/shadow | PASS (visual) |
| Caustics RGBA, alpha 0–255, white RGB, no baked background | PASS (≈52–60% fully transparent; 03 is a soft veil) |
| Contact sheet inspected; reads as effects not UI | PASS after revising: filters 01–04 and caustics 02/04 were reworked once because first versions were too chaotic / lattice-like / tangled |

NOT tested: Safari, Firefox, After Effects/Premiere/Resolve (map PNGs are provided but the AE parameter mapping is unverified),
`<video>` input (image backdrop was used), animation (filters are static; animate `seed`/`baseFrequency` via SMIL/JS for motion).
