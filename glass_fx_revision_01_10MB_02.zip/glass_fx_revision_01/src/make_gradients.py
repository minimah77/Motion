"""Four full-canvas gradient-mesh backgrounds, 1080x1920, heavy gaussian blur.
Each is structurally different (not one template re-coloured)."""
import os
from common import *

OUT = os.path.join(ROOT, "gradient_meshes")
BIG = 'filterUnits="userSpaceOnUse" x="-900" y="-900" width="2880" height="3720" color-interpolation-filters="sRGB"'
GRAIN = '''<filter id="grain" filterUnits="userSpaceOnUse" x="0" y="0" width="1080" height="1920" color-interpolation-filters="sRGB">
  <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed="5" result="g"/>
  <feColorMatrix in="g" type="matrix" values="0.33 0.33 0.33 0 0  0.33 0.33 0.33 0 0  0.33 0.33 0.33 0 0  0 0 0 0 1"/>
</filter>'''
GRAIN_USE = '<rect width="1080" height="1920" filter="url(#grain)" style="mix-blend-mode:overlay" opacity="0.10"/>'


def blob(cx, cy, rx, ry, rot, color, op=1.0, blend="screen", stop=0.0):
    gid = f"b{abs(hash((cx, cy, color))) % 10**7}"
    g = (f'<radialGradient id="{gid}"><stop offset="{stop}" stop-color="{color}" stop-opacity="{op}"/>'
         f'<stop offset=".55" stop-color="{color}" stop-opacity="{op*0.55:.2f}"/>'
         f'<stop offset="1" stop-color="{color}" stop-opacity="0"/></radialGradient>')
    e = (f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" transform="rotate({rot} {cx} {cy})" '
         f'fill="url(#{gid})" style="mix-blend-mode:{blend}"/>')
    return g, e


def compose(name, base_rect, layers, defs_extra="", post=""):
    defs, body = [defs_extra], []
    for kind, payload in layers:
        if kind == "raw":
            body.append(payload)
        else:
            d, e = payload
            defs.append(d); body.append(e)
    svg = svg_wrap(f'''<g filter="url(#soft)" style="isolation:isolate">
{base_rect}
{chr(10).join(body)}
</g>
{post}
{GRAIN_USE}''', defs="\n".join(defs) + GRAIN)
    return svg


def save(name, svg):
    p = os.path.join(OUT, name + ".svg")
    open(p, "w").write(svg)
    return (p, os.path.join(OUT, name + ".png"))


jobs = []

# ------------------------------------------------------------------ 01 Nebula Bloom
# Dark violet field; large overlapping additive colour clouds; two blur radii for depth.
f1 = f'<filter id="soft" {BIG}><feGaussianBlur stdDeviation="150"/></filter>'
layers = [
    ("blob", blob(240, 360, 640, 440, -28, "#ff1f8e", 1.0, "plus-lighter")),
    ("blob", blob(890, 740, 580, 380, 32, "#00c8ff", 1.0, "plus-lighter")),
    ("blob", blob(500, 1170, 740, 480, -12, "#6a2cff", 1.0, "plus-lighter")),
    ("blob", blob(860, 1540, 520, 360, 20, "#ffae2a", 1.0, "plus-lighter")),
    ("blob", blob(110, 1690, 540, 360, -34, "#00e0a8", 0.95, "plus-lighter")),
    ("blob", blob(520, 700, 320, 240, 40, "#ff6a3d", 0.75, "plus-lighter")),
    ("blob", blob(560, 130, 660, 320, 6, "#2b1aff", 0.9, "plus-lighter")),
    ("blob", blob(620, 1500, 300, 200, -25, "#ff3bd0", 0.7, "plus-lighter")),
]
svg = compose("01", '<rect x="-900" y="-900" width="2880" height="3720" fill="#06031a"/>', layers, f1,
              post='<rect width="1080" height="1920" fill="url(#vig1)"/>')
svg = svg.replace("<defs>", '<defs><radialGradient id="vig1" cx="540" cy="900" r="1250" gradientUnits="userSpaceOnUse"><stop offset=".45" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#02000d" stop-opacity=".30"/></radialGradient>', 1)
jobs.append(save("01_nebula_bloom", svg))

# ------------------------------------------------------------------ 02 Abyss Light
# Deep water-column gradient: dark top -> luminous base, with tilted light shafts (not round blobs).
f2 = f'<filter id="soft" {BIG}><feGaussianBlur stdDeviation="105"/></filter>'
col = '''<linearGradient id="col" gradientUnits="userSpaceOnUse" x1="0" y1="-200" x2="0" y2="2100">
<stop offset="0" stop-color="#010a1c"/><stop offset=".38" stop-color="#042a52"/><stop offset=".72" stop-color="#067a8f"/><stop offset="1" stop-color="#2fe0c4"/></linearGradient>'''
shafts = []
for cx, cy, rx, ry, rot, c, op in [
    (330, 640, 170, 1100, 14, "#3fe8ff", 0.95),
    (640, 520, 130, 1000, 9, "#8affd8", 0.8),
    (860, 900, 210, 1150, 17, "#1aa7ff", 0.95),
    (120, 1000, 170, 950, 11, "#00c2b8", 0.8),
]:
    shafts.append(("blob", blob(cx, cy, rx, ry, rot, c, op, "screen")))
layers = [("raw", f'<defs>{col}</defs><rect x="-900" y="-900" width="2880" height="3720" fill="url(#col)"/>')]
layers += shafts
layers += [
    ("blob", blob(540, 1820, 820, 360, 0, "#c8ffe9", 0.95, "screen")),
    ("blob", blob(300, 1700, 420, 240, -10, "#00ffd0", 0.8, "screen")),
    ("blob", blob(960, 150, 560, 380, 25, "#3a1fa8", 0.8, "normal")),
    ("blob", blob(120, 160, 420, 300, -20, "#0b2a8a", 0.7, "normal")),
]
svg = compose("02", "", layers, f2)
jobs.append(save("02_abyss_light", svg))

# ------------------------------------------------------------------ 03 Ember Flow
# Flowing S-curve ribbons, warped by turbulence, then blurred: organic field with direction.
f3 = f'''<filter id="soft" {BIG}>
  <feTurbulence type="fractalNoise" baseFrequency="0.0013 0.0019" numOctaves="2" seed="13" result="n"/>
  <feColorMatrix in="n" type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 0 1" result="m"/>
  <feDisplacementMap in="SourceGraphic" in2="m" scale="560" xChannelSelector="R" yChannelSelector="G" result="w"/>
  <feGaussianBlur in="w" stdDeviation="62"/>
</filter>'''
def ribbon(d, color, w, op=1.0, blend="screen"):
    return ("raw", f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{w}" stroke-linecap="round" opacity="{op}" style="mix-blend-mode:{blend}"/>')
layers = [
    ribbon("M-300 300 C 300 -100, 700 700, 1400 380", "#ff2d7a", 420, 0.95),
    ribbon("M-300 780 C 200 380, 800 1200, 1400 760", "#ff3d2e", 360, 1.0),
    ribbon("M-300 1180 C 300 800, 700 1600, 1400 1200", "#ff9a1f", 340, 0.95),
    ribbon("M-300 1560 C 250 1250, 760 1900, 1400 1560", "#ffd36b", 300, 0.9),
    ribbon("M-300 1900 C 300 1640, 800 2200, 1400 1940", "#3a1bff", 380, 0.95),
    ribbon("M-300 60 C 250 380, 800 -200, 1400 120", "#5a1fd8", 300, 0.85),
    ribbon("M-300 1000 C 300 640, 800 1400, 1400 980", "#fff1c9", 90, 0.5, "soft-light"),
]
svg = compose("03", '<rect x="-900" y="-900" width="2880" height="3720" fill="#16041f"/>', layers, f3)
jobs.append(save("03_ember_flow", svg))

# ------------------------------------------------------------------ 04 Pearl Oil-Slick
# High-key pearlescent base; soft pastel clouds + thin-film iridescent bands interacting through blend modes.
f4 = f'<filter id="soft" {BIG}><feGaussianBlur stdDeviation="120"/></filter>'
f4b = f'''<filter id="film" {BIG}>
  <feTurbulence type="fractalNoise" baseFrequency="0.0016 0.0026" numOctaves="2" seed="29" result="n"/>
  <feColorMatrix in="n" type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 0 1" result="m"/>
  <feDisplacementMap in="SourceGraphic" in2="m" scale="520" xChannelSelector="R" yChannelSelector="G" result="w"/>
  <feGaussianBlur in="w" stdDeviation="42"/>
</filter>'''
layers = [
    ("blob", blob(220, 330, 560, 420, -20, "#a98bff", 1.0, "normal")),
    ("blob", blob(860, 520, 520, 380, 25, "#5fecc4", 1.0, "normal")),
    ("blob", blob(300, 1050, 640, 430, 15, "#ff6fc0", 1.0, "normal")),
    ("blob", blob(860, 1300, 560, 400, -25, "#4fb0ff", 1.0, "normal")),
    ("blob", blob(540, 1750, 760, 380, 0, "#ffd36e", 1.0, "normal")),
    ("blob", blob(120, 1560, 420, 300, 30, "#5b4bff", 0.55, "multiply")),
    ("blob", blob(950, 130, 420, 300, 20, "#4a3ad0", 0.45, "multiply")),
]
film = []
for d, c, w, op in [
    ("M-300 520 C 250 220, 700 900, 1400 560", "#ff3ec8", 120, 0.55),
    ("M-300 640 C 250 340, 700 1020, 1400 680", "#ffd23d", 90, 0.5),
    ("M-300 760 C 250 460, 700 1140, 1400 800", "#22e6ff", 120, 0.55),
    ("M-300 1380 C 300 1100, 700 1700, 1400 1320", "#7a3dff", 110, 0.5),
    ("M-300 1500 C 300 1220, 700 1820, 1400 1440", "#ff7ad9", 80, 0.5),
    ("M-300 1620 C 300 1340, 700 1940, 1400 1560", "#3dffd2", 110, 0.5),
]:
    film.append(f'<path d="{d}" fill="none" stroke="{c}" stroke-width="{w}" stroke-linecap="round" opacity="{op}"/>')
layers.append(("raw", f'<g filter="url(#film)" opacity=".85">{"".join(film)}</g>'))
layers.append(("raw", f'<g filter="url(#film)" style="mix-blend-mode:overlay" opacity=".9">{"".join(film)}</g>'))
svg = compose("04", '<rect x="-900" y="-900" width="2880" height="3720" fill="#f1ebfb"/>', layers, f4 + f4b)
jobs.append(save("04_pearl_oil_slick", svg))

if __name__ == "__main__":
    render_many(jobs)
    print("rendered", [os.path.basename(j[1]) for j in jobs])
