"""Shared helpers: test pattern SVG, headless-Chromium renderer."""
import os
from playwright.sync_api import sync_playwright

W, H = 1080, 1920
OVER = 220  # overscan so displacement never pulls in empty edges
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def test_pattern_group(gid="testpattern"):
    """A dense test image: photographic-style gradient scene + grid, rings,
    outlined type, small text, colour bars, checker. Drawn with overscan."""
    o = OVER
    parts = []
    parts.append(f'''<g id="{gid}">
<defs>
  <linearGradient id="tp-sky" gradientUnits="userSpaceOnUse" x1="0" y1="-{o}" x2="0" y2="1320">
    <stop offset="0" stop-color="#070d2b"/><stop offset=".30" stop-color="#2c1a66"/>
    <stop offset=".52" stop-color="#a02a78"/><stop offset=".72" stop-color="#f2653f"/>
    <stop offset=".90" stop-color="#ffb764"/><stop offset="1" stop-color="#ffe2a0"/>
  </linearGradient>
  <radialGradient id="tp-sun" gradientUnits="userSpaceOnUse" cx="540" cy="1290" r="520">
    <stop offset="0" stop-color="#fff6d8" stop-opacity="1"/><stop offset=".25" stop-color="#ffd27a" stop-opacity=".7"/>
    <stop offset="1" stop-color="#ff7a3a" stop-opacity="0"/>
  </radialGradient>
  <linearGradient id="tp-sea" gradientUnits="userSpaceOnUse" x1="0" y1="1320" x2="0" y2="{H+o}">
    <stop offset="0" stop-color="#1b4f6e"/><stop offset=".5" stop-color="#0b2a4a"/><stop offset="1" stop-color="#05101f"/>
  </linearGradient>
</defs>
<rect x="-{o}" y="-{o}" width="{W+2*o}" height="{1320+o}" fill="url(#tp-sky)"/>
<rect x="-{o}" y="700" width="{W+2*o}" height="700" fill="url(#tp-sun)"/>
<circle cx="540" cy="1290" r="150" fill="#fff3cf"/>
<path d="M-{o} 1320 L-60 1190 L90 1262 L240 1120 L380 1250 L470 1210 L600 1300 L760 1150 L900 1260 L1010 1170 L{W+o} 1250 L{W+o} 1330 L-{o} 1330 Z" fill="#150b2c"/>
<path d="M-{o} 1330 L120 1262 L300 1310 L520 1252 L700 1318 L930 1262 L{W+o} 1316 L{W+o} 1340 L-{o} 1340 Z" fill="#0d0720"/>
<rect x="-{o}" y="1320" width="{W+2*o}" height="{H+o-1320}" fill="url(#tp-sea)"/>
''')
    # sun reflection streaks on the sea
    for i in range(26):
        y = 1345 + i * 22
        w = 300 - i * 9
        if w > 8:
            parts.append(f'<rect x="{540 - w/2}" y="{y}" width="{w}" height="6" fill="#ffd9a0" opacity="{0.75 - i*0.025:.3f}"/>')
    # fine + coarse grid
    for x in range(-o - (-o % 30), W + o, 30):
        major = (x % 90 == 0)
        parts.append(f'<line x1="{x}" y1="-{o}" x2="{x}" y2="{H+o}" stroke="#fff" stroke-width="{2.4 if major else 1}" opacity="{.62 if major else .22}"/>')
    for y in range(-o - (-o % 30), H + o, 30):
        major = (y % 90 == 0)
        parts.append(f'<line x1="-{o}" y1="{y}" x2="{W+o}" y2="{y}" stroke="#fff" stroke-width="{2.4 if major else 1}" opacity="{.62 if major else .22}"/>')
    # concentric rings
    for r in range(70, 500, 70):
        parts.append(f'<circle cx="540" cy="900" r="{r}" fill="none" stroke="#ffffff" stroke-width="4" opacity=".92"/>')
    parts.append('<circle cx="540" cy="900" r="10" fill="#fff"/>')
    # diagonals
    for k in range(-6, 8):
        parts.append(f'<line x1="{k*180-200}" y1="260" x2="{k*180+520}" y2="1460" stroke="#7fe9ff" stroke-width="2" opacity=".35"/>')
    # big outlined type + titles
    parts.append('<text x="540" y="470" text-anchor="middle" font-family="Arial, Helvetica, \'DejaVu Sans\', sans-serif" font-weight="700" font-size="196" textLength="960" lengthAdjust="spacingAndGlyphs" fill="none" stroke="#fff" stroke-width="5">REFRACT</text>')
    parts.append('<text x="60" y="118" font-family="Arial, Helvetica, \'DejaVu Sans\', sans-serif" font-weight="700" font-size="54" fill="#fff">OPTICAL DISTORTION TEST</text>')
    parts.append('<text x="60" y="168" font-family="\'DejaVu Sans Mono\', monospace" font-size="26" fill="#bfe9ff">grid · rings · type · colour bars · checker</text>')
    parts.append('<text x="60" y="1590" font-family="Arial, Helvetica, \'DejaVu Sans\', sans-serif" font-weight="700" font-size="40" fill="#fff">The quick brown fox jumps over the lazy dog</text>')
    parts.append('<text x="60" y="1636" font-family="Arial, Helvetica, \'DejaVu Sans\', sans-serif" font-size="26" fill="#e8f6ff">0123456789 — small type shows blur &amp; scatter vs. warp</text>')
    # colour bars
    cols = ["#ffffff", "#ffe600", "#00e5ff", "#17d442", "#ff2bd6", "#ff2b2b", "#2b4bff", "#000000"]
    bw = W / len(cols)
    for i, c in enumerate(cols):
        parts.append(f'<rect x="{i*bw}" y="1680" width="{bw+0.5}" height="130" fill="{c}"/>')
    # checker strip
    s = 45
    for r in range(2):
        for c in range(W // s + 1):
            if (r + c) % 2 == 0:
                parts.append(f'<rect x="{c*s}" y="{1820 + r*s}" width="{s}" height="{s}" fill="#fff"/>')
            else:
                parts.append(f'<rect x="{c*s}" y="{1820 + r*s}" width="{s}" height="{s}" fill="#111"/>')
    parts.append(f'<rect x="-{o}" y="1910" width="{W+2*o}" height="{o+10}" fill="#111"/>')
    parts.append('</g>')
    return "\n".join(parts)


def svg_wrap(body, defs="", w=W, h=H, bg=None):
    bgrect = f'<rect width="{w}" height="{h}" fill="{bg}"/>' if bg else ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" '
            f'width="{w}" height="{h}" viewBox="0 0 {w} {h}">\n<defs>{defs}</defs>\n{bgrect}\n{body}\n</svg>')


def render(svg_path, png_path, w=W, h=H, transparent=False):
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": w, "height": h}, device_scale_factor=1)
        pg.goto("file://" + os.path.abspath(svg_path))
        pg.wait_for_timeout(300)
        pg.screenshot(path=png_path, omit_background=transparent, full_page=False)
        b.close()


def render_many(jobs, w=W, h=H, transparent=False):
    """jobs: list of (svg_path, png_path)."""
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": w, "height": h}, device_scale_factor=1)
        for svg_path, png_path in jobs:
            pg.goto("file://" + os.path.abspath(svg_path))
            pg.wait_for_timeout(300)
            pg.screenshot(path=png_path, omit_background=transparent, full_page=False)
        b.close()
