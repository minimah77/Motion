import os
from PIL import Image, ImageDraw, ImageFont, ImageChops
from common import ROOT
TW, TH, GAP, M = 440, 782, 24, 60
BG = (22, 22, 25)
def font(sz, bold=False):
    for p in (["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"] if bold else []) + ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]:
        if os.path.exists(p): return ImageFont.truetype(p, sz)
    return ImageFont.load_default()
def load(p): return Image.open(os.path.join(ROOT, p))
def thumb(im): return im.convert("RGB").resize((TW, TH), Image.LANCZOS)
def over_dark(p):
    im = load(p).convert("RGBA"); bg = Image.new("RGBA", im.size, BG + (255,)); bg.alpha_composite(im); return thumb(bg)
def screen_over(bgp, fgp):
    b = load(bgp).convert("RGBA"); f = load(fgp).convert("RGBA")
    # tint caustic light slightly toward the bg's brightest hue is left to the user; here: plain white via 'screen'
    fr = Image.new("RGBA", f.size, (255,255,255,0)); fr.putalpha(f.getchannel("A"))
    out = ImageChops.screen(b.convert("RGB"), Image.merge("RGB", [f.getchannel("A")]*3))
    return thumb(out)

rows = [
 ("A · SVG FILTERS — same test pattern, five different optical effects (rendered in Chromium 153)",
  [("original test pattern", thumb(load("svg_filters/00_test_pattern_reference.png"))),
   ("01 wavy optical + chromatic split", thumb(load("svg_filters/01_wavy_optical.png"))),
   ("02 liquid refraction", thumb(load("svg_filters/02_liquid_refraction.png"))),
   ("03 heat-wave shimmer", thumb(load("svg_filters/03_heat_wave.png"))),
   ("04 organic refractive surface", thumb(load("svg_filters/04_organic_refractive.png"))),
   ("05 frosted glass scatter", thumb(load("svg_filters/05_frosted_scatter.png")))]),
 ("B · GRADIENT MESH + HEAVY GAUSSIAN BLUR — 1080×1920",
  [("01 nebula bloom", thumb(load("gradient_meshes/01_nebula_bloom.png"))),
   ("02 abyss light", thumb(load("gradient_meshes/02_abyss_light.png"))),
   ("03 ember flow", thumb(load("gradient_meshes/03_ember_flow.png"))),
   ("04 pearl oil-slick", thumb(load("gradient_meshes/04_pearl_oil_slick.png")))]),
 ("C · CAUSTICS — white light, real alpha (shown over this sheet's dark background only)",
  [(n, over_dark(f"caustics/{f}.png")) for n, f in [("01 underwater network","01_underwater_network"),("02 sharp ripples","02_sharp_ripples"),("03 soft flow","03_soft_flow"),("04 glass fold edges","04_glass_fold_edges"),("05 restrained rainbow refraction","05_rainbow_refraction")]]),
 ("D · IN CONTEXT — caustics layered (screen) over the gradient meshes",
  [("network over abyss", screen_over("gradient_meshes/02_abyss_light.png","caustics/01_underwater_network.png")),
   ("ripples over nebula", screen_over("gradient_meshes/01_nebula_bloom.png","caustics/02_sharp_ripples.png")),
   ("soft flow over ember", screen_over("gradient_meshes/03_ember_flow.png","caustics/03_soft_flow.png")),
   ("fold edges over pearl", screen_over("gradient_meshes/04_pearl_oil_slick.png","caustics/04_glass_fold_edges.png")),
   ("rainbow over abyss", screen_over("gradient_meshes/02_abyss_light.png","caustics/05_rainbow_refraction.png"))]),
]
cols = 6
W = M*2 + cols*TW + (cols-1)*GAP
rowh = 56 + TH + 28 + 36
Hh = 150 + len(rows)*rowh + 40
sheet = Image.new("RGB", (W, Hh), BG); d = ImageDraw.Draw(sheet)
d.text((M, 44), "GLASS FX — REVISION 01 · REVIEW CONTACT SHEET", font=font(40, True), fill=(235,235,240))
d.text((M, 100), "Dark background belongs to this sheet only. Asset files contain no background.", font=font(20), fill=(150,150,160))
y = 150
for title, items in rows:
    d.text((M, y), title, font=font(24, True), fill=(210,210,220)); y += 56
    for i, (lab, im) in enumerate(items):
        x = M + i*(TW+GAP); sheet.paste(im, (x, y)); d.text((x, y+TH+8), lab, font=font(20), fill=(185,185,195))
    y += TH + 28 + 36
os.makedirs(os.path.join(ROOT, "review"), exist_ok=True)
sheet.save(os.path.join(ROOT, "review", "contact_sheet.png"))
sheet.resize((W//2, Hh//2), Image.LANCZOS).save("/tmp/claude-0/-home-claude/330b1623-8a25-5e80-b8dc-3b81177f4808/scratchpad/sheet_small.png")
print(sheet.size)
