import os, json, re
import numpy as np
from PIL import Image
from playwright.sync_api import sync_playwright
from common import ROOT
S = os.path.join(ROOT, "svg_filters")
lib = open(os.path.join(S, "glass_filters_library.svg")).read()
ids = re.findall(r'<filter id="([^"]+)"', lib)
ref = np.asarray(Image.open(os.path.join(S, "00_test_pattern_reference.png")).convert("RGB")).astype(float)
res = {}
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width":1080,"height":1920})
    for fid in ids:
        html = f'''<html><body style="margin:0;background:#000">{lib}
<div style="position:absolute;inset:0;background:url(file://{S}/00_test_pattern_reference.svg) no-repeat"></div>
<div style="position:absolute;left:0;top:600px;width:1080px;height:700px;backdrop-filter:url(#{fid})"></div></body></html>'''
        hp = os.path.join(ROOT, "tests", f"backdrop_{fid}.html"); open(hp, "w").write(html)
        pg.goto("file://" + hp); pg.wait_for_timeout(500)
        out = os.path.join(ROOT, "tests", f"backdrop_{fid}.png"); pg.screenshot(path=out)
        a = np.asarray(Image.open(out).convert("RGB")).astype(float)
        inside = np.abs(a[700:1200] - ref[700:1200]).mean(); outside = np.abs(a[:500] - ref[:500]).mean()
        res[fid] = dict(diff_inside_band=round(inside,2), diff_outside_band=round(outside,2), works=bool(inside > 5 and outside < 1))
        print(fid, res[fid])
    b.close()
json.dump(res, open(os.path.join(ROOT, "tests", "backdrop_filter_results.json"), "w"), indent=2)
