MOTION ASSET LIBRARY - PACK 01: DOODLES, ICONS & SYMBOLS
=========================================================

Built step by step. This archive is cumulative: each step adds to it.

COMPLETED SO FAR
- Doodle Arrows: 36 distinct designs
- 3D Icons: 28 distinct designs
- Scribbles: 42 distinct designs
Total individual PNG files: 742  (106 master designs + colour variants)

FOLDER STRUCTURE
01_Doodle_Arrows/       Master arrows, each in its primary colour
02_Scribbles/           Master scribbles, squiggles, hatching, highlights, doodle clusters
03_3D_Icons/            Master 3D glossy icons (lit heightfield renders with soft shadows)
04_Symbols/             (later step)
05_Color_Variants/      Every design recoloured: white, black, chrome, electric_blue,
                        violet, pink, yellow (sub-folders per family and colour)
06_Preview_Sheets/      Contact sheets. MASTER_contact_sheet.png shows every design.
                        Sheet backgrounds are for browsing only - never part of assets.
07_Manifest_and_Instructions/   manifest.csv / manifest.json, this README, source code

FILE FORMAT
All assets: PNG, 1024 x 1024 px, RGBA with real alpha transparency. Artwork is centred
with about 10% padding on every side so nothing is clipped. No backgrounds, labels
or watermarks are baked in.

NAMING
<family>_<design>_<colour>_<NN>.png   e.g. arrow_curved_s_white_06.png
NN is the design number. The same NN in a different colour is the same design recoloured.

IMPORTING INTO CAPCUT (phone or desktop)
1. Create your project and add your footage to the main track.
2. Tap/click Overlay (mobile: Overlay > Add overlay) or Media > Import, then pick the PNG.
   Desktop: drag the PNG onto a track above your video.
3. PNG transparency is kept automatically. Pinch or drag the corners to resize and move.
4. Animate it: Animations > In (Wipe, Zoom, Pop) works well for arrows; or add keyframes
   for scale and position. For a hand-drawn "draw-on" feel, use Wipe on a short duration.
5. Tip: white and yellow assets vanish on bright footage. Swap to the black or
   electric_blue version from 05_Color_Variants/ rather than recolouring in the editor.
Other editors: Premiere, DaVinci Resolve, Final Cut, VN, InShot and Canva all read
PNG alpha - place the file on a track above the video.

ANIMATION
This pack contains static PNGs only. Nothing here is a pre-animated GIF or WebM.
Animate them with your editor's keyframes and in/out animations.
