---
name: glass-prompt-video
description: Recreate the dark-glass "type a prompt, result image morphs full-screen" promo video for any topic using the kit's engine (template/index.html + config.js), assets, fonts and original-synthesis SFX. Use when the user sends the glass-prompt-video-kit zip and gives a topic.
---
Follow START_HERE_HANDOFF.md in the kit root. Edit only template/config.js. Preview before rendering; render only when the user says so. Use only kit assets. Draw an original brand mark.
