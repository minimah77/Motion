# glass-prompt-video-kit
One zip to send to Claude. Tell Claude: "Read START_HERE_HANDOFF.md and recreate the video for this topic: …".
Edit only `template/config.js` per topic. See START_HERE_HANDOFF.md.
