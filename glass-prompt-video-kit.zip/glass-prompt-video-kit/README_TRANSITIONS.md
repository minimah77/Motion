# Transition recipe (glass prompt video, 1920x1080, 30 fps)

Layer stack (bottom → top): bg navy gradient · grid (fades) · blue horizon glow · liquid blob (opening D) · ring · UI layer (planet arc, brand title, search capsule) · result photo card · glass tagline pill · blue wash · white flash · cursor · film grain (overlay, 6%).

## Openings (config `opening`, 0–2.4 s)
- A planet-rim: mark blur-in, arc rises, brand letters type, glow grows, title shrinks to .55 and capsule rises.
- B capsule-rise: capsule rises first, then brand letters, title drops in.
- C grid-boot: grid circle-reveals, mark + letters, grid dims, capsule scales in.
- D liquid-bloom: displaced blue blob rises and drains, then title and capsule.
- E cursor-first: cursor flies in, taps, ring ripples, arc, letters, capsule.
- F whip-in: A but the whole UI slides in from the right with motion blur.

## Fixed transitions after the opening (times relative, computed in index.html)
- T1 type: prompt typed at `cps` from 2.4 s; newest `hot_chars` letters glow in accent colour; send icon pops after 3 chars.
- T2 whip-pan: UI slides left by (send_x − 960) in 0.6 s with speed-based blur; cursor flies in from bottom-right and lands on the send button.
- T3 click → morph: click scale-down + ripple ring; send button grows into a 380px rounded photo card (0.4 s), gentle float/rotate.
- T4 scale-through: card scales to full-screen (0.5 s), glass tagline pill appears centered and types the tagline.
- T5 flash: photo blurs + brightens to white (0.6 s).
- T6 drain: blue wash drains downward revealing the dark end-card (brand mark + title at full size, 1.25 s).

## Change the look
Accent colour = `accent`. Speed = `cps`. Opening = `opening`. Everything else lives in `index.html` CSS (pill size/blur, tag size, etc.).

## Rebuild fonts.css after adding fonts
Put `Family-Weight.ttf` (Regular/Medium/SemiBold/Bold/Black) in `fonts/`, add the family key to the `fam` dict, run the generator (see git history of this kit, or ask Claude to rebuild: one @font-face per TTF).
