1 check_assets ok · 2 brief filled · 3 config.js written · 4 result image in assets/original · 5 preview frames approved · 6 render only on user "render" · 7 sfx.wav + final.mp4 presented.
