# Prompts for the result image (paste into ChatGPT image / any generator)
Base: "Cinematic 16:9 photograph, 1920x1080, <SUBJECT>, soft blue-teal colour grade, calm premium mood, shallow depth, no text, no logos, no people's faces unless asked."
Examples: calm lake at dawn with forest reflection · neon city street at night · minimal product on glass pedestal · futuristic workspace with floating UI panels.
Rules: no text inside the image; keep subject centred (it is scaled from a 380px card to full-screen); blue tones match the glow.
