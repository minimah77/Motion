# START HERE — Glass Prompt Video Kit (handoff for Claude)

You are given this one zip. Goal: recreate the reference video (`reference/reference_video.mp4`) — a dark-glass "type a prompt → result image" promo — but with a NEW topic the user will give you in chat (title/brand word, prompt text, tagline, result image, language, script, SFX wishes).

## Hard rules
1. Use ONLY the files in this kit. Do not pull in assets from any other project.
2. Do NOT render anything until the user says "render". First, show 1 to 3 preview frames and wait for approval (step-by-step approval workflow).
3. Never reuse another company's logo. Draw an original brand mark as inline SVG in `config.js` (`mark_svg`).
4. Sounds are original synthesis (`scripts/sfx_soft.py`). No samples, no copyrighted audio.
5. Deliver results as files (frames preview PNGs, final MP4, sfx.wav) using present_files.

## What is in the kit
- `template/index.html` — the engine (all transitions T1..T6, 6 openings A–F). Do not edit unless fixing a bug.
- `template/config.js` — THE ONLY FILE you edit per topic (brand_word, placeholder, prompt_text, tagline, opening, accent, result_image, cps, font, rtl, hot_chars, mark_svg).
- `topics/` — copy-paste config examples (`example_persian.js` is a full RTL example).
- `assets/original/` — 14 generated PNGs (backgrounds, glow, planet-rim arc, icons, cursor, search bar, capsule, chat bubbles, controls sheet, 2 lake images, film grain).
- `assets/keyed/` — green-screen-removed cut-outs (already built; rebuild with `scripts/key_assets.py`).
- `fonts/` + `fonts/fonts.css` — Vazirmatn, IBM Plex Sans Arabic, SF Arabic, Parastoo, Lalezar, Playpen Sans Arabic, Markazi Text, iOS 15 Medium. Use the family name in `config.js` `font`.
- `scripts/` — `check_assets.py`, `key_assets.py`, `render.py`, `sfx_glass.py` + `sfx_soft.py`, `build_video.sh`.
- `prompts/` — topic brief form, image-generation prompts for new result images, per-topic checklist.
- `skill/glass-prompt-video/SKILL.md` — the same recipe as a skill file (install if the user wants it as a skill).
- `README_TRANSITIONS.md` — the full transition recipe (timings, what each opening does).
- `reference/reference_video.mp4` — the target look.

## Workflow (do in order, one step per approval)
1. `pip install numpy scipy pillow playwright --break-system-packages` (+ `playwright install chromium`, ffmpeg needed). If network is off, tell the user.
2. `python3 scripts/check_assets.py` — must say nothing missing.
3. Ask the user (or read their message) for the TOPIC BRIEF (`prompts/TOPIC_BRIEF_TEMPLATE.md`). Fill gaps with sensible defaults and state them in one line.
4. Write `template/config.js` from the brief. For Persian/Arabic: `rtl:true`, `font:"Vazirmatn"` (or another Arabic font in `fonts/`), write `placeholder` yourself.
5. Result image: if the user supplies one, copy to `assets/original/` and set `result_image`. Otherwise give them an image prompt from `prompts/RESULT_IMAGE_PROMPTS.md` (16:9, 1920x1080). Placeholder: the lake images.
6. Preview: `python3 scripts/render.py preview 0.4,1.2,2.4` then show frames. Adjust, wait for OK.
7. On "render": `bash scripts/build_video.sh output/final.mp4 [voice_or_music.mp3]`. Duration is computed from text lengths (see schedule.json) so a longer prompt = longer video automatically.
8. Present `output/final.mp4`.

## Timing facts (so scripts/voice-overs line up)
`type0=2.4s` prompt typing starts; `cps` chars per second; whip-pan, click, morph (0.4s), scale-through (0.5s), tagline typing, flash (0.6s), wash drain, brand end-card (1.25s). Read `output/schedule.json` after any preview for exact seconds, then place voice-over / captions against it.

## Known gaps (tell the user honestly)
- No Poppins font file was supplied. Latin default falls back to Helvetica/Arial. For English use "Vazirmatn" or "SF Arabic" (both have Latin) or drop Poppins TTFs into `fonts/` and re-run the fonts.css generator in README_TRANSITIONS.md.
- Needs Chromium (playwright) + ffmpeg for rendering.
