"""Synthesize the soft Apple-style SFX track timed to the video. usage (after a render/preview wrote output/schedule.json):
  python3 scripts/sfx_glass.py            -> output/sfx.wav
Edit the CUE rules below to taste. Needs numpy + scipy. Uses sfx_soft.py (same folder)."""
import json, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from sfx_soft import mix
R = pathlib.Path(__file__).resolve().parent.parent
d = json.load(open(R/"output"/"schedule.json")); T = d["schedule"]; cps = d["cps"]; op = d["opening"]
cues = []
# --- opening (0 - 2.4 s) ---
cues += {"A":[(0.30,"whoosh_soft",.8),(0.45,"sparkle",.5)],
         "B":[(0.45,"swish",.7),(1.0,"pop",.8)],
         "C":[(0.05,"riser_soft",.5),(0.6,"pop",.9)],
         "D":[(0.05,"whoosh_soft",.8),(0.95,"drop",.7)],
         "E":[(0.15,"swish",.7),(0.62,"tap",1.0)],
         "F":[(0.0,"whoosh_soft",.9)]}[op]
cues += [(1.0+0.07*i,"tap",.35,1+.03*i) for i in range(d["brand_len"])]            # brand letters
cues += [(1.85,"pop",.8)]                                                           # capsule appears
# --- typing the prompt ---
for i in range(d["prompt_len"]): cues.append((T["type0"]+i/cps,"key",.42,1+0.04*((i*7)%5)))
cues.append((T["type0"]+3/cps,"pop",.5))                                            # send button appears
# --- whip-pan, cursor, click ---
cues += [(T["pan0"],"swish",.9),(T["click"]-.12,"tap",.5),(T["click"],"tap",1.0,.8),(T["m0"],"send",.9),(T["m1"],"pop",.8)]
# --- scale-through, tagline typing ---
cues += [(T["s0"],"whoosh_soft",1.0),(T["s1"],"sparkle",.6)]
for i in range(d["tagline_len"]): cues.append((T["g0"]+i/cps,"key",.34,1.1+0.04*((i*5)%5)))
# --- flash, drain, outro ---
cues += [(T["w0"]-.55,"riser_soft",.7),(T["w0"]+.05,"chime",.9),(T["w1"],"whoosh_soft",.7),(T["d1"]+.1,"success",.8)]
mix(cues, d["duration"], str(R/"output"/"sfx.wav"))
print("wrote output/sfx.wav", len(cues), "cues")
