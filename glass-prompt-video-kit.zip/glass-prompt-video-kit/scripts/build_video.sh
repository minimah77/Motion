#!/usr/bin/env bash
# Frames + SFX (+ optional voice/music) -> MP4.   usage: bash scripts/build_video.sh [out.mp4] [extra_audio.mp3]
set -e; cd "$(dirname "$0")/.."; OUT=${1:-output/final.mp4}; FPS=${FPS:-30}
python3 scripts/render.py full
python3 scripts/sfx_glass.py
if [ -n "$2" ]; then AUD="-i output/sfx.wav -i $2 -filter_complex amix=inputs=2:duration=first:normalize=0"; else AUD="-i output/sfx.wav"; fi
ffmpeg -y -framerate $FPS -i output/frames/f%04d.jpg $AUD -c:v libx264 -preset medium -crf 17 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart -shortest "$OUT"
ffprobe -v error -show_entries format=duration -of csv=p=0 "$OUT"
