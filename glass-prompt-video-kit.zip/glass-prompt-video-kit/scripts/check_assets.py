"""Run first: python3 scripts/check_assets.py  -> one-line report of what is present / missing."""
import pathlib
R=pathlib.Path(__file__).resolve().parent.parent
need=["assets/original/0%d_%s.png"%(i,n) for i,n in []]
files=["01_near_black_navy_gradient","02_soft_blue_horizon_gradient","03_curved_planet_rim_light_arc","05_ui_icon_set_plus_mic_send","06_macos_pointing_hand_cursor","08_calm_lake_dawn_forest_reflection_01","09_fine_neutral_film_grain"]
miss=[f for f in files if not (R/"assets/original"/(f+".png")).exists()]
keyed=[f for f in ["planet_rim_arc","icon_plus","icon_mic","icon_send","cursor_hand"] if not (R/"assets/keyed"/(f+".png")).exists()]
print("MISSING originals:",miss or "none","| MISSING keyed:",keyed or "none (or run scripts/key_assets.py)")
