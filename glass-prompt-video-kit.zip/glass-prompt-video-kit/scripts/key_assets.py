"""Rebuild assets/keyed/*.png from assets/original (green #00FF00 -> alpha, despill, auto-crop).
usage: python3 scripts/key_assets.py        (needs numpy, scipy, pillow)"""
import numpy as np, pathlib
from PIL import Image
from scipy import ndimage as ndi

R = pathlib.Path(__file__).resolve().parent.parent
O = R / "assets" / "original"
KD = R / "assets" / "keyed"
KD.mkdir(exist_ok=True)


def key(p):
    a = np.asarray(Image.open(p).convert("RGB")).astype(np.float32)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    al = 1 - np.clip((g - np.maximum(r, b) - 40) / 110, 0, 1)
    g2 = np.minimum(g, np.maximum(r, b) + 8)  # despill
    return np.dstack([r, g2, b, al * 255]).astype(np.uint8)


def comps(a, minarea=800, dil=14):
    lab, n = ndi.label(ndi.binary_dilation(a[..., 3] > 40, iterations=dil))
    out = []
    for i, s in enumerate(ndi.find_objects(lab)):
        if (lab[s] == i + 1).sum() >= minarea:
            out.append((s[1].start, s[0].start, s[1].stop, s[0].stop))
    return sorted(out)


def save(a, box, name, pad=24):
    x0, y0, x1, y1 = box
    h, w = a.shape[:2]
    x0, y0, x1, y1 = max(0, x0 - pad), max(0, y0 - pad), min(w, x1 + pad), min(h, y1 + pad)
    Image.fromarray(a[y0:y1, x0:x1], "RGBA").save(KD / name, optimize=True)
    print("keyed", name)


def biggest(c):
    return max(c, key=lambda b: (b[2] - b[0]) * (b[3] - b[1]))


# arc already has alpha
Image.open(O / "03_curved_planet_rim_light_arc.png").convert("RGBA").save(KD / "planet_rim_arc.png", optimize=True)
print("keyed planet_rim_arc.png")

a = key(O / "05_ui_icon_set_plus_mic_send.png")
for box, n in zip(comps(a, 200, 30)[:3], ["icon_plus.png", "icon_mic.png", "icon_send.png"]):
    save(a, box, n, 6)

a = key(O / "06_macos_pointing_hand_cursor.png")
save(a, biggest(comps(a, 500, 10)), "cursor_hand.png", 6)

for f, n in [("04_dark_glass_search_bar.png", "search_bar_dark.png"),
             ("07_frosted_glass_capsule.png", "capsule_frosted.png"),
             ("12_empty_dark_glass_app_window.png", "window_dark_glass.png")]:
    a = key(O / f)
    save(a, biggest(comps(a, 2000, 10)), n, 10)

for f, pre in [("10_chat_bubbles_dark_and_frosted_v1.png", "bubbles_v1"),
               ("11_chat_bubbles_dark_and_frosted_v2.png", "bubbles_v2")]:
    a = key(O / f)
    c = sorted(comps(a, 2000, 10), key=lambda b: b[1])
    for i, b in enumerate(c[:2]):
        save(a, b, pre + "_" + ["dark", "frosted"][i] + ".png", 10)

a = key(O / "13_ui_controls_sheet.png")
for i, b in enumerate(comps(a, 300, 12)):
    save(a, b, "control_%d.png" % (i + 1), 8)
