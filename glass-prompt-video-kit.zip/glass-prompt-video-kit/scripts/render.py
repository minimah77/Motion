"""Render the template to frames.  usage (run from the kit root):
  python3 scripts/render.py preview 0.4,1.2,2.4   -> output/preview/tXX.XX.png
  python3 scripts/render.py preview                -> 10 evenly spaced previews
  python3 scripts/render.py full                   -> output/frames/f0000.jpg ...
Env: FPS (default 30). Also prints duration and the schedule (output/schedule.json)."""
import sys, asyncio, os, json, pathlib
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parent.parent
MODE=sys.argv[1]; ARG=sys.argv[2] if len(sys.argv)>2 else ""
FPS=int(os.environ.get("FPS","30"))
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=["--allow-file-access-from-files","--force-color-profile=srgb"])
        pg=await b.new_page(viewport={"width":1920,"height":1080},device_scale_factor=1)
        msgs=[]; pg.on("console",lambda m:msgs.append(m.text)); pg.on("pageerror",lambda e:msgs.append("ERR "+str(e)))
        await pg.goto("file://"+str(ROOT/"template"/"index.html"))
        await pg.evaluate("loadAll()"); await pg.wait_for_timeout(300)
        dur=await pg.evaluate("window.DURATION"); sch=await pg.evaluate("window.SCHEDULE")
        (ROOT/"output").mkdir(exist_ok=True)
        json.dump({"duration":dur,"schedule":sch,"cps":await pg.evaluate("CONFIG.cps"),"prompt_len":await pg.evaluate("[...CONFIG.prompt_text].length"),
                   "tagline_len":await pg.evaluate("[...CONFIG.tagline].length"),"brand_len":await pg.evaluate("[...CONFIG.brand_word].length"),
                   "opening":await pg.evaluate("CONFIG.opening")},open(ROOT/"output"/"schedule.json","w"),indent=1)
        print("duration",round(dur,2),"s")
        if MODE=="preview":
            out=ROOT/"output"/"preview"; out.mkdir(parents=True,exist_ok=True)
            ts=[float(x) for x in ARG.split(",")] if ARG else [i*dur/9 for i in range(10)]
            for t in ts:
                await pg.evaluate(f"render({t})"); await pg.wait_for_timeout(30)
                await pg.locator("#stage").screenshot(path=str(out/f"t{t:05.2f}.png"))
        else:
            out=ROOT/"output"/"frames"; out.mkdir(parents=True,exist_ok=True)
            n=int(dur*FPS)
            for i in range(n):
                await pg.evaluate(f"render({i/FPS})")
                await pg.locator("#stage").screenshot(path=str(out/f"f{i:04d}.jpg"),type="jpeg",quality=93)
            print("frames",n)
        for m in msgs[:10]: print("console:",m)
        await b.close()
asyncio.run(main())
