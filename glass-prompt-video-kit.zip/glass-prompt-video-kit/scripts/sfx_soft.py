"""Original-synthesis soft UI sound kit (no samples, no third-party audio). Needs numpy + scipy.
mix(cues, duration, out_path): cues = [(time_s, name, gain[, pitch])]. Names:
whoosh_soft swish sparkle pop tap key send riser_soft drop chime success"""
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, lfilter
SR = 44100
rng = np.random.default_rng(7)

def _t(d): return np.arange(int(SR * d)) / SR
def _env(n, a=.005, r=.1):
    e = np.ones(n); na = max(1, int(a * SR)); nr = max(1, int(r * SR))
    e[:na] = np.linspace(0, 1, na); e[-nr:] *= np.linspace(1, 0, nr)
    return e
def _bp(x, lo, hi):
    b, a = butter(2, [lo / (SR / 2), min(hi, SR / 2 - 100) / (SR / 2)], btype="band"); return lfilter(b, a, x)
def _lp(x, f):
    b, a = butter(2, f / (SR / 2)); return lfilter(b, a, x)
def _sine(f, d, dec=6):
    t = _t(d); return np.sin(2 * np.pi * f * t) * np.exp(-dec * t)
def _sweep(f0, f1, d):
    t = _t(d); f = f0 * (f1 / f0) ** (t / d); return np.sin(2 * np.pi * np.cumsum(f) / SR)

def whoosh_soft(p=1):
    d = .9; n = rng.standard_normal(int(SR * d)); t = _t(d)
    x = _bp(n, 300 * p, 3500 * p); return x * np.sin(np.pi * t / d) ** 2 * .5
def swish(p=1):
    d = .35; n = rng.standard_normal(int(SR * d)); t = _t(d)
    return _bp(n, 1200 * p, 6000) * np.sin(np.pi * t / d) ** 2 * .45
def sparkle(p=1):
    d = .8; y = np.zeros(int(SR * d))
    for i, f in enumerate([2093, 2637, 3136, 3951, 5274]):
        s = int(i * .06 * SR); x = _sine(f * p, .5, 7) * .25; y[s:s + len(x)] += x[:len(y) - s]
    return y
def pop(p=1):
    return _sweep(520 * p, 190 * p, .12) * np.exp(-_t(.12) * 22) * .9
def tap(p=1):
    n = rng.standard_normal(int(SR * .05)); return (_lp(n, 2500) * np.exp(-_t(.05) * 90) * .7 + _sine(180 * p, .05, 70) * .5)
def key(p=1):
    n = rng.standard_normal(int(SR * .035)); return _bp(n, 1800 * p, 7000) * np.exp(-_t(.035) * 140) * .55
def send(p=1):
    y = _sine(2200 * p, .2, 18) * .15; y[:int(SR * .16)] += _sweep(600 * p, 1500 * p, .16) * np.exp(-_t(.16) * 14) * .6; return y
def riser_soft(p=1):
    d = .6; n = rng.standard_normal(int(SR * d)); t = _t(d)
    return _bp(n, 400, 5000) * (t / d) ** 2 * .35
def drop(p=1):
    return _sweep(380 * p, 70, .5) * np.exp(-_t(.5) * 6) * .8
def chime(p=1):
    d = 1.2; y = np.zeros(int(SR * d))
    for f, g in [(1319, 1), (1976, .6), (2637, .35)]: y += _sine(f * p, d, 3.2) * g * .35
    return y
def success(p=1):
    d = 1.4; y = np.zeros(int(SR * d))
    for i, f in enumerate([784, 988, 1175, 1568]):
        s = int(i * .09 * SR); x = _sine(f * p, 1.0, 3.5) * .3; y[s:s + len(x)] += x[:len(y) - s]
    return y

LIB = dict(whoosh_soft=whoosh_soft, swish=swish, sparkle=sparkle, pop=pop, tap=tap, key=key,
           send=send, riser_soft=riser_soft, drop=drop, chime=chime, success=success)

def mix(cues, duration, out_path):
    buf = np.zeros(int((duration + 1.5) * SR))
    for c in cues:
        t, name, g = c[0], c[1], c[2]; p = c[3] if len(c) > 3 else 1
        x = LIB[name](p) * g; s = max(0, int(t * SR)); e = min(len(buf), s + len(x))
        if e > s: buf[s:e] += x[:e - s]
    buf = buf[:int(duration * SR)]
    pk = np.abs(buf).max() or 1; buf = buf / pk * .85
    wavfile.write(out_path, SR, (buf * 32767).astype(np.int16))
