// Persian example: copy over template/config.js
window.CONFIG = {
  brand_word:"لومن", placeholder:"از لومن بپرس", prompt_text:"یک عکس از دریاچه بساز", tagline:"خلاقیتت را آزاد کن",
  opening:"C", accent:"#2F7BFF", result_image:"../assets/original/14_calm_lake_dawn_forest_reflection_02.png",
  cps:12, font:"Vazirmatn", rtl:true, hot_chars:1,
  mark_svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.15" stroke-linecap="round"><circle cx="12" cy="12" r="7.5"/><circle cx="12" cy="12" r="3"/></svg>'
};
