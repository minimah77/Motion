// ====== EDIT THIS FILE ONLY (topic variables). Everything else is the engine. ======
window.CONFIG = {
  brand_word:  "Lumen",                    // typed in the opening title (also used in the placeholder "Ask ...")
  placeholder: "",                         // "" = "Ask " + brand_word. Persian example: "از لومن بپرس"
  prompt_text: "Generate me a lake photo", // typed in the search capsule
  tagline:     "Unleash your Creativity",  // typed on the glass pill over the result image
  opening:     "A",                        // A planet-rim | B capsule-rise | C grid-boot | D liquid-bloom | E cursor-first | F whip-in
  accent:      "#2F7BFF",                  // glow / newest-letter colour
  result_image:"../assets/original/08_calm_lake_dawn_forest_reflection_01.png", // swap for the topic image (16:9, ideally 1920x1080)
  cps: 15,                                 // typing speed, characters per second
  font: "Poppins",                         // Poppins | Vazirmatn | "SF Arabic" | "IBM Plex Sans Arabic" | Parastoo | Lalezar | "Playpen Sans Arabic" | "Markazi Text"
  rtl: false,                              // true for Persian/Arabic text (right-to-left)
  hot_chars: 2,                            // how many newest letters glow in the accent colour while typing
  // Brand mark: inline SVG (24x24 viewBox, stroke=currentColor). Draw your own; never reuse another company's logo.
  mark_svg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.15" stroke-linecap="round"><g transform="translate(12 12)"><ellipse rx="3.2" ry="7.6" transform="rotate(0)"/><ellipse rx="3.2" ry="7.6" transform="rotate(60)"/><ellipse rx="3.2" ry="7.6" transform="rotate(120)"/></g></svg>'
};
