# STEP 2 - SVG ICON SET (130 icons, line + solid)

Folder: assets/icons

| Path | What |
|---|---|
| line/NAME.svg | 130 outline icons, 24x24 grid, stroke 1.75, round caps and joins |
| solid/NAME.svg | 130 filled icons, same names, details cut out of the fill |
| sprite_line.svg, sprite_solid.svg | one file with every icon as a symbol (use `<use href="#home"/>`) |
| icons.json | name, category and inner SVG markup for both styles, for code and Remotion |

## RULES
- All icons use `currentColor`. Set the CSS `color` (or the parent's color) to recolor. Inline them or use the sprite; a plain `<img>` shows black.
- Default size 24 on the grid; render at 56 to 120 px in video. Never mix line and solid in one scene.
- Line = calm, premium, UI labels. Solid = badges, success states, app promo, small sizes.
- Pair with a glass pill or a circle at 12 percent accent for icon chips.
- Animation: enter with the Snappy spring (scale 0.85 to 1.04 to 1), draw line icons with stroke-dash over 14 frames, swap line to solid on click or success.
- Solid icons use masks with unique ids, so inline many at once safely.

## ICON LIST BY CATEGORY
- **nav** (15): home, search, arrow-left, arrow-right, arrow-up, arrow-down, chevron-left, chevron-right, chevron-up, chevron-down, close, menu, plus, minus, check
- **status** (5): check-circle, x-circle, info, warning, help
- **action** (15): refresh, undo, copy, edit, trash, filter, sliders, share, download, upload, external-link, link, more-h, more-v, repeat
- **comm** (14): send, chat, chat-dots, mail, phone, bell, mic, at, heart, comment, thumbs-up, smile, eye, eye-off
- **media** (10): camera, video, play, pause, stop, music, image, film, headphones, volume
- **commerce** (13): bag, cart, card, wallet, coin, receipt, tag, gift, bank, chart-up, percent, dollar, crown
- **files** (17): calendar, clock, folder, file, note, list-check, map-pin, bookmark, flag, lock, unlock, key, pdf, clipboard, timer, pencil-ruler, notebook
- **tech** (17): sparkles, cpu, code, terminal, cloud, wifi, battery, shield, wand, bot, bolt, globe, settings, compass, map, layers, prompt
- **places** (6): building, store, coffee, car, plane, route
- **people** (10): user, users, user-plus, star, trophy, medal, target, rocket, flame, leaf
- **learn** (8): book, book-open, graduation, language, lightbulb, quote, hash, text

## NOT INCLUDED YET
Brand logos (never use real ones), emoji (Step 4 or ChatGPT prompt 04), device frames (Step 4).
