# STEP 3 - GLASS KIT (cards, pills, badges, data indicators)

Folder: assets/glass (122 PNG shells with transparency + live CSS)

## FILES
| Path | What |
|---|---|
| glass_kit.css | live CSS for HTML or Remotion builds: classes .gk-card .gk-light/.gk-dark/.gk-tint, .gk-pill p-*, .gk-track/.gk-fill, .gk-toggle, .gk-ring, .gk-dot, .gk-count. Real backdrop blur works here. |
| components_demo.html | open in a browser to see every live component |
| tokens.json | radii, blur, shadow, colors, pill sizes, motion |
| cards/ indicators/ pills/ badges/ | PNG shells, text-free, transparent background |

## RULES
- PNG shells have NO text. Add text in code with the type scale (H2 56 to 72, body 36 to 44, label 24 to 28 mono).
- PNG cards carry a baked soft shadow with about 110 px of transparent margin on every side. Align by the card edge, not the PNG edge. Pills 60 px margin, badges and indicators 10 to 30 px.
- PNG glass is only translucent, it cannot blur what is behind it. For real frosted glass in video builds use glass_kit.css (backdrop-filter).
- Light glass on light or pastel backgrounds, dark glass on dark gradients, tint card for one hero element per scene.
- Entry: cards use the Soft spring (stiffness 100, damping 16) with blur 24 to 0; pills and badges use Snappy (260, 20); bars fill with easeOutExpo over 24 to 40 frames.
- Add a colored bloom behind the hero card: accent at 40 percent, blur 60 to 120, breathe 35 to 60 percent.

## CARDS (24)
card_{sq 720x720, wide 960x540, tall 540x860, small 480x300, stat 420x300, notif 900x170, search 960x120}_{light,dark,tint}; bubble_in_{light,dark} (520x140); bubble_out_accent.

## PILLS (30)
pill_{glass_l, glass_d, white, ink, blue, green, orange, pink, violet, grad}_{s 170x56, m 230x72, l 320x96}.

## BADGES (18)
starburst_{yellow,blue,pink}; check_circle_{green,blue,orange}; dot_notify_red; count_bubble_red; highlighter_{yellow,blue,pink,green} (marker stroke behind a word); highlight_box_{blue,orange,green} (vector-editor box with corner handles); swash_underline_{blue,orange,pink}.

## INDICATORS (50)
ring_{blue,green,orange}_{25,50,75,100}; bar_blue_{25,50,75,100}_{light,dark}; toggle_on_{blue,green}, toggle_off_{light,dark}; slider_blue_60; checkbox_on/off; radio_on/off; pager_dots_{a1,a3}_{light,dark}; bars_up_blue, bars_up_green, bars_down_red; sparkline_up_green, sparkline_up_blue, sparkline_down_red; skeleton_3lines_{light,dark}; typing_dots_{light,dark}; stars_5_gold; avatar_ring_{blue,violet,orange}; avatar_placeholder_{blue,violet,orange}.

## QUICK RECIPES
- Feature beat: gradient frost_1 + card_wide_light + pill_blue_m + icon (solid) + sweep_glass overlay across the card.
- Proof beat: dark_midnight + card_stat_dark x3 + sparkline_up_green + ring_green_75 counting up.
- CTA: vivid gradient + pill_white_l + starburst_yellow + sparkles overlay.
- Highlight a key word: highlighter_yellow behind it (scale x from 0 to 1 in 10 frames) or highlight_box_blue with the Snappy spring.

## NEXT
Step 4: cursors and device frames. Step 5: SFX map. Step 6: final recipe + one-prompt template wired to these exact file names.
