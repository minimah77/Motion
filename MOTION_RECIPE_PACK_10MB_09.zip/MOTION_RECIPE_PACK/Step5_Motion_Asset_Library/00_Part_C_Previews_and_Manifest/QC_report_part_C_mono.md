# Step 5C QC Report - Mono (black & white) variants

Assets: 10 (5 loaders x white + black)  |  all checks passed: 10/10

Same renderer, timings, sizes and checks as the colour set (see QC_report_part_C.md); only the colours changed. The colour pack was regression-tested after the renderer change: frames are pixel-identical (max difference 0). White versions are meant for dark backgrounds, black versions for light backgrounds.

| asset | size | frames | dur | type | webm alpha | mov alpha | edge alpha | loop seam | result |
|---|---|---|---|---|---|---|---|---|---|
| loader_ring_spin_white | 720x720 | 45 | 1.5s | loop | 0/255 | 0/255 | 0 | 0.80 | PASS |
| loader_dots_bounce_white | 720x360 | 36 | 1.2s | loop | 0/255 | 0/255 | 0 | 0.44 | PASS |
| loader_bar_fill_white | 1080x270 | 90 | 3.0s | one-shot | 0/255 | 0/255 | 0 | - | PASS |
| loader_percentage_count_white | 720x720 | 90 | 3.0s | one-shot | 0/255 | 0/255 | 0 | - | PASS |
| loader_orbiting_dot_white | 720x720 | 60 | 2.0s | loop | 0/255 | 0/255 | 0 | 0.98 | PASS |
| loader_ring_spin_black | 720x720 | 45 | 1.5s | loop | 0/255 | 0/255 | 0 | 0.73 | PASS |
| loader_dots_bounce_black | 720x360 | 36 | 1.2s | loop | 0/255 | 0/255 | 0 | 0.46 | PASS |
| loader_bar_fill_black | 1080x270 | 90 | 3.0s | one-shot | 0/255 | 0/255 | 0 | - | PASS |
| loader_percentage_count_black | 720x720 | 90 | 3.0s | one-shot | 0/255 | 0/255 | 0 | - | PASS |
| loader_orbiting_dot_black | 720x720 | 60 | 2.0s | loop | 0/255 | 0/255 | 0 | 0.98 | PASS |

## Animation checks (measured on the delivered WebM)

- loader_bar_fill (white and black): fill width 0.0% at frame 0, 25.0% f24, 50.0% f36, 75.0% f48, 100% from f72 (2.4 s); monotonic.
- loader_percentage_count (white and black): all 90 frames OCR'd on the matching background. 87/90 read exactly; frames 12, 48, 49 were misread by tesseract (thin 7s) and were checked by eye: 7%, 75%, 77%. Counts 0% -> 100% with no backwards steps.
- ring / dots / orbit: loop seam ratios 0.80 / 0.44 / 0.98 (white) and 0.73 / 0.46 / 0.98 (black); no duplicate neighbour frames.

Formats: WebM VP9 yuva420p + alpha (ALPHA_MODE=1), MOV ProRes 4444 with 8-bit alpha, PNG RGBA - all confirmed by ffprobe/decode on the delivered files.

Limitations: tones are grays (white fades to light gray, black fades to dark gray) so the tail/gradient still reads; a white loader will not show on a white background and vice versa; glows are reduced in mono so edges stay clean; WebM alpha needs an alpha-aware player (use the MOV otherwise); not tested in CapCut/Premiere.
