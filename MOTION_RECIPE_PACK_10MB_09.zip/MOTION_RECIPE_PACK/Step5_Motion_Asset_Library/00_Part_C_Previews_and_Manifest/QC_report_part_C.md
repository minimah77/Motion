# Step 5C QC Report - Loading & Progress Animations

Assets: 5  |  all checks passed: 5/5

Checks per asset: WebM decoded back with libvpx-vp9 (so alpha is read) and MOV decoded natively; frame counts match the render; alpha min = 0 and max >= 150 in both; alpha tag present on the WebM; PNG companion is RGBA with >20% transparent pixels and matching dimensions; no artwork touches the frame edge; preview MP4 exists. Loops: first/last-frame difference vs the average frame-to-frame step (ratio < 2 = seamless), loop length 1-3 s, no duplicate neighbour frames. Format/dimension/frame-count values below come from ffprobe on the delivered files.

| asset | size | frames | dur | type | webm alpha (min/max) | mov alpha (min/max) | edge alpha | loop seam ratio | result |
|---|---|---|---|---|---|---|---|---|---|
| loader_ring_spin | 720x720 | 45 | 1.5s | loop | 0/255 | 0/255 | 0 | 0.76 | PASS |
| loader_dots_bounce | 720x360 | 36 | 1.2s | loop | 0/255 | 0/255 | 0 | 0.44 | PASS |
| loader_bar_fill | 1080x270 | 90 | 3.0s | one-shot | 0/255 | 0/255 | 0 | - | PASS |
| loader_percentage_count | 720x720 | 90 | 3.0s | one-shot | 0/255 | 0/255 | 0 | - | PASS |
| loader_orbiting_dot | 720x720 | 60 | 2.0s | loop | 0/255 | 0/255 | 0 | 0.96 | PASS |

## Animation checks (measured on the delivered WebM)

- loader_bar_fill: fill width measured per frame from decoded alpha: 0.0% at frame 0, 6.7% f12, 25.0% f24, 50.0% f36, 75.0% f48, 93.3% f60, 100% from f72 (2.4 s) to the end. Monotonic, starts empty, ends full.
- loader_percentage_count: all 90 frames OCR'd. 88 read exactly as expected; frames 48 and 49 were misread by tesseract (read 15 and 7) but were checked by eye and show 75% and 77%. Counter goes 0% -> 100% (reached at frame 69, 2.3 s), 63 distinct values, never goes backwards, then holds at 100% with a small pop.
- loader_ring_spin / loader_dots_bounce / loader_orbiting_dot: every consecutive frame pair differs (mean alpha step 1.23 / 3.79 / 1.46); loop seam ratios 0.76 / 0.44 / 0.96.

## Actual file formats
- WebM: VP9, yuv420p + alpha side-data (ALPHA_MODE=1), 30 fps. Needs an alpha-aware player/editor.
- MOV: ProRes 4444 with alpha (encoded yuva444p10le, 8-bit alpha, qscale 8; ffprobe reports the pixel format as yuva444p12le), 30 fps.
- PNG: RGBA, 8-bit. Each `_still.png` is a representative frame: a mid-motion frame for the three loops, and the 100% frame for the bar and the counter.

Failures: none

Limitations: colors are baked in (pink/violet/blue/yellow, readable on both light and dark); the bar has no label and the counter has no unit options (the "%" is baked in); the bar and counter are one-shot (not loops) and hold their last frame for 0.6 s; WebM alpha needs an alpha-aware player (use the MOV otherwise); not tested inside CapCut/Premiere; the MOVs are ProRes (loader_percentage_count.mov is 18 MB; the rest are 2-8 MB).
