# STEP 1 - ATMOSPHERE LAYER (gradients, grain, overlays)

Folder: assets/gradients, assets/grain, assets/overlays
Every gradient and overlay exists in two formats: `_169` = 1920x1080, `_916` = 1080x1920. Pick the suffix that matches the video format. Never crop one into the other.

## 1. GRADIENTS (24 backgrounds, JPG, full frame, no blend mode needed)
Use as the bottom layer of a scene. Drift it slowly (scale 1.0 to 1.06 or a 3 percent pan) so it never sits static.

| Mood | Files | Pair with text color | Pair with glow tint |
|---|---|---|---|
| Dark glow | dark_azure, dark_emerald, dark_hourglass, dark_midnight, dark_orange, dark_planet_rim, dark_purple, dark_red | #F5F7FF | accent at 40 percent |
| Frost (light, premium) | frost_1, frost_2, frost_3, frost_4 | #0E1330 | #2F6BFF |
| Pastel (soft, friendly) | pastel_ice, pastel_lemon, pastel_lilac, pastel_mint, pastel_peach, pastel_rose, pastel_sky | #0E1330 or #111111 | matching hue |
| Vivid (bold, app promo) | vivid_blue_cyan, vivid_blue_violet, vivid_green_teal, vivid_orange_red, vivid_pink_orange | #FFFFFF or #0B0B0B | white glow |

Rules: one gradient per scene; swap gradient at a mid-video "reset" beat; dark_planet_rim and dark_hourglass are hero backgrounds for logo reveals.

## 2. GRAIN (4 seamless tiles x 2 frames, 1024x1024, mid grey)
Files: grain_fine_1/2, grain_medium_1/2, grain_coarse_1/2, grain_film_1/2.
- Blend mode: **Overlay** (or Soft Light), opacity 3 to 6 percent (dark scenes up to 8).
- Tile the 1024 image to cover the frame. Alternate frame 1 and 2 every 2 frames for live grain.
- Apply ONCE on top of the whole composition, never per layer.
- fine = default; medium = dark scenes; coarse = retro/pixel archetypes; film = cinematic or talking head.

## 3. OVERLAYS (22 JPG on black + 2 PNG with alpha)
JPG overlays: blend mode **Screen** (black disappears). PNG vignettes: normal blend.

| File | Job | Opacity | Duration | Best on |
|---|---|---|---|---|
| beam_blue / beam_orange | vertical light beam, logo or hero reveal | 60 to 100 | 0.6 to 1.5 s, fade in/out | dark |
| bokeh_cool / bokeh_warm | floating depth, slow drift up 2 percent | 40 to 70 | whole scene | dark, vivid |
| dust / dust_dense | tiny floating specks | 30 to 60 | whole scene | dark, photoreal |
| film_burn | warm edge burn used as a TRANSITION flash | 0 to 100 to 0 | 0.4 to 0.6 s | any |
| flare_amber / flare_blue / flare_white | anamorphic streak on a reveal or click-hit | 70 to 100 | 0.3 to 0.5 s | dark |
| flash_radial | punch flash on an impact beat | 0 to 90 to 0 | 0.15 to 0.25 s | any |
| fog | slow atmosphere, drift sideways | 20 to 40 | whole scene | dark |
| godrays | light shafts from top left | 30 to 60 | 2 to 4 s slow fade | dark, sky plates |
| leak_cool_1/2/3 | cold light leak, edge color wash | 40 to 80 | 0.5 to 0.8 s | transitions on dark or frost |
| leak_warm_1/2/3 | warm light leak, same job | 40 to 80 | 0.5 to 0.8 s | transitions on any |
| shockwave_ring | ring expanding from center (scale 0.2 to 2.5, fade) | 100 to 0 | 0.5 s | impact beats |
| sparkles | success, magic, premium reveal | 60 to 100 | 0.6 to 1 s | dark |
| sweep_glass | glass shine swept across a card (move left to right) | 80 | 0.5 s | glass cards |
| vignette_deep / vignette_soft (PNG) | frame darkening | 100 | whole scene | dark or photoreal only |

## 4. QUICK RECIPES
- Premium logo reveal: dark_planet_rim + beam_blue + flare_blue + sparkles + grain_fine 4 percent.
- Bright product hero: frost_1 + fog 20 percent + sweep_glass on the card + grain_fine 3 percent.
- Scene change: leak_warm_x or film_burn for 0.4 s on the cut frame, SFX starts 4 frames earlier.
- Impact: flash_radial 0.2 s + shockwave_ring 0.5 s + camera punch zoom 1.0 to 1.25 in 8 frames.

## 5. WHAT COMES NEXT
Step 2: icons (SVG line and solid). Step 3: glass cards, pills, badges. Step 4: cursors and devices. Step 5: SFX map. Step 6: final recipe and one-prompt template wired to these exact file names.
