# STEP 4 - CURSORS, CLICK RIPPLES, DEVICE FRAMES

Folders: assets/cursors, assets/devices

## CURSORS (assets/cursors)
- svg/ and png/ (128 and 256 px, soft shadow baked in): arrow_white, arrow_dark, arrow_glass, arrow_blue, hand_point_white, hand_point_dark, hand_grab_white, text_ibeam, crosshair, loading_ring, touch_dot_light, touch_dot_dark.
- cursors.json holds the hotspot of each cursor (on the 32 grid and at 128 px). Align the hotspot, not the image corner, with the click target.
- Use at 36 to 44 px on a 1080 wide canvas (render the 128 px PNG down, never up).
- When to use: arrow_white on dark or colorful scenes, arrow_dark on light scenes, arrow_glass for premium frost scenes, arrow_blue for brand moments, hand_point over buttons and links, text_ibeam over inputs, touch_dot_* for phone UI beats (finger tap).
- Motion: path is an eased arc (easeInOutCubic, 18 to 30 frames), settles 10 frames before the click. Click = scale 1 to 0.88 in 4 frames, back in 6, ripple starts on the down frame, target button scales 0.96 to 1.
- ripple/ ripple_{blue,white,dark}_00 to 13: 14 frames, 256 px, ring grows and fades. Play once at 30 fps, centered on the hotspot. Use blue on light UI, white on dark or colored UI.

## DEVICES (assets/devices)
Each device exists as:
- `*_hole.png` : transparent screen. Put your content BEHIND it (clip the content to the screen rect with the radius from device_specs.json). Best for code builds and AE.
- `*_green.png` : pure #00FF00 screen for keying in an editor (CapCut, Premiere, AE).
- `svg/` : the same files as vector.
- device_specs.json : canvas size, screen rect [x, y, w, h, radius] in PNG pixels.

| Device | Variants |
|---|---|
| phone (760x1540, dynamic island) | black, silver, blue |
| laptop (1700x990) | silver, gray |
| tablet portrait (1000x1360) and landscape (1360x1000) | silver, gray |
| monitor with stand (1800x1300) | silver, gray |
| browser window (1720x1100, no brand) | light, dark |
| outline_phone/laptop/tablet/monitor/browser | ink and white line art, 6 px stroke, transparent |
| glare_phone/laptop/tablet/monitor | diagonal screen sheen, place on top of the content at the screen origin |

Rules:
- Devices carry no shadow. Add in code: drop-shadow 0 40 80 rgba(15,25,60,.35) on light scenes, 0 40 80 rgba(0,0,0,.6) on dark.
- 3D tilt and float are done in code (rotateX/Y 12 to 25 degrees, perspective 1200, y bob 8 px over 90 frames), not baked.
- Screen recordings: 9:16 for phone and tablet portrait, 16:9 for laptop, monitor, browser, tablet landscape.
- The phone's dynamic island is part of the frame, so content never covers it.
- Outline devices are for minimal scenes, kinetic type behind, or icon-style transitions (draw with stroke-dash over 24 frames).

## NEXT
Step 5: scene plates (blue sky and green hill, clouds, studio floor), emoji and 3D object prompts for ChatGPT, mascot guidance. Step 6: SFX map. Step 7: final recipe and one-prompt template wired to these exact file names.
