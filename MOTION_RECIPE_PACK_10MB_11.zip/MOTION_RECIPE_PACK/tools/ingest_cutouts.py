#!/usr/bin/env python3
"""
ingest_cutouts.py  -  turns ChatGPT images into clean transparent PNGs (emoji, 3D objects, mascot poses).
Needs: python3, numpy, opencv-python, pillow.

1) ONE image  ->  one cutout
   python3 ingest_cutouts.py single in.png out.png [--bg auto|magenta|green|white] [--size 1024] [--pad 6]

2) SHEET (many items on a grid, flat background)  ->  one PNG per item + contact sheet + report
   python3 ingest_cutouts.py sheet sheet.png --names grin,wink,heart --out ../assets/emoji [--prefix emoji_]
           [--bg magenta] [--size 512] [--pad 8] [--min-area 0.0015] [--merge 0.012]
   Items are found as connected blobs, sorted in reading order (rows top to bottom, left to right), then named
   from --names (or --names-file names.txt, one per line). If the blob count differs from the name count the
   script still writes everything (extra blobs are called item_NN) and prints a clear warning.

Background rule: ask ChatGPT for a flat pure magenta #FF00FF background (best, nothing in the pack is magenta).
Pure white backgrounds eat white highlights, avoid them. If the image already has transparency it is used as is.
Edges are matted softly and magenta or green fringes are removed (despill).
"""
import sys, os, argparse
import numpy as np, cv2
from PIL import Image

def sstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)

def matte(rgba, bg):
    rgb = rgba[..., :3].astype(np.float32); al = rgba[..., 3].astype(np.float32) / 255
    if (al < 0.98).mean() > 0.02 and bg == "auto":
        return rgb, al
    border = np.concatenate([rgb[0], rgb[-1], rgb[:, 0], rgb[:, -1]])
    col = {"magenta": np.array([255, 0, 255.]), "green": np.array([0, 255, 0.]), "white": np.array([255, 255, 255.])}.get(bg, np.median(border, 0))
    d = np.linalg.norm(rgb - col, axis=2)
    a = sstep(36, 110, d)
    rgb = rgb.copy()
    edge = (a > 0.02) & (a < 0.98) | (cv2.erode((a > 0.5).astype(np.uint8), np.ones((5, 5), np.uint8)) == 0) & (a > 0.5)
    if bg == "magenta" or (bg == "auto" and col[0] > 200 and col[2] > 200 and col[1] < 80):
        sp = np.clip(np.minimum(rgb[..., 0], rgb[..., 2]) - rgb[..., 1], 0, None) * edge
        rgb[..., 0] -= 0.9 * sp; rgb[..., 2] -= 0.9 * sp
    elif bg == "green" or (bg == "auto" and col[1] > 200 and col[0] < 80 and col[2] < 80):
        sp = np.clip(rgb[..., 1] - np.maximum(rgb[..., 0], rgb[..., 2]), 0, None) * edge
        rgb[..., 1] -= 0.9 * sp
    return np.clip(rgb, 0, 255), a

def crop_save(rgb, a, box, path, size, pad):
    x0, y0, x1, y1 = box; H, W = a.shape
    x0, y0, x1, y1 = max(0, x0 - pad), max(0, y0 - pad), min(W, x1 + pad), min(H, y1 + pad)
    r = np.dstack([rgb[y0:y1, x0:x1], a[y0:y1, x0:x1] * 255]).astype(np.uint8)
    im = Image.fromarray(r, "RGBA"); s = size / max(im.size)
    if s < 1: im = im.resize((round(im.width * s), round(im.height * s)), Image.LANCZOS)
    im.save(path, optimize=True); return im

def cmd_single(a):
    rgba = np.array(Image.open(a.input).convert("RGBA")); rgb, al = matte(rgba, a.bg)
    ys, xs = np.nonzero(al > 0.05)
    if len(xs) == 0: raise SystemExit("nothing found, check --bg")
    crop_save(rgb, al, (xs.min(), ys.min(), xs.max() + 1, ys.max() + 1), a.output, a.size, a.pad)
    print("OK", a.output)

def cmd_sheet(a):
    rgba = np.array(Image.open(a.input).convert("RGBA")); rgb, al = matte(rgba, a.bg)
    H, W = al.shape
    solid = (al > 0.35).astype(np.uint8)
    k = max(3, int(min(H, W) * a.merge) | 1)
    merged = cv2.dilate(solid, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    n, lab, st, _ = cv2.connectedComponentsWithStats(merged, 8)
    boxes = []
    for i in range(1, n):
        x, y, w, h, area = st[i]
        if area < a.min_area * H * W: continue
        m = (lab == i) & (solid > 0); ys, xs = np.nonzero(m)
        if len(xs) == 0: continue
        boxes.append([xs.min(), ys.min(), xs.max() + 1, ys.max() + 1])
    if not boxes: raise SystemExit("no items found, check --bg")
    boxes.sort(key=lambda b: b[1]); rows = []; med = np.median([b[3] - b[1] for b in boxes])
    for b in boxes:                                   # group into rows by vertical centre
        cy = (b[1] + b[3]) / 2
        for r in rows:
            if abs(cy - r["cy"]) < 0.55 * med: r["items"].append(b); r["cy"] = np.mean([(i[1] + i[3]) / 2 for i in r["items"]]); break
        else: rows.append({"cy": cy, "items": [b]})
    ordered = [b for r in sorted(rows, key=lambda r: r["cy"]) for b in sorted(r["items"], key=lambda b: b[0])]
    names = []
    if a.names_file: names = [l.strip() for l in open(a.names_file, encoding="utf8") if l.strip()]
    if a.names: names = [x.strip() for x in a.names.split(",") if x.strip()]
    if names and len(names) != len(ordered):
        print(f"WARNING: found {len(ordered)} items but {len(names)} names. Check the contact sheet before using the files.")
    os.makedirs(a.out, exist_ok=True); thumbs = []
    for i, b in enumerate(ordered):
        nm = names[i] if i < len(names) else f"item_{i + 1:02d}"
        p = os.path.join(a.out, f"{a.prefix}{nm}.png"); thumbs.append((nm, crop_save(rgb, al, b, p, a.size, a.pad)))
    cols = min(8, len(thumbs)); rowsn = (len(thumbs) + cols - 1) // cols; T = 132
    cs = Image.new("RGB", (cols * T, rowsn * (T + 18)), (236, 238, 246))
    from PIL import ImageDraw
    dr = ImageDraw.Draw(cs)
    for i, (nm, im) in enumerate(thumbs):
        t = im.copy(); t.thumbnail((T - 12, T - 12)); x, y = (i % cols) * T, (i // cols) * (T + 18)
        cs.paste(t, (x + (T - t.width) // 2, y + 4 + (T - 12 - t.height) // 2), t); dr.text((x + 4, y + T), nm[:20], fill=(60, 60, 80))
    cs.save(os.path.join(a.out, "_contact_sheet.jpg"), quality=88)
    print(f"OK {len(ordered)} items written to {a.out} (see _contact_sheet.jpg)")

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    s1 = sp.add_parser("single"); s1.add_argument("input"); s1.add_argument("output")
    s2 = sp.add_parser("sheet"); s2.add_argument("input"); s2.add_argument("--out", required=True)
    s2.add_argument("--names"); s2.add_argument("--names-file"); s2.add_argument("--prefix", default="")
    s2.add_argument("--min-area", type=float, default=0.0015); s2.add_argument("--merge", type=float, default=0.012)
    for s in (s1, s2):
        s.add_argument("--bg", default="auto", choices=["auto", "magenta", "green", "white"])
        s.add_argument("--size", type=int, default=1024 if s is s1 else 512); s.add_argument("--pad", type=int, default=6)
    a = ap.parse_args(); (cmd_single if a.cmd == "single" else cmd_sheet)(a)

if __name__ == "__main__":
    main()
