#!/usr/bin/env python3
"""Ingest photoreal ChatGPT plates into assets/scenes with the exact code-plate names.

Usage:
  python3 tools/ingest_photoreal_plates.py <folder_with_returned_pngs> [--scenes assets/scenes]

Input names (extra suffixes like _jpg / _webp / .PNG are ignored):
  <plate>_169  (3:2 wide, e.g. 1536x1024)   -> center-cropped to 16:9, resized to 1920x1080
  <plate>_916  (2:3 tall, e.g. 1024x1536)   -> center-cropped to 9:16, resized to 1080x1920
Plates:
  opaque JPG : sky_blue sky_clouds sky_clouds_dense sky_greenhill sky_sunset sky_sunset_hill
               studio_light studio_warm studio_dark paper_cream paper_white
  alpha WebP : hill_near hill_far  (flat magenta #FF00FF background is keyed to transparent, edges despilled)

What it does:
  1. moves the old code-built file to assets/scenes/_code_fallback/ (never deleted)
  2. writes the photoreal file under the same name
  3. writes assets/scenes/photoreal.lock.json so build_plates.py never overwrites these files
"""
import os, re, sys, json, shutil
import numpy as np
from PIL import Image

OPAQUE = ["sky_blue", "sky_clouds", "sky_clouds_dense", "sky_greenhill", "sky_sunset", "sky_sunset_hill",
          "studio_light", "studio_warm", "studio_dark", "paper_cream", "paper_white"]
ALPHA = ["hill_near", "hill_far"]
BOTTOM_ANCHOR = {"sky_greenhill", "sky_sunset_hill", "hill_near", "hill_far"}  # keep the ground when cropping 3:2 to 16:9
SIZE = {"169": (1920, 1080), "916": (1080, 1920)}

def crop_to(img, fmt, plate):
    w, h = img.size
    tw, th = SIZE[fmt]
    target = tw / th
    if w / h > target:                       # too wide: crop sides
        nw = round(h * target); x = (w - nw) // 2
        box = (x, 0, x + nw, h)
    else:                                    # too tall: crop top/bottom
        nh = round(w / target)
        y = (h - nh) if plate in BOTTOM_ANCHOR else (h - nh) // 2
        box = (0, y, w, y + nh)
    return img.crop(box).resize((tw, th), Image.LANCZOS)

def key_magenta(img):
    """Return RGBA. Alpha from how magenta a pixel is, colors un-mixed from the magenta."""
    a = np.asarray(img.convert("RGB")).astype(np.float32)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    m = np.minimum(r, b) - g                 # high only for magenta-ish pixels
    alpha = 1.0 - np.clip((m - 70.0) / (190.0 - 70.0), 0, 1)
    k = np.array([255, 0, 255], np.float32)
    al = np.maximum(alpha, 1e-3)[..., None]
    rgb = (a - (1 - al) * k) / al            # remove magenta spill from partial pixels
    rgb = np.clip(rgb, 0, 255)
    # pull any leftover magenta tint on edge pixels toward green/gray
    edge = (alpha > 0) & (alpha < 1)
    spill = np.clip(np.minimum(rgb[..., 0], rgb[..., 2]) - rgb[..., 1], 0, None)
    rgb[..., 0] = np.where(edge, rgb[..., 0] - spill, rgb[..., 0])
    rgb[..., 2] = np.where(edge, rgb[..., 2] - spill, rgb[..., 2])
    # shrink the matte by 1 px to kill the last halo
    from PIL import ImageFilter
    am = Image.fromarray((alpha * 255).astype(np.uint8)).filter(ImageFilter.MinFilter(3))
    out = np.dstack([np.clip(rgb, 0, 255).astype(np.uint8), np.asarray(am)])
    return Image.fromarray(out, "RGBA")

def parse(name):
    stem = os.path.splitext(name)[0].lower()
    stem = re.sub(r"_(jpg|jpeg|png|webp)$", "", stem)
    m = re.match(r"^(.*)_(169|916)$", stem)
    return (m.group(1), m.group(2)) if m else (None, None)

def main():
    args = [x for x in sys.argv[1:] if not x.startswith("--")]
    if not args:
        print(__doc__); sys.exit(1)
    src = args[0]
    scenes = "assets/scenes"
    if "--scenes" in sys.argv: scenes = sys.argv[sys.argv.index("--scenes") + 1]
    fb = os.path.join(scenes, "_code_fallback"); os.makedirs(fb, exist_ok=True)
    lock_path = os.path.join(scenes, "photoreal.lock.json")
    lock = json.load(open(lock_path)) if os.path.exists(lock_path) else {"files": []}
    done, skipped = [], []
    for name in sorted(os.listdir(src)):
        plate, fmt = parse(name)
        if plate not in OPAQUE + ALPHA:
            skipped.append(name); continue
        img = Image.open(os.path.join(src, name)).convert("RGB")
        img = crop_to(img, fmt, plate)
        ext = "webp" if plate in ALPHA else "jpg"
        out = os.path.join(scenes, f"{plate}_{fmt}.{ext}")
        if os.path.exists(out) and not os.path.exists(os.path.join(fb, os.path.basename(out))):
            shutil.move(out, os.path.join(fb, os.path.basename(out)))
        if ext == "jpg":
            img.save(out, quality=93, subsampling=0, optimize=True)
        else:
            rgba = key_magenta(img)
            if plate == "hill_far":                    # lift the far ridge so it peeks above the near hill
                dy = {"169": -150, "916": -260}[fmt]
                arr = np.asarray(rgba).copy(); arr = np.roll(arr, dy, axis=0); arr[dy:] = arr[dy - 1]
                rgba = Image.fromarray(arr, "RGBA")
            rgba.save(out, quality=95, alpha_quality=100, method=4)
        done.append(os.path.basename(out))
        if os.path.basename(out) not in lock["files"]: lock["files"].append(os.path.basename(out))
        print("ok", os.path.basename(out), os.path.getsize(out) // 1024, "KB")
    json.dump(lock, open(lock_path, "w"), indent=1)
    miss = [f"{p}_{f}" for p in OPAQUE + ALPHA for f in SIZE if f"{p}_{f}.{'webp' if p in ALPHA else 'jpg'}" not in lock["files"]]
    print(f"done {len(done)} | skipped {len(skipped)} {skipped} | still code-built: {miss}")

if __name__ == "__main__":
    main()
