#!/usr/bin/env python3
"""
make_device_from_photo.py
Turns a photoreal green-screen device image (from ChatGPT) into production device files and registers it
in assets/devices/device_specs.json.

Input  : PNG/JPG of ONE device. Background = flat magenta #FF00FF (or already transparent). Screen = flat green #00FF00.
Output (into assets/devices_photo/, stem = photo_<name>):
  photo_<name>_hole.webp   device with transparent background AND transparent screen (put your content BEHIND it)
  photo_<name>_green.webp  device with transparent background and a clean flat #00FF00 screen (for keying in an editor)
  photo_<name>_glare.png   soft diagonal sheen shaped to the screen (put ON TOP of the content, Screen or Normal at 60 to 100 percent)
  photo_<name>_preview.jpg proof image with a test gradient in the screen
  device_specs.json entry  canvas, screen_quad (TL,TR,BR,BL), screen bbox + radius, perspective flag, content_size,
                           css_matrix3d (maps a content box of content_size to the screen quad), rotation, files

Usage:
  python3 make_device_from_photo.py device_phone_front_green.png [more files ...] [--name phone_front]
          [--out ../assets/devices_photo] [--specs ../assets/devices/device_specs.json] [--bg auto|magenta|green|white]
          [--max-size 2400]
Name rule: device_<name>_green.png  ->  <name>   (e.g. device_laptop_34_green.png -> laptop_34)
"""
import sys, os, json, argparse
import numpy as np, cv2
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))


def defringe(rgba, solid_thr=240):
    """Edge pixels with partial alpha keep the colour of the nearest solid device pixel.
    Removes the pink rim (outer edge) and the green hairline (screen edge) on any background."""
    from scipy import ndimage
    a = rgba[..., 3]
    solid = a >= solid_thr
    if not solid.any():
        return rgba
    idx = ndimage.distance_transform_edt(~solid, return_distances=False, return_indices=True)
    out = rgba.copy()
    part = ~solid   # also fill fully transparent pixels, so lossy WebP cannot bleed pink or green into the edge
    out[..., :3][part] = rgba[..., :3][idx[0][part], idx[1][part]]
    return out

def sstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)

def largest(mask):
    n, lab, st, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), 8)
    if n <= 1: return mask.astype(bool)
    i = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA])); return lab == i

def fill_holes(mask):
    m = mask.astype(np.uint8).copy(); h, w = m.shape
    ff = np.zeros((h + 2, w + 2), np.uint8); inv = m.copy()
    cv2.floodFill(inv, ff, (0, 0), 2)
    return (m == 1) | (inv == 0)

def order_quad(p):
    p = np.array(p, np.float32); s = p.sum(1); d = p[:, 0] - p[:, 1]
    return np.array([p[np.argmin(s)], p[np.argmax(d)], p[np.argmax(s)], p[np.argmin(d)]], np.float32)  # TL TR BR BL

def line_intersect(l1, l2):
    (vx1, vy1, x1, y1), (vx2, vy2, x2, y2) = l1, l2
    A = np.array([[vx1, -vx2], [vy1, -vy2]], np.float64); b = np.array([x2 - x1, y2 - y1], np.float64)
    t = np.linalg.solve(A, b); return np.array([x1 + vx1 * t[0], y1 + vy1 * t[0]], np.float32)

def fit_quad(mask):
    cs, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    c = max(cs, key=cv2.contourArea); per = cv2.arcLength(c, True)
    quad = None
    for eps in np.linspace(0.004, 0.08, 40):
        ap = cv2.approxPolyDP(c, eps * per, True)
        if len(ap) == 4: quad = ap[:, 0, :].astype(np.float32); break
    if quad is None: quad = cv2.boxPoints(cv2.minAreaRect(c)).astype(np.float32)
    quad = order_quad(quad)
    pts = c[:, 0, :].astype(np.float32)
    for tol in (0.10, 0.05, 0.02):           # refit each side from contour points (skip rounded corners), tighter each pass
        lines = []
        for i in range(4):
            a, b = quad[i], quad[(i + 1) % 4]; ab = b - a; L = np.linalg.norm(ab)
            u = ab / L; t = ((pts - a) @ u) / L; dist = np.abs((pts - a) @ np.array([-u[1], u[0]]))
            sel = pts[(t > 0.2) & (t < 0.8) & (dist < tol * L + 4)]
            if len(sel) < 10: return quad
            lines.append(cv2.fitLine(sel, cv2.DIST_HUBER, 0, 0.01, 0.01).flatten())
        quad = order_quad([line_intersect(lines[(i - 1) % 4], lines[i]) for i in range(4)])
    return quad

def corner_radius(mask, quad):
    ys, xs = np.nonzero(mask); P = np.stack([xs, ys], 1).astype(np.float32); rs = []
    ctr = quad.mean(0)
    for q in quad:
        dirv = (ctr - q); dirv /= np.linalg.norm(dirv) + 1e-6
        t = ((P - q) @ dirv); perp = np.abs((P - q) @ np.array([-dirv[1], dirv[0]]))
        sel = t[perp < 1.5]
        if len(sel): rs.append(sel.min() / (np.sqrt(2) - 1))
    return float(np.clip(np.median(rs) if rs else 0, 0, 0.5 * min(np.linalg.norm(quad[1] - quad[0]), np.linalg.norm(quad[3] - quad[0]))))

def css_matrix3d(quad, cw, ch):
    H = cv2.getPerspectiveTransform(np.array([[0, 0], [cw, 0], [cw, ch], [0, ch]], np.float32), quad.astype(np.float32))
    H = H / H[2, 2]
    m = [H[0, 0], H[1, 0], 0, H[2, 0], H[0, 1], H[1, 1], 0, H[2, 1], 0, 0, 1, 0, H[0, 2], H[1, 2], 0, 1]
    return "matrix3d(" + ",".join("%.8g" % v for v in m) + ")", H

def process(path, name, out, specs_path, bg_mode, max_size):
    im = Image.open(path).convert("RGBA")
    if max(im.size) > max_size:
        s = max_size / max(im.size); im = im.resize((round(im.width * s), round(im.height * s)), Image.LANCZOS)
    a = np.array(im).astype(np.float32); rgb = a[..., :3]; al = a[..., 3] / 255.0
    h, w = rgb.shape[:2]
    # ---- background matte
    has_alpha = (al < 0.98).mean() > 0.02
    if has_alpha and bg_mode == "auto":
        dev = al
    else:
        border = np.concatenate([rgb[0], rgb[-1], rgb[:, 0], rgb[:, -1]])
        bgc = {"magenta": np.array([255, 0, 255.]), "green": np.array([0, 255, 0.]), "white": np.array([255, 255, 255.])}.get(bg_mode, np.median(border, 0))
        d = np.linalg.norm(rgb - bgc, axis=2)
        dev = sstep(40, 110, d)
    devb = fill_holes(largest(dev > 0.5)); dev = dev * devb
    # ---- screen mask (green)
    hsv = cv2.cvtColor(rgb.astype(np.uint8), cv2.COLOR_RGB2HSV)
    g = (hsv[..., 0] > 38) & (hsv[..., 0] < 88) & (hsv[..., 1] > 80) & (hsv[..., 2] > 70) & devb
    k = max(3, int(min(h, w) * 0.004) | 1)
    g = cv2.morphologyEx(g.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))
    scr = largest(g)                      # exact green pixels: a black island or notch stays opaque
    if scr.sum() < 0.01 * h * w: raise SystemExit(f"{path}: no green screen found (need flat #00FF00 screen)")
    scr_q = fill_holes(scr)               # filled shape, used for the quad, radius and glare
    quad = fit_quad(scr_q)
    rad = corner_radius(scr_q, quad)
    # ---- hole version: transparent screen with soft green removal, despill
    zone = cv2.dilate(scr.astype(np.uint8), np.ones((7, 7), np.uint8)).astype(bool)
    r, gch, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    green_amt = np.clip((gch - np.maximum(r, b) - 25) / 80, 0, 1) * zone
    green_amt[scr] = 1.0
    out_a = dev * (1 - green_amt)
    out_a = cv2.GaussianBlur(out_a.astype(np.float32), (0, 0), 0.6)
    spill = zone & ~scr
    rgb2 = rgb.copy(); rgb2[..., 1] = np.where(spill, np.minimum(gch, np.maximum(r, b)), gch)
    edge = cv2.dilate((~devb).astype(np.uint8), np.ones((5, 5), np.uint8)).astype(bool) & devb   # remove magenta fringe on the outer edge
    ms = np.clip(np.minimum(rgb2[..., 0], rgb2[..., 2]) - rgb2[..., 1], 0, None) * edge
    rgb2[..., 0] -= ms * 0.9; rgb2[..., 2] -= ms * 0.9
    hole = np.dstack([np.clip(rgb2, 0, 255), out_a * 255]).astype(np.uint8)
    green = hole.copy(); sa = cv2.GaussianBlur(scr.astype(np.float32), (0, 0), 0.6)
    green_rgb = rgb2 * (1 - sa[..., None]) + np.array([0, 255, 0.]) * sa[..., None]
    green_a = np.maximum(out_a, sa * dev.max())
    green = np.dstack([np.clip(green_rgb, 0, 255), green_a * 255]).astype(np.uint8)
    hole = defringe(hole); green = defringe(green)
    # ---- glare, in content space then warped to the screen quad
    side_w = float(np.mean([np.linalg.norm(quad[1] - quad[0]), np.linalg.norm(quad[2] - quad[3])]))
    side_h = float(np.mean([np.linalg.norm(quad[3] - quad[0]), np.linalg.norm(quad[2] - quad[1])]))
    cw, ch = int(round(side_w)), int(round(side_h))
    uu, vv = np.meshgrid(np.linspace(0, 1, cw, dtype=np.float32), np.linspace(0, 1, ch, dtype=np.float32))
    t = (uu + 0.55 * vv) - 0.55
    sheen = 0.16 * np.exp(-(t / 0.16) ** 2) + 0.07 * np.exp(-((t - 0.38) / 0.07) ** 2) + 0.05 * np.clip(1 - uu - 0.4 * vv, 0, 1) ** 2
    gl = np.dstack([np.full((ch, cw), 255, np.float32), np.full((ch, cw), 255, np.float32), np.full((ch, cw), 255, np.float32), sheen * 255])
    css, Hm = css_matrix3d(quad, cw, ch)
    glw = cv2.warpPerspective(gl, Hm, (w, h), flags=cv2.INTER_LINEAR, borderValue=(255, 255, 255, 0))
    glw[..., 3] *= cv2.GaussianBlur(scr_q.astype(np.float32), (0, 0), 0.8)
    glare = np.clip(glw, 0, 255).astype(np.uint8)
    # ---- preview
    test = np.zeros((ch, cw, 3), np.float32)
    test[...] = np.array([40, 110, 255.]) * (1 - uu[..., None]) + np.array([150, 70, 255.]) * uu[..., None]
    cv2.rectangle(test, (cw // 10, ch // 12), (cw * 9 // 10, ch // 6), (255, 255, 255), -1)
    prev = cv2.warpPerspective(test, Hm, (w, h), flags=cv2.INTER_LINEAR)
    base = np.full((h, w, 3), 58, np.float32); m = cv2.warpPerspective(np.ones((ch, cw), np.float32), Hm, (w, h))[..., None]
    comp = base * (1 - m) + prev * m
    for lay in (hole, glare):
        aa = lay[..., 3:4] / 255.0; comp = comp * (1 - aa) + lay[..., :3] * aa
    # ---- write files
    os.makedirs(out, exist_ok=True); stem = f"photo_{name}"
    Image.fromarray(hole, "RGBA").save(f"{out}/{stem}_hole.webp", "WEBP", quality=95, method=6, alpha_quality=100)
    Image.fromarray(green, "RGBA").save(f"{out}/{stem}_green.webp", "WEBP", quality=95, method=6, alpha_quality=100)
    Image.fromarray(glare, "RGBA").save(f"{out}/{stem}_glare.png", optimize=True)
    pv = Image.fromarray(np.clip(comp, 0, 255).astype(np.uint8)); pv.thumbnail((1000, 1000)); pv.save(f"{out}/{stem}_preview.jpg", quality=88)
    # ---- geometry report
    top = quad[1] - quad[0]; rot = float(np.degrees(np.arctan2(top[1], top[0])))
    dev_rect = abs(np.linalg.norm(quad[1] - quad[0]) - np.linalg.norm(quad[2] - quad[3])) / side_w + abs(np.linalg.norm(quad[3] - quad[0]) - np.linalg.norm(quad[2] - quad[1])) / side_h
    persp = bool(dev_rect > 0.03 or abs(rot) > 0.8)
    x0, y0 = quad.min(0); x1, y1 = quad.max(0)
    entry = {"kind": "photo", "canvas": [w, h],
             "screen": [int(round(x0)), int(round(y0)), int(round(x1 - x0)), int(round(y1 - y0)), int(round(rad))],
             "screen_quad": [[round(float(x), 1), round(float(y), 1)] for x, y in quad],
             "corner_radius": int(round(rad)), "perspective": persp, "rotation_deg": round(rot, 2),
             "content_size": [cw, ch], "css_matrix3d": css,
             "files": {"hole": f"assets/devices_photo/{stem}_hole.webp", "green": f"assets/devices_photo/{stem}_green.webp",
                       "glare": f"assets/devices_photo/{stem}_glare.png", "preview": f"assets/devices_photo/{stem}_preview.jpg"},
             "usage": "Render content at content_size, clip with corner_radius, apply css_matrix3d with transform-origin 0 0 (or place at screen[] when perspective is false), then _hole on top, then _glare on top of that."}
    specs = {}
    if os.path.exists(specs_path):
        specs = json.load(open(specs_path))
    else:
        print("  note: specs file not found, creating", specs_path)
        os.makedirs(os.path.dirname(specs_path) or ".", exist_ok=True)
    specs[stem] = entry
    json.dump(specs, open(specs_path, "w"), indent=1)
    print(f"OK {stem}: canvas {w}x{h}, screen quad {entry['screen_quad']}, radius {int(round(rad))}, perspective {persp}")
    return entry

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+"); ap.add_argument("--name")
    ap.add_argument("--out", default=os.path.normpath(os.path.join(HERE, "..", "assets", "devices_photo")))
    ap.add_argument("--specs", default=os.path.normpath(os.path.join(HERE, "..", "assets", "devices", "device_specs.json")))
    ap.add_argument("--bg", default="auto", choices=["auto", "magenta", "green", "white"]); ap.add_argument("--max-size", type=int, default=2400)
    a = ap.parse_args()
    for f in a.files:
        nm = a.name or os.path.splitext(os.path.basename(f))[0]
        if not a.name:
            nm = nm[7:] if nm.startswith("device_") else nm
            nm = nm[:-6] if nm.endswith("_green") else nm
        process(f, nm, a.out, a.specs, a.bg, a.max_size)

if __name__ == "__main__":
    main()
