#!/usr/bin/env python3
"""
build_plates.py  -  builds every code-made scene plate of the motion pack.
Needs: python3, numpy, opencv-python, pillow.

  python3 build_plates.py all [OUT_DIR]          build everything (default OUT_DIR = ../assets/scenes)
  python3 build_plates.py panel "#FF7A2E" brand_orange [OUT_DIR]   one flat color panel in both formats

Formats: _169 = 1920x1080, _916 = 1080x1920.
Opaque plates are JPG. Layers with transparency are WebP (alpha). Cloud layers are 2x wide and
tile seamlessly left to right, so a slow x drift can loop forever.
"""
import sys, os
import numpy as np, cv2
from PIL import Image

FORMATS = {"169": (1920, 1080), "916": (1080, 1920)}
HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT = os.path.normpath(os.path.join(HERE, "..", "assets", "scenes"))

def noise(h, w, beta, seed):
    """periodic 1/f^beta noise in 0..1 (tiles in x and y)"""
    r = np.random.default_rng(seed).standard_normal((h, w)).astype(np.float32)
    F = np.fft.rfft2(r)
    fy = np.fft.fftfreq(h)[:, None].astype(np.float32)
    fx = np.fft.rfftfreq(w)[None, :].astype(np.float32)
    f = np.sqrt(fx * fx + fy * fy); f[0, 0] = 1
    F = F * (1.0 / f ** (beta / 2)); F[0, 0] = 0
    n = np.fft.irfft2(F, s=(h, w)).astype(np.float32)
    lo, hi = np.percentile(n, [1, 99])
    return np.clip((n - lo) / (hi - lo), 0, 1)

def sstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)

def hexrgb(s):
    s = s.lstrip("#"); return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))

def vgrad(stops, h, w, t0=0.0, t1=1.0):
    y = np.clip((np.linspace(0, 1, h, dtype=np.float32) - t0) / (t1 - t0), 0, 1)
    pos = [p for p, _ in stops]
    out = np.stack([np.interp(y, pos, [c[i] for _, c in stops]) for i in range(3)], -1).astype(np.float32)
    return np.repeat(out[:, None, :], w, axis=1)

def radial(h, w, cx, cy, rx, ry, power=2.0):
    yy = np.arange(h, dtype=np.float32)[:, None]; xx = np.arange(w, dtype=np.float32)[None, :]
    d = np.sqrt(((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2)
    return np.exp(-d ** power)

def to_u8(img, seed=1):
    d = (np.random.default_rng(seed).random(img.shape[:2]).astype(np.float32) - 0.5)[..., None]
    return np.clip(np.round(img + d), 0, 255).astype(np.uint8)

def _locked(path):
    lk = os.path.join(os.path.dirname(path), "photoreal.lock.json")
    if os.path.exists(lk):
        import json
        return os.path.basename(path) in json.load(open(lk)).get("files", [])
    return False

def save_jpg(arr, path, q=92):
    if _locked(path): print("   keep photoreal", os.path.basename(path)); return
    Image.fromarray(to_u8(arr)).save(path, quality=q, subsampling=0, optimize=True)
    print("  ", os.path.basename(path), os.path.getsize(path) // 1024, "KB")

def save_webp(rgba, path, q=88):
    if _locked(path): print("   keep photoreal", os.path.basename(path)); return
    rgb = to_u8(rgba[..., :3]); a = np.clip(rgba[..., 3] * 255, 0, 255).astype(np.uint8)
    Image.fromarray(np.dstack([rgb, a]), "RGBA").save(path, quality=q, alpha_quality=92, method=4)
    print("  ", os.path.basename(path), os.path.getsize(path) // 1024, "KB")

def over(base_rgb, layer_rgba):
    h, w = base_rgb.shape[:2]
    lay = layer_rgba[:, :w] if layer_rgba.shape[1] != w else layer_rgba
    a = lay[..., 3:4]
    return base_rgb * (1 - a) + lay[..., :3] * a

SKY_STOPS = [(0, (52, 148, 246)), (0.45, (126, 196, 255)), (1, (234, 246, 255))]
SUNSET_STOPS = [(0, (38, 42, 112)), (0.30, (120, 76, 170)), (0.52, (232, 110, 150)),
                (0.70, (255, 160, 110)), (0.84, (255, 208, 140)), (1, (255, 226, 170))]

def sky_blue(w, h):
    img = vgrad(SKY_STOPS, h, w, 0.0, 0.85)
    r = 0.45 * max(w, h)
    glow = radial(h, w, 0.10 * w, -0.05 * h, r, r, 1.6)
    return img + glow[..., None] * (np.array([255, 255, 255], np.float32) - img) * 0.30

def sky_sunset(w, h, sun_x):
    img = vgrad(SUNSET_STOPS, h, w, 0.0, 0.80)
    sy = 0.76 * h
    big = radial(h, w, sun_x * w, sy, (0.55 if w > h else 0.9) * w, 0.30 * h, 1.3)
    core = radial(h, w, sun_x * w, sy, 0.07 * min(w, h), 0.07 * min(w, h), 2.2)
    img = img + big[..., None] * (np.array([255, 190, 120], np.float32) - img) * 0.55
    return img + core[..., None] * (np.array([255, 246, 220], np.float32) - img) * 0.95

def make_clouds(w, h, seed, coverage, band, lit, shade, soft=0.14, flat_bottom=0.0, gain=0.55):
    big = noise(h, w, 3.0, seed); mid = noise(h, w, 2.4, seed + 1); det = noise(h, w, 1.8, seed + 2)
    d = 0.50 * big + 0.38 * mid + 0.12 * det
    d = cv2.GaussianBlur(d, (0, 0), h * 0.0025)
    yy = np.linspace(0, 1, h, dtype=np.float32)[:, None]
    c0, c1 = band
    vb = np.exp(-(((yy - (c0 + c1) / 2) / ((c1 - c0) / 2)) ** 2) * 1.6)
    d = d + 0.55 * (vb - 0.5)
    if flat_bottom:
        d = d - flat_bottom * sstep(c1 - 0.05, c1 + 0.12, yy)
    thr = np.percentile(d, 100 * (1 - coverage))
    alpha = sstep(thr, thr + soft, d)
    ds = cv2.GaussianBlur(d, (0, 0), h * 0.004)
    s = max(3, int(h * 0.022))
    diff = ds - np.roll(ds, (s, int(s * 0.6)), (0, 1))
    b = np.clip(0.66 + gain * diff / (np.percentile(np.abs(diff), 97) + 1e-6), 0, 1)
    thick = sstep(thr + soft, thr + 0.45, ds)
    b = np.clip(b - 0.18 * thick * sstep(0.2, 1.0, yy), 0, 1)
    lit = np.array(lit, np.float32); shade = np.array(shade, np.float32)
    rgb = shade + (lit - shade) * b[..., None]
    return np.dstack([rgb, alpha]).astype(np.float32)

def ridge(w, h, base, amp, seed):
    r = np.random.default_rng(seed); x = np.linspace(0, 1, w)
    y = sum(a * np.sin(2 * np.pi * (f * x + r.random())) for f, a in ((1.0, 1.0), (2.3, 0.45), (4.7, 0.15)))
    return ((base + amp * y / 1.6) * h).astype(np.float32)

def hill(w, h, base, amp, seed, top, bottom, haze=0.0, haze_col=(234, 246, 255), flowers=0,
         edge=1.6, dof=False, rim=None):
    rd = ridge(w, h, base, amp, seed)
    yy = np.arange(h, dtype=np.float32)[:, None]
    depth = yy - rd[None, :]
    mask = np.clip(depth / edge + 0.5, 0, 1)
    t = np.clip(depth / (h * 0.26), 0, 1)[..., None]
    col = np.array(top, np.float32) * (1 - t) + np.array(bottom, np.float32) * t
    slope = np.gradient(rd)
    lit = np.clip(0.5 - slope * 4.0, 0, 1)[None, :, None]
    col = col * (0.93 + 0.14 * lit * (1 - t))
    patch = noise(h, w, 3.0, seed + 5); grass = noise(h, w, 1.3, seed + 6)
    grass = cv2.GaussianBlur(grass, (0, 0), sigmaX=0.6, sigmaY=5.0)
    grass = (grass - grass.min()) / (grass.max() - grass.min())
    col = col * (1 + 0.07 * (patch - 0.5)[..., None] * 2 + 0.06 * (grass - 0.5)[..., None] * 2 * (0.4 + t))
    gl = radial(h, w, 0.2 * w, 0.55 * h, 0.7 * w, 0.8 * h, 1.5)
    col = col * (1 + 0.07 * gl[..., None])
    if haze:
        hz = haze * (1 - 0.5 * t)
        col = col * (1 - hz) + np.array(haze_col, np.float32) * hz
    if rim is not None:
        rm = np.exp(-np.clip(depth, 0, None) / (h * 0.0045)) * mask
        col = col + rm[..., None] * (np.array(rim, np.float32) - col) * 0.35
    if flowers:
        fl = np.zeros((h, w, 4), np.float32); rng = np.random.default_rng(seed + 9)
        pts = []
        for _ in range(flowers):
            x = int(rng.integers(0, w)); y0 = rd[x] + 0.05 * h
            y = int(rng.uniform(y0, h - 2)); k = (y - rd[x]) / max(1.0, h - rd[x])
            pts.append((y, x, 1.0 + 5.0 * k ** 1.3))
        for y, x, r in sorted(pts):
            cv2.circle(fl, (x, y), max(1, int(round(r))), (255, 255, 255, 0.92), -1, cv2.LINE_AA)
            if r > 3: cv2.circle(fl, (x, y), max(1, int(r * 0.33)), (250, 214, 90, 0.95), -1, cv2.LINE_AA)
        fl = cv2.GaussianBlur(fl, (0, 0), 0.8)
        a = fl[..., 3:4]; col = col * (1 - a) + fl[..., :3] * a
    if dof:
        bl = cv2.GaussianBlur(col, (0, 0), h * 0.006)
        wd = sstep(0.86 * h, h, yy)[..., None]
        col = col * (1 - wd) + bl * wd
    return np.dstack([col, mask]).astype(np.float32)

def studio(w, h, wall, floor, pool, pool_k, horizon):
    hz = horizon * h; soft = 0.075 * h
    yy = np.arange(h, dtype=np.float32)[:, None]
    s = sstep(hz - soft, hz + soft, yy)
    tw = np.clip(yy / hz, 0, 1); tf = np.clip((yy - hz) / (h - hz), 0, 1)
    wc = np.array(wall[0], np.float32) * (1 - tw[..., None]) + np.array(wall[1], np.float32) * tw[..., None]
    fc = np.array(floor[0], np.float32) * (1 - tf[..., None]) + np.array(floor[1], np.float32) * tf[..., None]
    img = np.repeat(wc * (1 - s[..., None]) + fc * s[..., None], w, axis=1)
    p = radial(h, w, 0.5 * w, hz + 0.20 * (h - hz), 0.56 * w, 0.26 * (h - hz) + 0.10 * h, 2.0)
    img = img + p[..., None] * (np.array(pool, np.float32) - img) * pool_k
    g = radial(h, w, 0.5 * w, hz - 0.10 * h, 0.5 * w, 0.4 * h, 1.8)
    img = img + g[..., None] * (np.array(pool, np.float32) - img) * pool_k * 0.35
    kl = radial(h, w, 0.0, 0.0, 1.0 * w, 1.1 * h, 1.4)
    return img * (0.985 + 0.03 * kl[..., None])

def soft_shadow(w, h, core, pen, peak=0.42, rr=False):
    c = np.zeros((h, w), np.float32); c2 = np.zeros((h, w), np.float32)
    if rr:
        cv2.rectangle(c, (int(w * .22), int(h * .30)), (int(w * .78), int(h * .62)), 1.0, -1)
        cv2.rectangle(c2, (int(w * .18), int(h * .26)), (int(w * .82), int(h * .66)), 1.0, -1)
    else:
        cv2.ellipse(c, (w // 2, h // 2), (int(w * 0.34), int(h * 0.16)), 0, 0, 360, 1.0, -1, cv2.LINE_AA)
        cv2.ellipse(c2, (w // 2, h // 2), (int(w * 0.42), int(h * 0.26)), 0, 0, 360, 1.0, -1, cv2.LINE_AA)
    a = 1 - (1 - 0.8 * cv2.GaussianBlur(c, (0, 0), core)) * (1 - 0.55 * cv2.GaussianBlur(c2, (0, 0), pen))
    return a / a.max() * peak

def paper(h, w, base, seed, mott=0.02, grain=0.016, fiber=0.035, vig=0.05):
    img = np.ones((h, w, 3), np.float32) * np.array(base, np.float32)
    m = (noise(h, w, 2.8, seed) - 0.5) * 2 * mott
    g = cv2.GaussianBlur(np.random.default_rng(seed + 1).standard_normal((h, w)).astype(np.float32), (0, 0), 0.6) * grain * 1.6
    f = np.zeros((h, w), np.float32); rng = np.random.default_rng(seed + 2)
    for _ in range(int(450 * h * w / 1024 ** 2)):
        cx, cy = rng.uniform(0, w), rng.uniform(0, h); ang = rng.uniform(0, np.pi); L = rng.uniform(18, 80)
        bend = rng.uniform(-0.5, 0.5); sign = 1.0 if rng.random() < 0.5 else -0.7
        pts = np.array([[cx + np.cos(ang + bend * u) * L * u, cy + np.sin(ang + bend * u) * L * u] for u in (-0.5, 0, 0.5)], np.float32)
        for ox in (-w, 0, w):
            for oy in (-h, 0, h):
                if pts[:, 0].min() + ox > w or pts[:, 0].max() + ox < 0 or pts[:, 1].min() + oy > h or pts[:, 1].max() + oy < 0: continue
                cv2.polylines(f, [np.round(pts + [ox, oy]).astype(np.int32)], False, sign, 1, cv2.LINE_AA)
    f = cv2.GaussianBlur(f, (0, 0), 0.7) * fiber
    img = img * (1 + (m + g + f)[..., None])
    if vig:
        v = radial(h, w, w / 2, h / 2, 0.85 * w, 0.85 * h, 2.4)
        kl = radial(h, w, 0.15 * w, 0.1 * h, 0.9 * w, 0.9 * h, 1.5)
        img = img * (1 - vig + vig * v[..., None]) * (0.985 + 0.025 * kl[..., None])
    return img

PANELS = {"panel_pop_pink": "#FF84C6", "panel_pop_blue": "#1F4FE0", "panel_pop_green": "#16D84A", "panel_pop_yellow": "#FFE23A",
          "panel_pop_red": "#D4170F", "panel_paper_cream": "#F4F2EC", "panel_ink_black": "#0B0B0B", "panel_white": "#FFFFFF",
          "panel_frost": "#F1F3FA"}

def lum(rgb):
    f = lambda c: (c / 255 / 12.92) if c / 255 <= 0.03928 else ((c / 255 + 0.055) / 1.055) ** 2.4
    r, g, b = [f(c) for c in rgb]; return 0.2126 * r + 0.7152 * g + 0.0722 * b

def contrast(a, b):
    la, lb = lum(a), lum(b); return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)

def flat_panel(out, name, hx, fmt):
    w, h = FORMATS[fmt]
    Image.new("RGB", (w, h), hexrgb(hx)).save(f"{out}/{name}_{fmt}.png", optimize=True)

def build_all(out):
    os.makedirs(out, exist_ok=True)
    for fmt, (w, h) in FORMATS.items():
        print("format", fmt, w, h)
        wide = (2 * w, h); land = w > h
        hz_far, hz_near = (0.655, 0.805) if land else (0.735, 0.855)
        amp_far, amp_near = (0.035, 0.045) if land else (0.020, 0.028)
        sky = sky_blue(w, h)
        save_jpg(sky, f"{out}/sky_blue_{fmt}.jpg")
        c_soft = make_clouds(*wide, seed=11, coverage=0.27, band=(0.08, 0.60), soft=0.10, lit=(255, 253, 248), shade=(170, 192, 224))
        c_dense = make_clouds(*wide, seed=21, coverage=0.62, band=(0.45, 1.02), lit=(255, 253, 248), shade=(160, 184, 220), flat_bottom=0.25)
        c_sun = make_clouds(*wide, seed=31, coverage=0.30, band=(0.12, 0.68), lit=(255, 214, 178), shade=(178, 118, 156), soft=0.12, gain=0.38)
        save_webp(c_soft, f"{out}/clouds_soft_{fmt}.webp")
        save_webp(c_dense, f"{out}/clouds_dense_{fmt}.webp")
        save_webp(c_sun, f"{out}/clouds_sunset_{fmt}.webp")
        save_jpg(over(sky, c_soft), f"{out}/sky_clouds_{fmt}.jpg")
        save_jpg(over(sky, c_dense), f"{out}/sky_clouds_dense_{fmt}.jpg")
        far = hill(w, h, hz_far, amp_far, 41, top=(150, 214, 170), bottom=(96, 190, 128), haze=0.38, edge=2.6)
        near = hill(w, h, hz_near, amp_near, 52, flowers=(230 if land else 170), top=(142, 224, 106), bottom=(30, 154, 88), dof=True)
        save_webp(far, f"{out}/hill_far_{fmt}.webp"); save_webp(near, f"{out}/hill_near_{fmt}.webp")
        save_jpg(over(over(over(sky, c_soft), far), near), f"{out}/sky_greenhill_{fmt}.jpg")
        sun_x = 0.68 if land else 0.5
        ss = sky_sunset(w, h, sun_x)
        save_jpg(ss, f"{out}/sky_sunset_{fmt}.jpg")
        sh_far = hill(w, h, 0.775 if land else 0.80, 0.03 if land else 0.02, 61, top=(104, 66, 134), bottom=(70, 44, 104),
                      haze=0.25, haze_col=(255, 170, 130), edge=2.4, rim=(255, 190, 130))
        sh_near = hill(w, h, 0.86 if land else 0.88, 0.04 if land else 0.025, 72, top=(44, 28, 84), bottom=(22, 14, 48), rim=(255, 170, 120))
        lay = np.dstack([over(over(np.zeros((h, w, 3), np.float32) + np.array([104, 66, 134], np.float32), sh_far), sh_near),
                         np.maximum(sh_far[..., 3], sh_near[..., 3])])
        save_webp(lay, f"{out}/hill_sunset_{fmt}.webp")
        save_jpg(over(over(ss, c_sun), lay), f"{out}/sky_sunset_hill_{fmt}.jpg")
        hz = 0.58 if land else 0.60
        save_jpg(studio(w, h, ((241, 244, 251), (232, 236, 246)), ((226, 231, 243), (212, 219, 235)), (255, 255, 255), 0.55, hz), f"{out}/studio_light_{fmt}.jpg")
        save_jpg(studio(w, h, ((251, 246, 239), (244, 238, 228)), ((237, 229, 217), (222, 212, 198)), (255, 252, 246), 0.55, hz), f"{out}/studio_warm_{fmt}.jpg")
        save_jpg(studio(w, h, ((30, 33, 43), (20, 22, 28)), ((19, 21, 27), (9, 10, 13)), (70, 82, 120), 0.55, hz), f"{out}/studio_dark_{fmt}.jpg")
        save_jpg(paper(h, w, (244, 242, 236), 5), f"{out}/paper_cream_{fmt}.jpg", 90)
        save_jpg(paper(h, w, (250, 250, 247), 6, mott=0.014, fiber=0.025), f"{out}/paper_white_{fmt}.jpg", 90)
        for name, hx in PANELS.items(): flat_panel(out, name, hx, fmt)
    save_jpg(paper(1024, 1024, (244, 242, 236), 7), f"{out}/paper_cream_tile_1024.jpg", 90)
    save_jpg(paper(1024, 1024, (250, 250, 247), 8, mott=0.014, fiber=0.025), f"{out}/paper_white_tile_1024.jpg", 90)
    save_jpg(paper(1024, 1024, (217, 196, 160), 9, mott=0.03, fiber=0.06), f"{out}/paper_kraft_tile_1024.jpg", 90)
    for name, (w, h, core, pen, rr) in {"shadow_ellipse_wide": (1600, 420, 26, 70, False), "shadow_ellipse_phone": (800, 360, 18, 50, False),
                                        "shadow_ellipse_round": (1000, 520, 24, 64, False), "shadow_card_soft": (1400, 1000, 30, 90, True)}.items():
        a = soft_shadow(w, h, core, pen, rr=rr)
        Image.fromarray(np.dstack([np.zeros((h, w, 3), np.uint8), np.round(a * 255).astype(np.uint8)]), "RGBA").save(f"{out}/{name}.png", optimize=True)
        print("  ", name + ".png", os.path.getsize(f"{out}/{name}.png") // 1024, "KB")

if __name__ == "__main__":
    a = sys.argv[1:]
    if not a or a[0] == "all":
        build_all(a[1] if len(a) > 1 else DEFAULT_OUT)
    elif a[0] == "panel" and len(a) >= 3:
        out = a[3] if len(a) > 3 else DEFAULT_OUT; os.makedirs(out, exist_ok=True)
        for fmt in FORMATS: flat_panel(out, "panel_" + a[2], a[1], fmt)
        print("panel_%s: text %s" % (a[2], "#FFFFFF" if contrast(hexrgb(a[1]), (255, 255, 255)) >= contrast(hexrgb(a[1]), (11, 11, 11)) else "#0B0B0B"))
    else:
        print(__doc__)
