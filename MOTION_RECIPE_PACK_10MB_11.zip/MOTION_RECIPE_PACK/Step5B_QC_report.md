# Step 5B QC Report - Motion Trails & Floating Particles

Assets: 10  |  all checks passed: 10/10

Checks per asset: WebM and MOV decoded back (WebM with libvpx-vp9 so alpha is read), frame counts match the render, alpha min = 0 and max >= 150, PNG companion is RGBA with >20% transparent pixels, dimensions match, preview MP4 exists. Loops: first/last-frame difference compared to the average frame-to-frame step (ratio < 2 = seamless). Edge check (no artwork touching the border) applies to the other 7 assets; the two 9:16 overlays and trail_fast_horizontal intentionally cross the frame edges (full-frame overlay or whip streak).

| asset | size | frames | dur | webm alpha max | edge alpha | loop seam ratio | result |
|---|---|---|---|---|---|---|---|
| trail_neon_swoosh | 1080x540 | 66 | 2.2s | 255 | 0 | - | PASS |
| trail_fast_horizontal | 1080x270 | 30 | 1.0s | 255 | 245 | - | PASS |
| trail_orbiting_spark | 720x720 | 60 | 2.0s | 255 | 0 | 0.79 | PASS |
| trail_comet_arc | 1080x540 | 72 | 2.4s | 255 | 1 | - | PASS |
| trail_energy_pulse | 1080x270 | 60 | 2.0s | 255 | 0 | 0.02 | PASS |
| particles_float_up | 1080x1920 | 90 | 3.0s | 241 | 222 | 0.94 | PASS |
| particles_sparkle_burst | 720x720 | 48 | 1.6s | 255 | 0 | - | PASS |
| particles_orbit_loop | 720x720 | 72 | 2.4s | 255 | 0 | 1.13 | PASS |
| particles_soft_drift | 1080x1920 | 90 | 3.0s | 215 | 48 | 1.03 | PASS |
| particles_glow_pop | 720x720 | 42 | 1.4s | 255 | 0 | - | PASS |

Failures: none

Limitations: colors are baked in; WebM alpha needs an alpha-aware player/editor (use the MOV otherwise); not tested inside CapCut/Premiere; ProRes MOVs are large (the 1080x1920 ones are about 18 MB each).