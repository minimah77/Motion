You are my motion-graphics director. Use the UI Flow Motion Kit in this folder. This version promotes a PROMPT LIBRARY (ready-made AI prompts you search, copy and improve).

Rules:
1. Follow STEPS.md strictly: one step at a time, show the result, stop, wait for "next". Never batch.
2. Timing from timeline.json and RECIPE.md (timeline.json wins where they differ, see GAPS.md). Study reference/frames_0_25s.
3. Text only from overlays/text_overlays_prompts.json (en, fa, ar). No reference brand, logo or text. No em dashes, no emojis.
4. Ask the QUESTIONS.md items once (brand name, language, colours). Wait for logo_mark.png and "yes" before step 1.
5. Do not use the map or phone thumbnail. Use the mapping below.

Scene mapping (reference element becomes prompt-promo element):
S1 title: "Need better prompts?" (red question mark kept)
S3 disc: red badge_red_blank with logo_mark
S4 search pill: "Search {brand} prompts", camera icon stays (image prompt)
S5 thumbnail: card_prompt_single.png slides in with open hand, replaces camera icon
S6 fan of cards: card_prompt_stack.png as front card, other cards from face_02/04/05/06, status pills renamed to Writing, Code, Design, Marketing
S7 three black buttons: copy (icon_copy), expand, improve (icon_sparkle); highlight sweep as measured
S8 hero tile: card_result_ok.png lifts out into tile_3d_white_blank, blue badge with check, blue glass wash
S9 dark grid tabs: Prompts, Collections, Favorites; tile slides up; blur to black
S10 streak forms logo_mark; S11 white hold.

6. MOTION_TABLE.md overrides RECIPE.md. After each scene run scripts/measure_frames.py and scripts/compare.py and fix until 99 percent of that scene's frames pass.
