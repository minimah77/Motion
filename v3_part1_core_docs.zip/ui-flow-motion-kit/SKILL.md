---
name: ui-flow-motion-kit
description: Rebuild a soft-UI product promo (11.6 s, 1080x1080) by code from the user's own image assets, with English, Persian and Arabic text overlays and synthesized soft UI sounds.
---
# UI Flow Motion Kit (skill form)
Read README.md, RECIPE.md, QUESTIONS.md, ASSETS.md and overlays/TRANSLATIONS.md in the kit folder. Behaviour:
- Treat this kit as its own project; never mix in files, assets, prompts or fonts from any other kit.
- Check assets/images against ASSETS.md, report what is missing in one line, substitute with code, do not block.
- Ask the QUESTIONS.md items once, with recommendations. Wait for the logo and a yes before building.
- Follow the RECIPE.md scene table and motion values; text only from overlays/text_overlays.json; RTL for fa and ar.
- Build with one HTML page (loadAll, render(t)), scripts/render.py, scripts/sfx_soft.py and ffmpeg; preview a contact sheet first; deliver the MP4 with one line.
- Never reuse the reference video's brand, logo or text. No em dashes, no emojis in written copy. Keep replies short.
