# Assets (UI Flow Motion Kit)

All images are in `assets/images/` (cut-outs are already transparent PNG, the green key is removed). Original ChatGPT sheets are in `assets/sheets/`. `assets/manifest.json` lists every file and its pixel size. Text is never inside an image: it comes from `overlays/text_overlays.json`.

Palette: red #D31406, blue #0A96F0, page white #FCFCFC, black #000000, charcoal #141414.
Shadows, rounded corners, outlines, blur and the white stage are done in code.

## Provided (renamed and checked)
| File | What it is | Scene |
|---|---|---|
| bg_intro_black_red_glow.png | black with soft red glow rising from the bottom | 1 |
| qmark_red_3d.png | glossy red question mark, transparent | 1 |
| cursor_hand_open / point / grab / pinch.png | white glove cursors, transparent | 4, 5, 6 |
| face_01_task_white.png | white card, 4 status icons in a column | 5 |
| face_02_black_solid.png | black card with faint rim | 5 |
| face_04_gradient_ui.png | teal to violet header, white lower half with two grey bars | 5 |
| face_05_white_device.png | white card with black phone shape | 5 |
| face_06_pale_blocks.png | pale lilac card with faint blocks | 5 |
| pill_status_draft / progress / review / done.png | empty status pills with icon, transparent | 5 |
| btn_pin_black / btn_expand_black / btn_scan_black.png | round black glass buttons | 6 |
| btn_expand_light.png | light frosted version of the expand button (hover state) | 6 |
| glow_lilac_pink.png, glow_blue_soft.png | soft glows behind the card stack | 6 |
| tile_3d_white_blank.png | soft 3D white tile with empty well | 7 |
| tile_3d_blue_glass.png | same tile in glowing blue glass (blue wash) | 7 |
| badge_blue_blank.png | blue round badge, the pin icon is added in code | 7, 9 |
| bg_dark_tiles.png | dark grid of charcoal tiles | 9 |
| tile_dark_blank.png | dark 3D tile with empty well | 9 |
| tabbar_notch_black.png | black tab bar hanging from the top, empty | 9 |

Sheets kept in `assets/sheets/`: cursor_hands_sheet, pills_status_sheet, btn_round_sheet.
Not used: the thin red horizon-line glow was rejected (does not match the video); the stronger red glow is saved as `assets/alt/bg_intro_black_red_glow_alt.png`.

## Still missing (draw in code until you generate them)
| File | Code substitute | ChatGPT prompt |
|---|---|---|
| face_03_hero_map.png | procedural SVG map (sage base, white streets, green parks, blue river on the right, black route, two dots) | A clean flat city map: soft pale sage-green base, white streets in an organic grid, a few bright green park areas, a strong blue river running down the right edge, a small blue stream on the left, a thick black route line with a small dot at the start and a small dot at the end, and one small white round pin marker with a dark centre on the route. Flat illustration. Full-bleed square, front-on, no frame, no shadow. No text, no street names, no logo. |
| thumb_phone_hand.png | rounded photo-like block, dark with yellow accents | A small square photo with rounded corners of a hand holding a black smartphone, slightly tilted, the screen shows an abstract dark interface with yellow accent blocks and no readable text. Soft studio light, plain white background, the hand and phone fill most of the frame. Square 1:1. No text, no letters, no logo, no watermark. |
| pill_search_glass.png | CSS pill, white fill, 2 px dark outline, pink glow at the ends | An empty horizontal search-bar pill, fully rounded ends, solid white fill, thin dark grey outline about 2 px, very soft pale pink glow just inside the left and right ends, completely empty, about 5 times wider than tall, on flat #00FF00. |
| badge_red_blank.png | CSS red disc #D31406 with the user's logo on top | A flat red circular disc, solid red #D31406, very subtle top-left highlight, slightly darker thin rim, empty centre, on flat #00FF00. |
| icons_ui_sheet.png | inline SVG line icons (search, camera, pushpin, expand, magnifier with sparkle) | 4 by 4 grid of 16 rounded line icons on pure white: search magnifier, camera, pushpin, share arrow, diagonal expand arrows, scan viewfinder, heart, plus, check, close, bookmark, link, download, filter, magnifier with sparkle, menu. Black 3 px stroke, rounded caps, no fill. |
| streak_redblue.png | CSS rotated black bar with a red to blue tip | A single thick black diagonal bar at 45 degrees, hard clean edges and squared ends, a thin glowing red line along the inside of one end fading into bright blue at the tip, on pure white. |

The user also supplies `logo_mark.png` (black mark, transparent or white background). Slicing names for the icon sheet, once it exists: icon_search, icon_camera, icon_pin, icon_share, icon_expand, icon_scan, icon_heart, icon_plus, icon_check, icon_close, icon_bookmark, icon_link, icon_download, icon_filter, icon_sparkle, icon_menu (row by row).
