# Questions Claude asks (once, short, with a recommendation on each)
1. **Brand and logo:** what is the brand name for the search pill, and do you have logo_mark.png (black mark, transparent or white background)?
2. **Language:** English, Persian or Arabic overlays? Recommendation: the language of your audience; Persian uses Vazirmatn.
3. **Texts:** keep the title "Need Inspiration?" and the tab and status labels from overlays/text_overlays.json, or give your own?
4. **Missing images:** generate the missing ones from ASSETS.md first (map, phone thumbnail, search pill, red badge, icons, streak) or let me draw them in code? Recommendation: generate the map and thumbnail, code the rest.
5. **Colours:** keep red #D31406 and blue #0A96F0, or swap for your brand colours?
6. **Sound:** soft synthesized UI sounds (recommended) or silent?
After the answers Claude states the plan in 5 lines and waits for the logo and "yes".
