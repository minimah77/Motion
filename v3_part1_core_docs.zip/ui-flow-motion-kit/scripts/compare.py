"""Compare build vs reference features. Pass = frame within tolerance.
Usage: python scripts/compare.py ref.json build.json
Tolerances (720 px space): luma 4, bbox edge 8 px, colour-blob edge 10 px. Target for '99 percent': >= 99 percent of frames pass.
Brand-specific content (your logo, your texts) shifts pixel counts, so counts are NOT compared, only luma, extents and presence."""
import sys, json
R = json.load(open(sys.argv[1])); B = json.load(open(sys.argv[2]))
n = min(len(R), len(B)); bad = []
def near(a, b, tol):
    if a is None and b is None: return True
    if a is None or b is None: return False
    return all(abs(x - y) <= tol for x, y in zip(a[:4], b[:4]))
for i in range(n):
    r, b = R[i], B[i]; why = []
    if abs(r['luma'] - b['luma']) > 4: why.append('luma %.0f vs %.0f' % (r['luma'], b['luma']))
    if not near(r['nonwhite'], b['nonwhite'], 8): why.append('extent')
    if not near(r['red'], b['red'], 10): why.append('red blob')
    if not near(r['blue'], b['blue'], 10): why.append('blue blob')
    if why: bad.append((i, ', '.join(why)))
print('frames compared', n, '| pass %.1f percent' % (100 * (n - len(bad)) / n))
if len(R) != len(B): print('LENGTH MISMATCH', len(R), len(B))
runs = []
for i, w in bad:
    if runs and i - runs[-1][1] <= 1: runs[-1][1] = i
    else: runs.append([i, i, w])
for a, c, w in runs[:40]: print('fix frames %d-%d (%.2f-%.2f s): %s' % (a, c, a / 30, c / 30, w))
