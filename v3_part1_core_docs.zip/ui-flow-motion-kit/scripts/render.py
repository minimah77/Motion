"""Deterministic frame renderer: HTML page with loadAll() and render(t) -> JPEG/PNG frames.
Usage:
  python scripts/render.py BUILD_DIR PAGE.html OUT_DIR preview 0.5,2.0,4.5
  python scripts/render.py BUILD_DIR PAGE.html OUT_DIR full 0-348      # frame range at 30 fps
Then: ffmpeg -framerate 30 -i OUT_DIR/f%04d.jpg -i audio.wav -c:v libx264 -preset medium -crf 17 \
      -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart -shortest out.mp4
"""
import sys, asyncio, os
from playwright.async_api import async_playwright
BUILD, HTML, OUT, MODE, ARG = sys.argv[1:6]
FPS = 30
SIZE = int(os.environ.get("KIT_SIZE", "1080"))   # square 1080x1080
async def main():
    os.makedirs(OUT, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(args=["--allow-file-access-from-files", "--force-color-profile=srgb"])
        pg = await b.new_page(viewport={"width": SIZE, "height": SIZE}, device_scale_factor=1)
        msgs = []
        pg.on("console", lambda m: msgs.append(m.text))
        pg.on("pageerror", lambda e: msgs.append("ERR " + str(e)))
        await pg.goto("file://" + os.path.abspath(BUILD) + "/" + HTML)
        await pg.evaluate("loadAll()")
        await pg.wait_for_timeout(400)
        if MODE == "preview":
            for t in [float(x) for x in ARG.split(",")]:
                await pg.evaluate(f"render({t})")
                await pg.wait_for_timeout(40)
                await pg.screenshot(path=f"{OUT}/t{t:05.2f}.png")
        else:
            a, bb = [int(x) for x in ARG.split("-")]
            for i in range(a, bb):
                await pg.evaluate(f"render({i/FPS})")
                await pg.screenshot(path=f"{OUT}/f{i:04d}.jpg", type="jpeg", quality=93)
        for m in msgs[:10]:
            print("console:", m)
        await b.close()
asyncio.run(main())
