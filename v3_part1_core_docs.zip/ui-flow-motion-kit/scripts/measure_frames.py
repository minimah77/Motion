"""Per-frame features of a frame folder, scaled to the 720 px reference space.
Usage: python scripts/measure_frames.py FRAME_DIR PATTERN OUT.json [START_INDEX]
  reference: python scripts/measure_frames.py /tmp/ref 'f%04d.png' ref.json 1   (ffmpeg -i video1.mp4 /tmp/ref/f%04d.png)
  build:     python scripts/measure_frames.py out 'f%04d.jpg' build.json 0
"""
import sys, json, numpy as np
from PIL import Image
D, PAT, OUT = sys.argv[1:4]; S = int(sys.argv[4]) if len(sys.argv) > 4 else 0
def bb(m):
    ys, xs = np.where(m)
    if len(xs) < 15: return None
    return [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max()), int(len(xs))]
res = []; i = 0
while True:
    try: im = Image.open(D + '/' + PAT % (i + S)).convert('RGB')
    except FileNotFoundError: break
    a = np.array(im.resize((720, 720))).astype(int); r, g, b = a[..., 0], a[..., 1], a[..., 2]; L = a.mean(2)
    res.append({'f': i, 'luma': round(float(L.mean()), 1),
                'nonwhite': bb(L < 235) if L.mean() > 120 else bb(L > 40),
                'red': bb((r > 150) & (g < 90) & (b < 90)), 'blue': bb((b > 200) & (r < 80) & (g > 100))})
    i += 1
json.dump(res, open(OUT, 'w')); print(len(res), 'frames ->', OUT)
