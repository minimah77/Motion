"""Soft Apple-style UI sound synthesizer + cue mixer (original synthesis, no samples, no downloads).
Run `python scripts/sfx_soft.py demo out.wav` for a demo, or
`python scripts/sfx_soft.py mix cues.json out.wav 11.6` to mix a cue list:
  cues.json = [{"t":0.30,"sfx":"tap","gain":0.6}, {"t":1.45,"sfx":"pop"}, ...]
Sounds: tap pop swish whoosh_soft chime success click key sparkle toggle_on toggle_off drop notify riser_soft
"""
import sys, json, math
import numpy as np
SR = 44100
def _t(d): return np.arange(int(SR*d))/SR
def _env(n, a=0.004, r=0.08):
    e = np.ones(n); na = max(1,int(SR*a)); nr = max(1,int(SR*r))
    e[:na] = np.linspace(0,1,na); e[-nr:] = np.minimum(e[-nr:], np.linspace(1,0,nr)); return e
def _sine(f, d, a=0.004, r=0.08, g=1.0):
    t=_t(d); return np.sin(2*math.pi*f*t)*_env(len(t),a,r)*g
def _bell(f, d, g=1.0):
    t=_t(d); y=sum(np.sin(2*math.pi*f*k*t)*a for k,a in [(1,1),(2.01,.35),(3.02,.12)])
    return y*np.exp(-t*6)*g*0.5
def _noise(d, seed=1):
    return np.random.default_rng(seed).standard_normal(int(SR*d))
def _lp(x, fc):
    a=np.exp(-2*math.pi*np.broadcast_to(np.asarray(fc,float),x.shape)/SR); y=np.zeros_like(x); s=0.0
    for i,v in enumerate(x): s=(1-a[i])*v+a[i]*s; y[i]=s
    return y
def _reverb(x, mix=0.18):
    out=np.copy(x); rng=np.random.default_rng(3)
    for dly,g in [(0.021,.35),(0.037,.28),(0.053,.2),(0.079,.14)]:
        n=int(SR*dly); out=np.pad(out,(0,n)); out[n:n+len(x)]+=x*g
    return (1-mix)*np.pad(x,(0,len(out)-len(x)))+mix*out
def _add(*xs):
    n=max(len(x) for x in xs); out=np.zeros(n)
    for x in xs: out[:len(x)]+=x
    return out
def tap():   return _add(_sine(900,.07,.001,.06)*.5,_sine(1800,.05,.001,.04)*.15)
def pop():
    t=_t(.12); f=520+380*np.exp(-t*40); return np.sin(2*math.pi*np.cumsum(f)/SR)*np.exp(-t*30)*.6
def click(): return _sine(2400,.03,.0005,.025)*.4
def key():   return _add(_sine(1500,.035,.0005,.03)*.35,_lp(_noise(.03,5),3000)*.08)
def swish():
    n=_noise(.28,2); t=_t(.28); y=_lp(n,2200)*np.sin(np.pi*t/.28)**2; return y*.25
def whoosh_soft():
    n=_noise(.55,4); t=_t(.55); y=_lp(n,1400+3000*t/.55)*np.sin(np.pi*t/.55)**1.6; return y*.28
def chime():  return _add(_bell(1318,.9)*.5,_bell(1760,.9)*.3)
def success(): return np.concatenate([_bell(988,.18)*.5, _bell(1318,.18)*.5, _bell(1760,.7)*.55])
def sparkle():
    out=np.zeros(int(SR*.6))
    for i,f in enumerate([2093,2637,3136,3951,4186]):
        s=_sine(f,.18,.002,.15)*.25; o=int(SR*.05*i); out[o:o+len(s)]+=s[:len(out)-o]
    return out
def toggle_on():  return np.concatenate([_sine(660,.05,.002,.04),_sine(990,.08,.002,.07)])*.4
def toggle_off(): return np.concatenate([_sine(990,.05,.002,.04),_sine(660,.08,.002,.07)])*.4
def drop():
    t=_t(.25); f=700*np.exp(-t*7)+120; return np.sin(2*math.pi*np.cumsum(f)/SR)*np.exp(-t*14)*.55
def notify(): return _add(_bell(1568,.5)*.5,_bell(2093,.5)*.25)
def riser_soft():
    t=_t(.9); n=_lp(_noise(.9,7),1000+5000*t/.9)*(t/.9)**2; return n*.25
SFX={k:v for k,v in globals().items() if k in "tap pop click key swish whoosh_soft chime success sparkle toggle_on toggle_off drop notify riser_soft".split()}
def mix(cues, total, path, gain=0.9):
    buf=np.zeros(int(SR*(total+1.5)))
    for c in cues:
        y=_reverb(SFX[c["sfx"]]())*c.get("gain",.7); o=int(SR*c["t"]); buf[o:o+len(y)]+=y[:len(buf)-o]
    buf=buf[:int(SR*total)]; peak=np.max(np.abs(buf)) or 1; buf=buf/peak*min(gain,0.89)
    import wave
    st=np.stack([buf,buf],1); pcm=(np.clip(st,-1,1)*32767).astype('<i2')
    with wave.open(path,'wb') as w: w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
if __name__=="__main__":
    if sys.argv[1]=="demo":
        names=list(SFX); cues=[{"t":0.4+i*0.9,"sfx":n,"gain":.7} for i,n in enumerate(names)]
        mix(cues, 0.4+len(names)*0.9+1, sys.argv[2])
    else:
        mix(json.load(open(sys.argv[2])), float(sys.argv[4]), sys.argv[3])
