# Measured motion (from all 344 reference frames). Values are in the 720 px reference space; multiply by 1.5 for the 1080 build. Frame f = t x 30. This file OVERRIDES RECIPE.md wherever they differ.
Raw data: reference/measured_per_frame.json, reference/measured_tracks.json, reference/reference_features.json. All frames: reference/frames_30fps_480/r0001..r0344.jpg (r0001 = f0).

## S1 title (f0-f38)
- f0-f5 pure black, glow rises (luma 0 to 15 by f30). Text first visible f6.
- Blur-in: sharpness goes 63 (f6) to 1100 (f20), so blur about 12 px to 0 over 14 frames, ease-out. "Need" onset f8 (full by f20), "Inspiration" onset f8, main jump f12, full by f16.
- Hold sharp f20-f28. Blur-out f29-f38 (sharpness 987 to 48), text gone f38.
- Red question mark (41 px tall, 25 px wide) flies in from the right: left edge x 668 at f8, 642 at f10, 595 at f16, 558 at f22, 530 at f28, 498 at f34. Ease-out, it docks just after the word. y fixed 334-375.

## S2 question mark to disc (f36-f55)
- f36 the mark leaves the line, grows: f38 bbox 45x73, f40 55x85, f42 64x92, f44 69x95 at centre (333,260). It travels left and UP (x 453 to 333, y 294 to 260, f38-f44).
- f45-f50 it DROPS and enlarges: centre y 277, 289, 299, 318, 356, 392 (f45-f50), red area 2.3k to 9k px. Fade to white f44-f51 (luma 8 to 248).
- f51-f55 it becomes the red disc: 191 px wide, centre (345,366). Red area 18k px.

## S3 disc to pill (f52-f90)
- f52-f69 steady: disc with pink ring, 191 px, then breathing in: width 160 at f70, 138 at f72, 82 at f74 (blur), f75 vertical red stripe, f76 stretched 325 wide with red glow (red area 216).
- Pill grows: width 325 (f76), 392 (f77), 521 (f80), settles 488 wide x 76 tall at f90 (box x115-603, y320-396), centre (359,358).
- Typing f77-f87 (see timeline.json measured_typing_scene4). Pink glow at both ends f77-f81.

## S5 (f99-f137)
- Dock slide, motion centroid (x,y) per 3 frames from f99: (430,370) (529,389) (463,400) (373,393) (371,392) (444,410) (535,423) (378,387) (301,363) (263,357) (279,356) (286,341) (306,313). Two bursts: thumbnail in (f99-f108, peak f105), cursor/pill dock (f114-f123).
- Pill box grows to x96-719 y319-484 at f100 then settles. Pill tilt 1-2 deg while docking.

## S6 (f138-f176)
- f138 spike: pill rises to the top, fan grows. Fan box at f140: x52-595, y199-581; at f160 x124-595, y172-527; hold f150-f176.

## S7 (f177-f213)
- f177-f181 dim (luma 241 to 227). Round buttons grow f177-f188 (11 frames), ease-out with about 1.5 percent overshoot (dark area 5260 to 7002 then 6879).
- Highlight sweep: bottom light f189-f192, off by f198; middle light f201-f204, off f207; top light f207 fading.
- Map card lift starts f209-f213.

## S8 (f214-f263)
- Visible height of the lifted object (px): f209 380, f215 364, f218 291 (card leaves the fan), f221 310, f224 359, f227 372 (largest), f230 344, f239 341, f248 337, f254 329, f260 309, f263 281. So it overshoots up to about 372 then eases down to 281 (settled tile 265 wide x 281 tall incl. badge, centre (375,371)).
- Blue wash f229-f234. Blue badge centre: (524,251) f225, (481,289) f250, (459,301) f263.

## S9 (f264-f299) HARD CUT at f264, tile moves DOWN (not up)
- Dark grid, luma 20-28. Blue badge centre (452,305) f264, (434,314) f270, (431,325) f276, (431,347) f282, (431,391) f288, (439,428) f291. Slow start, accelerating (ease-in). Also drifts left 21 px.
- Blur and fade to black f288-f297 (luma 20 to 2), black f297-f299.

## S10-S11 (f300-f343) HARD CUT at f300
- f300 the streak enters from lower left: box x151-295, y360-537, red tip (205,477). Red tip path: (396,274) f303, (385,362) f306, (357,372) f309, (302,362) f312. Box f303 x246-429 y240-407, f306 x278-411 y280-404, f312 x295-397 y302-399.
- Settled logo box x297-394, y305-397 (97 x 92 px, centre (345,351)) from f318. Glint: left edge dips to 269 at f315.
- Blue glow burst f323-f324 at x320-432, y269-376. Logo gone from f325. White hold (luma 252) to f343.

## Cursor
- Not tracked per frame (white glove on white). Use the S5 centroid list above for S5, hover at the card (about x300,y355) in S6, and about (410,350) in S7. Click scale 0.9 for 120 ms.
