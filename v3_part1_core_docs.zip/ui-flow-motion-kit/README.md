# UI Flow Motion Kit

One kit = everything needed to rebuild a soft-UI product promo (11.6 s, square 1080x1080, white stage with a black intro and a dark app screen) by code from your own images, in English, Persian or Arabic. This is its own project: it shares no file with any other kit.

## How to start
1. Unzip all three parts into the same place and merge the folder `ui-flow-motion-kit/`.
2. Check `ASSETS.md` (what is provided, what is still missing and the prompts for the missing images).
3. Open a new Claude chat, attach the folder or the zips and paste `PROMPT.md`.
4. Answer the short questions in `QUESTIONS.md`, send your logo, then say yes.

## Install (3 zips, same top folder)
| Zip | Contains |
|---|---|
| ui-flow-motion-kit_part1_core.zip | README, PROMPT, SKILL, QUESTIONS, RECIPE, ASSETS, scripts/, overlays/ (translations), reference/video1.mp4, output/.keep, assets/sheets (original sheets), assets/alt |
| ui-flow-motion-kit_part2_fonts.zip | fonts/ : static TTF only, one folder per family, OFL.txt in each |
| ui-flow-motion-kit_part3_images.zip | assets/images (renamed, transparent cut-outs), assets/manifest.json |

No file appears in more than one zip.

## Fonts
Vazirmatn, IBM Plex Sans Arabic, Lalezar, Playpen Sans Arabic, Markazi Text, Parastoo (all OFL) and SF Arabic (Apple, see `fonts/SF_Arabic/LICENSE_NOTE.txt`). `Ios_15_Medium.ttf` is byte-identical to `SFArabic-Medium.ttf`, so it is not shipped twice. Lora and Nanum Myeongjo were not received.

## Scripts
- `scripts/render.py` : Playwright frames from a page with `loadAll()` and `render(t)`.
- `scripts/sfx_soft.py` : synthesized UI sounds and a cue mixer.
- `scripts/smoke_test.html` : one-second test page for the renderer.

## Notes
- Cut-outs were keyed from flat #00FF00 and checked on white and on black.
- Sheets were sliced into single files; the original sheets are kept in `assets/sheets/`.
- Reference video: `reference/video1.mp4` (style reference only).
- Rules: no brand, logo or text from the reference is reused; no em dashes or emojis in the written copy.

## v2 additions
- GAPS.md: what is still lacking. STEPS.md: one-by-one build order. PROMPT_PROMO.md: prompt-library version. overlays/text_overlays_prompts.json: its texts.
- New images: badge_red_blank, ring_red_blank, pill_search_glass, streak_redblue, icons/, card_prompt_stack, card_prompt_single, card_result_ok.
- reference/: timeline.json, contact_sheet_0_5s.png, frames_0_25s/.
- Zips: v2_part1_core_docs, v2_part2_fonts, v2_part3_images (3 files, each under 10 MB).

## v3
- MOTION_TABLE.md (measured per-frame motion, overrides RECIPE.md), scripts/measure_frames.py + compare.py (99 percent pass test), reference/frames_30fps_480 (all 344 frames), measured_*.json, crops_for_asset_matching.
- Zips: v3_part1_core_docs, v3_part2_fonts, v3_part3a_images, v3_part3b_images.
