# Translation overlays

All on-screen text of the reference video lives in `text_overlays.json` (English, Persian, Arabic). Text is never baked into the images, it is always drawn in code.

| Key | When (s) | English | Persian | Arabic |
|---|---|---|---|---|
| title_hook | 0.00-1.30 | Need Inspiration? | دنبال ایده می‌گردی؟ | هل تبحث عن إلهام؟ |
| search_placeholder | 2.50-3.00 | Search {brand} | جستجو در {brand} | ابحث في {brand} |
| status_draft | 4.50-6.00 | Draft | پیش‌نویس | مسودة |
| status_progress | 4.50-6.00 | In-progress | در حال انجام | قيد التنفيذ |
| status_review | 4.50-6.00 | In-review | در حال بررسی | قيد المراجعة |
| status_done | 4.50-6.00 | Completed | تکمیل‌شده | مكتمل |
| tab_1 / tab_2 / tab_3 | 8.75-9.75 | Pins / Boards / Collages | پین‌ها / بوردها / کلاژها | الدبابيس / اللوحات / الكولاجات |

Rules
- `{brand}` is the user's own brand. Never reuse the brand name, logo or wording of the reference video.
- Persian and Arabic: `dir="rtl"`, keep the question mark red, use ZWNJ where shown, wrap Latin words in a ltr span.
- Typing effect: left to right for English, right to left for Persian and Arabic. The last typed letter flashes red, like the reference.
- Fonts per language are listed in the `fonts` block of the JSON. Check glyph coverage before using SF Arabic for Latin text; fall back to Vazirmatn.
- For other languages or topics keep the same keys and swap only the strings.
