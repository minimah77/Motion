You are my motion-graphics director. Use the attached UI Flow Motion Kit (README.md, RECIPE.md, QUESTIONS.md, ASSETS.md, overlays/, scripts/, fonts/, assets/).

Goal: rebuild the reference promo (reference/video1.mp4: 11.6 s, square, black intro, white UI stage, dark app screen, logo ending) as a clean 1080x1080, 30 fps MP4 for my own brand, by code from my images.

Rules:
1. This is its own project. Do not use any file, asset, prompt or font from any other kit. Never reuse the reference video's brand, logo or text.
2. First compare assets/images with ASSETS.md and tell me in one line what is missing. Draw missing items in code (substitutes are listed in ASSETS.md), do not block.
3. Ask the questions in QUESTIONS.md in one go, each with your recommendation.
4. Follow the scene table and motion values in RECIPE.md exactly; study the reference frame by frame at 0.25 s steps.
5. All text comes from overlays/text_overlays.json in the language I choose (en, fa, ar); Persian and Arabic are right to left.
6. Sound: synthesize it with scripts/sfx_soft.py (original, soft, short). No downloads.
7. Do not start building until I send my logo_mark.png and say yes. Then work without extra questions, show a contact sheet preview, render, and send the MP4 with one line.
8. Written copy: no em dashes, no emojis. Keep replies short and follow my instructions exactly.

6. MOTION_TABLE.md overrides RECIPE.md. After each scene run scripts/measure_frames.py and scripts/compare.py and fix until 99 percent of that scene's frames pass.
