# Step by step, one by one (editing and enhancing)

MEASURE LOOP (99 percent target): after every scene step run `python scripts/measure_frames.py out 'f%04d.jpg' build.json 0` then `python scripts/compare.py reference/reference_features.json build.json`. Fix the listed frame runs until at least 99 percent of the frames of that scene pass (luma, extents, red and blue blobs within tolerance), then stop. Motion numbers are in MOTION_TABLE.md and win over RECIPE.md.

Rule for Claude: do ONE step, show the result (a contact sheet or a 2 s clip of just that scene), then STOP and wait for "next" or a fix. Never batch steps. Never touch finished scenes unless asked.

Step 0  Measure. Read timeline.json and the frames in reference/frames_0_25s. For the scene asked, write a keyframe table (t, x, y, scale, rotation, blur, opacity) into build/keyframes_S#.json. Show it. Stop.
Step 1  Page skeleton. One HTML page, 1080x1080, loadAll(), render(t), a scene switch by time, debug overlay with t and frame number. Run scripts/smoke_test.html path first. Stop.
Step 2  Scene 1 (0.00-1.47): black, red glow rise, title blur-in, red question mark, blur-out. Preview frames 0,7,10,15,24,36. Stop.
Step 3  Scene 2 (1.27-1.73): lone red question mark drops while the 8-frame fade to white (f44-f51). Stop.
Step 4  Scene 3 (1.73-2.53): red disc with logo, pink ring, 1.75 s sharp, blur and stretch (f71-f76). Stop.
Step 5  Scene 4 (2.53-3.30): pill opens, typing f77-f87, last letter red, icons. Stop.
Step 6  Scene 5 (3.30-4.60): thumbnail slides in with open hand, pill tilts 1-2 degrees and docks. Stop.
Step 7  Scene 6 (4.60-5.90): pill rises, card fan grows, pointing hand, front card tilts 4 degrees. Stop.
Step 8  Scene 7 (5.90-7.13): dim to grey, glows, three buttons, highlight sweep 6.30-6.90. Stop.
Step 9  Scene 8 (7.13-8.80): hero card lifts and scales 1.0 to 2.4 over 0.9 s, blue glass wash 7.63-7.80, settle. Stop.
Step 10 Scene 9 (8.80-10.00): HARD CUT to dark grid, tab bar, tile slides up, blur to black f288-f297. Stop.
Step 11 Scene 10 and 11 (10.00-11.47): HARD CUT to white, streak forms logo, blue glow f323-f327, hold. Stop.
Step 12 Assemble all 344 frames, render, encode (RECIPE.md pipeline), compare to the reference at 0.5 s, report differences in 5 lines. Stop.
Step 13 Optional audio with sfx_soft.py, trimmed to 11.47 s.

Enhancing: after step 12, ask which scene to improve, redo only that step, re-run step 12 for that scene range only.
