# Recipe: UI Flow Motion Kit

Reference: `reference/video1.mp4`, 720x720, 30 fps, 11.58 s, H.264 + AAC. Build target: 1080x1080, 30 fps, H.264 + AAC, about 11.6 s. Everything is built by code (one HTML page with `loadAll()` and a deterministic `render(t)`, frames by `scripts/render.py`, encode with ffmpeg). Study the reference frame by frame; never copy its brand, logo or text.

## Look
- Stage: pure black with a red glow (scenes 1 and 9), page white #FCFCFC for everything else.
- Colours: red #D31406, blue #0A96F0, status orange #FF8A2A, status blue #2F80FF, status green #1DB954, charcoal #141414.
- Type: bold neutral sans (SF Arabic Bold/Medium for Latin, Vazirmatn for Persian, IBM Plex Sans Arabic for Arabic). Title about 8 percent of frame height, tight tracking, white on black.
- Cards and tiles: rounded corners about 20 percent of the side, 1 px light grey outline (#E3E3E3), soft shadow blur 40-60 px at 12-18 percent.
- Glass buttons and glows come from the images; blur, shadow and tilt are done in code.

## Scene table (verified on the reference at 0.25 s steps, tolerance plus or minus 0.15 s)
| # | Time (s) | What happens | Assets |
|---|---|---|---|
| 1 | 0.00-1.30 | Title on black with red glow. Words blur in one by one (blur 12 to 0 px, rise 8 px, 120 ms stagger). The question mark is red. Hold about 0.5 s, then the words blur out. | bg_intro_black_red_glow, title_hook |
| 2 | 1.25-1.50 | Only the red question mark remains, it rises and drops out. | qmark_red_3d |
| 3 | 1.50-2.30 | Cut to white. A blurred logo disc settles in the centre with a thin pink ring, 1.75 s sharp, then blurs and stretches into the search pill. | badge_red_blank (or code disc) + logo_mark |
| 4 | 2.30-3.00 | The pill opens and text types in (magnifier left, camera right), last letter flashes red. | pill (code), icons, search_placeholder |
| 5 | 3.00-4.25 | A phone-in-hand thumbnail slides in from the lower right with the open hand cursor, replaces the camera icon (pill tilts 1-2 degrees while it docks). | thumb_phone_hand, cursor_hand_open |
| 6 | 4.50-6.00 | Pill rises to the top, a fan of 6-7 square cards grows out of a grey block at lower left (front card white task card with 4 status pills). A pointing hand hovers, front card tilts about 4 degrees. | face_01 to face_06, pill_status_*, cursor_hand_point |
| 7 | 6.00-7.00 | Cards dim to grey, lilac-pink and blue glows appear behind the stack, three black round buttons pop in at the right (pin, expand, magnifier-sparkle). At about 6.75 s the expand button turns light. | glow_lilac_pink, glow_blue_soft, btn_* |
| 8 | 7.00-8.60 | The map card lifts out, scales up to the centre and becomes a soft 3D white tile with the blue badge top right. At 7.75 s a blue glass wash sweeps over it, then settles. | face_03_hero_map, tile_3d_white_blank, tile_3d_blue_glass, badge_blue_blank |
| 9 | 8.75-9.75 | Hard cut to the dark grid. Black tab bar hangs from the top (Pins, Boards, Collages, white underline). The tile (dark version with the map and blue badge) slides up the middle column, then the whole screen blurs and fades to black. | bg_dark_tiles, tile_dark_blank, tabbar_notch_black, tab_1..3 |
| 10 | 10.00-11.00 | Cut to white. A thick black diagonal bar with a red to blue tip forms into the logo mark; a short blue glow at 10.75 s. | streak_redblue, logo_mark |
| 11 | 11.00-11.58 | Empty white hold. | none |

## Motion values
- Easing: ease-out cubic for entrances, ease-in-out for moves, spring (overshoot 4 to 6 percent) for pops and button entrances.
- Blur transitions: 14-20 px gaussian, 6-8 frames. Cuts to or from black and white happen on a fully blurred or faded frame.
- Cursor: curved path, 500-700 ms, click scale 0.9 and back in 120 ms. States: open (arrive), point (hover), grab/pinch (optional).
- Card stack: z-spacing about 3 percent of side per card, horizontal fan offset about 6 percent, front card rotates 3 to 5 degrees on hover.
- Hero tile lift: scale 1.0 to 2.4 over 0.9 s with a shadow growing from blur 20 to 60 px.
- Grain: optional 3-4 percent overlay, last layer.

## Sound (original synthesis, no downloads)
`scripts/sfx_soft.py` makes tap, pop, click, key, swish, whoosh_soft, chime, success, sparkle, toggle_on/off, drop, notify, riser_soft. Suggested cues:
- 0.15, 0.45, 0.75 tap (title words), 1.30 swish, 1.55 pop (disc), 2.30 whoosh_soft, 2.55-2.95 key (typing, one per letter), 3.30 swish, 4.20 click, 4.55 whoosh_soft, 5.20 tap, 6.10 pop, 6.30 pop, 6.50 pop, 6.75 toggle_on, 7.10 swish, 7.75 sparkle, 8.75 click, 9.30 swish, 10.05 drop, 10.75 chime.
Keep every sound short and low gain; mix to about -16 LUFS, true peak -1 dBFS.

## Pipeline
1. Compose one HTML page, 1080x1080, `loadAll()` loads fonts (`@font-face` from `fonts/`) and images, `render(t)` draws everything deterministically from t.
2. Preview a contact sheet: `python scripts/render.py BUILD page.html out preview 0.5,1.5,2.7,3.6,5.0,6.5,7.5,9.0,10.3`.
3. Render: `python scripts/render.py BUILD page.html out full 0-348`.
4. Mix audio: `python scripts/sfx_soft.py mix cues.json out/audio.wav 11.6`.
5. Encode: `ffmpeg -framerate 30 -i out/f%04d.jpg -i out/audio.wav -c:v libx264 -preset medium -crf 17 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart -shortest out/final.mp4`.
6. Verify duration, 1080x1080, loudness, peak. Deliver the MP4 with one line.

## Languages
English, Persian and Arabic strings are in `overlays/text_overlays.json`. Persian and Arabic are right to left; typing runs right to left.
