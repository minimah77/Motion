# Gap check (v3, updated): per-frame motion is now MEASURED. See MOTION_TABLE.md.

What '99 percent' means here: timing, layout, extents and colour per frame match the reference within tolerance, checked by scripts/compare.py on all 344 frames. It does NOT mean identical pixels: your logo, brand text and your own images differ by design.

Still open: cursor exact path (only centroid per 3 frames), easing curves are read from the tables not fitted, and the 3 assets you must supply (logo_mark.png; for the original version the map and phone thumbnail, matching crops are in reference/crops_for_asset_matching, reference only, never ship them).

---- older v2 notes below ----
# Gap check: is it enough for Claude to rebuild the video frame by frame?

Short answer: enough for a faithful rebuild (about 90 percent match), not a pixel-exact clone. Nothing blocks the build.

## Now covered (new in this version)
- Red disc, red ring, search pill, streak, 16 line icons (sliced to assets/images/icons), three prompt cards.
- Reference frames every 0.25 s (reference/frames_0_25s/r001..r046.jpg, r001 = 0.00 s) next to the 0.5 s contact sheet and timeline.json.
- Scene boundaries measured from the video (hard cuts at 8.80 s and 10.00 s, fade to white 1.47-1.70 s).

## Still lacking (ranked by visual impact)
1. logo_mark.png: your black mark (transparent PNG). Needed for scenes 3 and 10. Only you can supply it.
2. Per-element keyframes: position, scale, rotation and blur of each element per frame are NOT measured (timeline.json lists this as not_yet_measured). Claude works from the scene table and 0.25 s frames, so motion curves are close, not identical. Fix: step 0 in STEPS.md measures them scene by scene.
3. Cursor paths and click moments in scenes 5, 6, 7 are not measured.
4. Exact word onsets of the title and the three button pop-ins (f177-f186) are not isolated.
5. Original-version only: face_03_hero_map and thumb_phone_hand are missing. Not needed for the prompt-promo version (cards replace them).
6. Audio: none (you said skip). sfx_soft.py can synthesize it later.
7. Fonts: Lora and Nanum Myeongjo were never received; not needed.
8. Frame size: reference is 720 px, build is 1080 px. Any 1.5x upscaled look is rebuilt in code, not copied.
9. Audio is 0.12 s longer than video (11.58 vs 11.47 s). Trim to the video.

## Recipe corrections (from timeline.json)
- Scene 2 to 3 is an 8-frame fade to white (f44-f51), not a cut.
- Scene 9 hard cut is at 8.80 s (f264), not 8.75 s.
- Buttons are already on screen by 6.20 s; what follows is a light highlight sweep bottom, middle, top (6.30-6.90 s), not pop-ins at 6.10/6.30/6.50.
- Typing runs f77-f87 (10 frames, 16 characters), fast then slower; newest letters are dark red then turn black.
