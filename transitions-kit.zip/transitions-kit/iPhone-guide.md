# Pro UI transitions on iPhone (CapCut / VN, free)

## Settings for all apps
- Project: 1080p, 60 fps. Export the same.
- Use 1-2 transition types for the whole video. Consistency = professional.
- Duration: 0.3-0.5 s. Hold each screen at least 1.5 s.

## 1. Push (navigation)
CapCut: tap the white square between two clips > Transitions > Basic > **Slide Left**. Duration 0.4 s.
Manual (better): put clip B on an overlay track, add Keyframes:
- Start: Position X = +100% (off-screen right), Opacity 100%
- End (0.4 s later): Position X = 0
- Curve: **Ease Out** on the end keyframe.
On clip A, add a keyframe moving X to -20% over the same 0.4 s, opacity 60%.

## 2. Fade-through
Clip A: Opacity 100 > 0 over the first half (0.2 s).
Clip B: Opacity 0 > 100 and Scale 96% > 100% over the second half. Ease In/Out.

## 3. Blur dissolve
CapCut: Transitions > **Blur** or **Dissolve**, 0.3 s. Or add Effects > Blur at the join, 0.25 s each side.

## 4. Zoom into detail
Keyframe Scale 100% > 125% on clip A while opacity fades to 0. Clip B starts at 90% scale and eases to 100%.

## 5. Wipe reveal
Overlay clip B, add a Mask (Linear) and keyframe the mask position left to right over 0.3 s.

## Polish checklist
- Stagger element entrances by about 0.05 s (title, cards, buttons).
- Entrance ease: Ease Out. Exit ease: Ease In. Never linear.
- Pop-in overshoot: scale 90% > 105% > 100%.
- Add a soft whoosh sound (0.2 s) at each transition and lower the music 3 dB there.
- Cut on beats if there is music.

## Apps
- **CapCut**: best overall (keyframes, curves, masks, free).
- **VN Video Editor**: no watermark, clean keyframes.
- **InShot**: simplest, basic zoom and transitions only.
