// UI motion-graphics transition presets for Remotion.
// Usage: import { usePreset, presets, ease } from "./transitions";
import { Easing, interpolate, useCurrentFrame } from "remotion";

export const ease = {
  out: Easing.bezier(0.22, 1, 0.36, 1), // entrances
  in: Easing.bezier(0.4, 0, 1, 1), // exits
  inOut: Easing.bezier(0.4, 0, 0.2, 1), // fade-through / blur
};

export type Preset = {
  name: string;
  durationInFrames: number; // at 60 fps: 14 frames ~ 0.23s
  // p = progress 0..1 (eased). Return CSS style for outgoing and incoming scenes.
  out: (p: number) => React.CSSProperties;
  in: (p: number) => React.CSSProperties;
};

const lerp = (a: number, b: number, p: number) => a + (b - a) * p;

export const presets: Record<string, Preset> = {
  // Navigation push with parallax: new screen slides in, old shifts back slightly.
  pushLeft: {
    name: "pushLeft",
    durationInFrames: 18,
    out: (p) => ({
      transform: `translateX(${lerp(0, -20, p)}%)`,
      opacity: lerp(1, 0.6, p),
    }),
    in: (p) => ({
      transform: `translateX(${lerp(100, 0, p)}%)`,
    }),
  },

  // Unrelated screens: old fades out, new fades in with a slight scale-up.
  fadeThrough: {
    name: "fadeThrough",
    durationInFrames: 20,
    out: (p) => ({ opacity: lerp(1, 0, Math.min(1, p * 2)) }),
    in: (p) => ({
      opacity: lerp(0, 1, Math.max(0, p * 2 - 1)),
      transform: `scale(${lerp(0.96, 1, p)})`,
    }),
  },

  // Premium blur dissolve.
  blurDissolve: {
    name: "blurDissolve",
    durationInFrames: 16,
    out: (p) => ({ opacity: 1 - p, filter: `blur(${lerp(0, 12, p)}px)` }),
    in: (p) => ({ opacity: p, filter: `blur(${lerp(12, 0, p)}px)` }),
  },

  // Zoom into a detail, then land on the next scene.
  zoomThrough: {
    name: "zoomThrough",
    durationInFrames: 18,
    out: (p) => ({ transform: `scale(${lerp(1, 1.25, p)})`, opacity: 1 - p }),
    in: (p) => ({ transform: `scale(${lerp(0.9, 1, p)})`, opacity: p }),
  },

  // Clean left-to-right wipe reveal.
  wipe: {
    name: "wipe",
    durationInFrames: 16,
    out: () => ({}),
    in: (p) => ({ clipPath: `inset(0 ${lerp(100, 0, p)}% 0 0)` }),
  },
};

// Progress (0..1) of a transition that starts at `startFrame`.
export function usePreset(
  preset: Preset,
  startFrame: number,
  easing: (t: number) => number = ease.out
) {
  const frame = useCurrentFrame();
  const raw = interpolate(
    frame,
    [startFrame, startFrame + preset.durationInFrames],
    [0, 1],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
  );
  const p = easing(raw);
  return { progress: p, outStyle: preset.out(p), inStyle: preset.in(p) };
}

// Stagger helper: delay each element by ~50ms (3 frames at 60fps).
export const stagger = (index: number, frames = 3) => index * frames;

// Pop-in with subtle overshoot (max ~5%).
export function popIn(frame: number, start: number) {
  const t = interpolate(frame, [start, start + 14], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const scale = interpolate(t, [0, 0.7, 1], [0.9, 1.05, 1]);
  return { opacity: Math.min(1, t * 2), transform: `scale(${scale})` };
}
