// Example: two UI scenes joined by a push transition. 60 fps, 1920x1080.
import { AbsoluteFill, Sequence } from "remotion";
import { presets, usePreset } from "./transitions";

const Scene: React.FC<{ title: string; color: string }> = ({ title, color }) => (
  <AbsoluteFill
    style={{
      background: color,
      color: "white",
      fontSize: 96,
      fontFamily: "Inter, sans-serif",
      alignItems: "center",
      justifyContent: "center",
    }}
  >
    {title}
  </AbsoluteFill>
);

export const Example: React.FC = () => {
  const sceneLength = 120; // 2s at 60fps
  const t = presets.pushLeft;
  const { outStyle, inStyle } = usePreset(t, sceneLength - t.durationInFrames);

  return (
    <AbsoluteFill style={{ background: "#0b0b10" }}>
      <Sequence durationInFrames={sceneLength}>
        <AbsoluteFill style={outStyle}>
          <Scene title="Home screen" color="#4f46e5" />
        </AbsoluteFill>
      </Sequence>
      <Sequence from={sceneLength - t.durationInFrames}>
        <AbsoluteFill style={inStyle}>
          <Scene title="Details screen" color="#059669" />
        </AbsoluteFill>
      </Sequence>
    </AbsoluteFill>
  );
};
