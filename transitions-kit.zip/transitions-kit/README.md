# UI Motion Transitions Kit

- `remotion/transitions.ts` : 5 presets (pushLeft, fadeThrough, blurDissolve, zoomThrough, wipe) plus stagger and popIn helpers.
- `remotion/Example.tsx` : two scenes joined with a push transition.
- `ffmpeg/join.sh` : join any number of clips with an xfade transition.
- `iPhone-guide.md` : the same transitions step by step in CapCut/VN.

## Quick start (Remotion)
1. `npx create-video@latest` (blank template), copy `remotion/` files into `src/`.
2. Register `Example` in Root.tsx with fps=60, 1920x1080, durationInFrames=222.
3. `npx remotion render Example out.mp4`

## Quick start (ffmpeg)
`chmod +x ffmpeg/join.sh && ./ffmpeg/join.sh out.mp4 smoothleft 0.4 a.mp4 b.mp4`

## Style rules
One or two transition types per video. 0.3-0.5 s. Ease-out entrances. Stagger by about 50 ms. Match audio beats.
