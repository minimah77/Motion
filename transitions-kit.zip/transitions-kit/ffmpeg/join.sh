#!/usr/bin/env bash
# Join clips with professional transitions using ffmpeg's xfade.
# Usage: ./join.sh out.mp4 [transition] [duration_seconds] clip1.mp4 clip2.mp4 [clip3.mp4 ...]
# Example: ./join.sh out.mp4 smoothleft 0.4 a.mp4 b.mp4 c.mp4
# Good transitions for UI videos: smoothleft, fadeblack, fade, circleopen, wipeleft, zoomin, dissolve
# Notes: all clips should share resolution/fps. Clips without audio are handled (video only).
set -euo pipefail

if [ "$#" -lt 5 ]; then
  sed -n '2,7p' "$0"; exit 1
fi

OUT="$1"; TRANS="$2"; DUR="$3"; shift 3
CLIPS=("$@")
N=${#CLIPS[@]}

# Probe durations
declare -a LEN
for i in "${!CLIPS[@]}"; do
  LEN[$i]=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "${CLIPS[$i]}")
done

INPUTS=()
for c in "${CLIPS[@]}"; do INPUTS+=(-i "$c"); done

FILTER=""
PREV="[0:v]"
OFFSET=0
for ((i=1; i<N; i++)); do
  OFFSET=$(awk -v o="$OFFSET" -v l="${LEN[$((i-1))]}" -v d="$DUR" 'BEGIN{printf "%.3f", o + l - d}')
  if [ $i -eq $((N-1)) ]; then LABEL="[v]"; else LABEL="[v$i]"; fi
  FILTER+="${PREV}[${i}:v]xfade=transition=${TRANS}:duration=${DUR}:offset=${OFFSET}${LABEL};"
  PREV="[v$i]"
done
FILTER=${FILTER%;}

ffmpeg -y "${INPUTS[@]}" -filter_complex "$FILTER" -map "[v]" \
  -c:v libx264 -preset veryfast -crf 18 -pix_fmt yuv420p "$OUT"
echo "Done: $OUT"
