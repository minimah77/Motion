# RECIPE: how to build the video

Source of the style: `reference/video1.mp4` (35.7 s, 16:9). Measurements are in `reference/analysis.md`. Everything below is verified from that video unless marked as our adaptation.

## 1. The look

- Typographic motion design. Flat colour stages, lots of empty space, tiny text that suddenly becomes giant cropped type.
- Stages: light `#FDFDFD`, black `#010002`, solid accent block `#2472FD`.
- Our adaptation: the reference's photo cards are replaced by the digital cards in `assets/images/cards/` (soft 3D interface cards, blue and grey). The reference's outline icon clusters are replaced by the icons in `assets/icons/`.
- Never add gradients, glow, grain, glass, gloss, liquid, mascots or robots.
- Accent: one hue per scene. Hue may change per word in the word wheel and per row in the rainbow rows.
- Text: tiny text in empty space (about 3% of frame height), then punches up to 30% of frame height, cropped by the frame.
- Type roles (our fonts, see section 4): tiny and held text in IBM Plex Sans Arabic Regular, bold lines and the wheel in Vazirmatn 700, giant punch words in Vazirmatn 900 or Lalezar. This copies the reference's contrast between small technical text and a giant grotesque. Use one pairing per video.

## 2. Scene table (25 s default, scale for 15 or 45)

| # | Time | Scene | Notes |
|---|---|---|---|
| 1 | 0.0-3.0 | Typed hook line, one accent phrase, two hairlines | word by word, never per letter |
| 2 | 3.0-6.0 | Icon clusters replace some words and cycle | clusters sit at the word positions, the kept words stay |
| 3 | 6.0-9.0 | Key word arcs in and rotates, then grows into a sentence | rotate and scale the whole word |
| 4 | 9.0-13.5 | Word wheel | fixed sentence, verbs scroll through a slot, centre word coloured, neighbours grey, decelerates |
| 5 | 13.5-18.0 | Card carousel, then dolly-in | 8 to 12 cards in 3D, push-in with riser and thud |
| 6 | 18.0-20.0 | Black title | hard cut, white text held |
| 7 | 20.0-21.5 | Accent punch | hard cut to `#2472FD`, giant white word, cropped, slides |
| 8 | 21.5-22.5 | Rainbow rows | hard cut to white, phrase repeated in different hues, one row blurred |
| 9 | 22.5-24.0 | Black stack | hard cut, key word repeated 9 to 11 rows, ghost row travels |
| 10 | 24.0-25.0 | CTA | line, keyword chip, typed comment, send press |

Each finished text stays 0.8 s or longer (1.5 s for small text). If the script needs it, move boundaries, but keep soft scenes first and hard cuts last.

## 3. Motion values

| Mechanic | Values |
|---|---|
| Typed word | 250 ms per word, 150 ms fade, 4 px rise, ease-out. Alternative: opacity 0 to 1, blur 12 to 0 px, rise 6 to 10 px, stagger 90 to 140 ms, 350 to 450 ms each |
| Hairlines | two 1 px lines in a pale accent, scaleX 0 to 1 in 500 to 700 ms, opacity 0.35 |
| Icon cycle | each slot swaps icon every 250 ms, clusters of 3 to 4 icons, drift 20 to 60 px, no blur. Icons about 2x the text height |
| Arc-in | rotate -40 to 0 degrees, scale 0.6 to 1.04 to 1, 600 to 900 ms, ease-out |
| Word wheel | about 330 ms per word, decelerating over 4 to 5 s, row pitch 1.5x font size, opacity 100% to 30% to 0 over 4 rows, centre word hue changes per word |
| Streak dissolve | text stretches and blurs vertically 30 to 60 px while fading, 500 ms. Use between wheel and cards |
| Card carousel | perspective 800 to 1200 px, rotateY about 35 degrees (the cards already have a built-in tilt, so use less than the reference's 50), rotateZ +/-8 degrees, each card drifts at its own speed, 5 to 9 cards on screen |
| Dolly-in | 2 to 4 s, ease-in, scale 1 to 2.5, Z-rotation up to 15 degrees, one or two new cards enter. Big hit at the start |
| Hard cut | 0 ms, no transition, lands on a thud |
| Giant crop | 300 to 360 px, white on accent, two lines, slight tilt, slides 80 to 120 px in 0.6 s |
| Rainbow rows | 5 rows, phrase repeated, each row its own hue and X offset, one row blurred horizontally 8 to 12 px |
| Stack | 9 to 11 rows of one word, reveal 60 ms per row, a blurred ghost row travels down about 1 row per 0.2 s |
| Final dissolve | per word random fade, never per letter |
| Held scenes | slow push-in 100 to 106% |

## 4. Persian rules (critical)

1. Never use `letter-spacing` on Persian. Never animate Persian per character. Both break the joined letters.
2. Reveal and dissolve by word, by wipe, or by a blur mask.
3. For the widely spaced stack, repeat the word in rows and vary row opacity and `scaleX`. Optionally use tatweel only between joining letters, and check the result.
4. `dir="rtl"` on Persian blocks. English words in `<span class="ltr" dir="ltr">`. The first logical word is the rightmost, so reveal right to left.
5. Fonts (8 families in `fonts/`). Persian letters پ چ ژ گ ک ی, Persian digits and « » ؟ were checked in every Persian family. Lalezar, IBM Plex Sans Arabic and Markazi Text have no ZWNJ glyph of their own, so render a still and check words like می‌کنم.
   - **Vazirmatn** (Thin 100 to Black 900, 9 weights): default Persian face. 400 body, 700 lines and the wheel, 900 punch words.
   - **IBM Plex Sans Arabic** (Thin to Bold): default for tiny held text, the closest match to the reference's small technical type.
   - **Lalezar** (one weight): display punch words, optional.
   - **Playpen Sans Arabic** (Thin to ExtraBold): playful, handwritten feel. Use for roast or fun topics.
   - **Markazi Text** (Regular to Bold): editorial serif, titles on black.
   - **Parastoo** (Regular to Bold): friendly text face for longer lines.
   - **Lora** and **Nanum Myeongjo**: Latin only, no Persian letters. English words and numbers only, wrapped in `<span class="ltr" dir="ltr">`.
   - There is no Persian monospace, so use weight and family contrast instead.
   - Load with `@font-face` relative to your HTML, for example `src:url(../../fonts/Vazirmatn/static/Vazirmatn-Bold.ttf)`. Only load the weights you use.
6. Persian punctuation: « » ؟ ؛ and a normal full stop. Check ZWNJ in words like می‌کنم، بقیه‌ش، نمی‌دونم.
7. Colloquial, modern, short. 8 lines, at most 8 words each. Line 1 is a hook, the last line is the CTA, one emphasised word per line.
8. Render a still after every text change and look for broken joins and clipped letters.

## 5. Transitions

Rank by fit, never the same type twice in a row, 250 to 500 ms unless it is a hard cut.

1. Blur or streak dissolve (reference at 16 s). 2. Hard cut on a bass hit (reference 26 to 33 s). 3. Scale-through. 4. Whip-pan. 5. Screen-cover in the accent colour. 6. Masked typography reveal. 7. White flash.

Early scenes soft, late scenes hard.

## 6. Cards and icons: how to use them

- Draw each card as a square `<img>` with hard corners on its pale plate. Do not round the corners and do not add a CSS shadow. The image already has its shadow.
- Pick cards that match the topic (see the table in `ASSETS.md`). Fewer than 8 cards is fine, repeat with different sizes and speeds.
- Do not stretch cards. Keep them square.
- Icons: pick 12 to 16 that match the script words. Cluster of 3 or 4 per replaced word. On black use `filter: invert(1)`.
- Never put text inside a card image. Add text in code if needed.

## 7. Sound plan

Each sound has one job. Never put a whoosh on everything. Sounds come from `scripts/sfx_soft.py`.

| Moment | Sound |
|---|---|
| each typed word | `key`, quiet, slightly different gain each time |
| each icon swap (not every one, about every second swap) | `pop`, quiet |
| arc-in start | `swish` |
| wheel words | `tick` on every word, spacing grows as the wheel slows |
| wheel landing | `ding` |
| 1.5 s before the dolly | `riser` |
| dolly start | `thud`, the loudest sound in the video |
| each hard cut (scenes 6, 7, 8, 9) | `thud`, softer than the dolly. Scene 8 may use `glitch` instead |
| stack rows | `type`, very quiet |
| CTA button | `press`, then `chime` |

Bed (optional `--bed`): quiet pad, bassier after the midpoint, near silence for the 0.5 s before the dolly hit.

Targets: about -16 LUFS integrated, true peak -1 dBFS or lower. Check with `ffmpeg -i output/video.mp4 -af ebur128=peak=true -f null -`.

## 8. Pipeline

1. Write `index.html` (1920x1080) in a new folder, for example `output/my_video/`. Three layers: background, DOM text layer with `dir="rtl"`, a top canvas for transition overlays.
2. Expose `window.loadAll()` (await `document.fonts.ready` and decode all images) and `window.render(t)` (synchronous, deterministic, no `setTimeout`, no CSS animations).
3. Keep a scene table `{start, end, update(localT)}` and a transition table keyed to scene boundaries.
4. Render stills at each scene midpoint and boundary:
   `python3 scripts/render.py output/my_video/index.html --duration 25 --stills 0.5,2.5,4.5,7,11,15,17,19,20.5,22,23.5,24.8 --out output/stills`
5. Look at every still. Fix joins, clipping, overlaps, margins (at least 90 px except intentional crops).
6. Write `cues.json` for the sound plan, then:
   `python3 scripts/sfx_soft.py mix output/my_video/cues.json --duration 25 --bed --out output/audio.wav`
7. Render:
   `python3 scripts/render.py output/my_video/index.html --duration 25 --audio output/audio.wav --out output/my_video.mp4`
8. Check loudness, duration, resolution, then deliver.

Minimal engine shape to follow:

```html
<div id="stage"> <div id="bg"></div> <div id="txt" dir="rtl"></div> <canvas id="fx" width="1920" height="1080"></canvas> </div>
<script>
const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
const easeOut=x=>1-Math.pow(1-clamp(x),3), easeIn=x=>clamp(x)**3, easeIO=x=>x<.5?4*x**3:1-Math.pow(-2*x+2,3)/2;
const scenes=[ {s:0,e:3,update(l,t){/* typed hook */}}, /* ... one per row of the scene table */ ];
window.loadAll=async()=>{ await document.fonts.ready; await Promise.all([...document.images].map(i=>i.decode().catch(()=>{}))); };
window.render=t=>{ const sc=scenes.find(x=>t>=x.s&&t<x.e)||scenes.at(-1); sc.update(t-sc.s,t); };
</script>
```

## 9. Quality checklist

- Persian joins intact, RTL punctuation correct, ZWNJ words checked
- Nothing clipped except intentional giant crops
- Colours match the system in `ASSETS.md`
- Every text visible 0.8 s or longer
- No transition type twice in a row
- No gradients, glow, grain, glass, liquid, mascots
- Audio about -16 LUFS, true peak -1 dBFS or lower
- Length 45 s or less
- No words or images copied from the reference video
