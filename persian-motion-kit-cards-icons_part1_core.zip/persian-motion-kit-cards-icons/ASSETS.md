# ASSETS

All paths are relative to the kit root. Names are fixed so prompts and code never have to guess.

## Colour system

| Token | Value | Use |
|---|---|---|
| light stage | `#FDFDFD` | main background |
| black stage | `#010002` | hard-cut title and stack scenes |
| accent block | `#2472FD` | punch scene, accent words (swap per topic) |
| card plate | `#E6E6E6` | pale square behind each card |
| muted grey | `#C8C8C8` | wheel neighbours |
| icon ink | `#141010` | icon line colour |
| rainbow hues | green `#00D68F`, blue `#2472FD`, magenta `#C040E0`, purple `#7B4DFF`, pink `#F0607A`, orange `#FF9A1F` | word wheel centre word, rainbow rows |

## Cards (12 present)

Soft 3D white interface cards in blue and grey, floating with a faint shadow on a pale grey square. No readable text in any card, so they work for any topic. Each is 1254x1254 PNG, opaque (re-saved losslessly, pixels unchanged).

| File | Shows | Good for topics about |
|---|---|---|
| `assets/images/cards/card_01_download.png` | download card at 80% | files, resources, free downloads, lead magnets |
| `assets/images/cards/card_02_dashboard.png` | browser dashboard with line and bar charts | analytics, growth, results, business |
| `assets/images/cards/card_03_book.png` | book with blue shape cover | ebooks, learning, guides, courses |
| `assets/images/cards/card_04_social.png` | social post with replies | content, community, social media, comments |
| `assets/images/cards/card_05_pages.png` | three layered page layouts | newsletters, documents, design, templates |
| `assets/images/cards/card_06_folder.png` | blue folder with PDF, image, sheet, doc, zip | files, organising, bundles, resources |
| `assets/images/cards/card_07_phone.png` | phone app with list rows and button | apps, mobile, tools, settings |
| `assets/images/cards/card_08_notification.png` | bell notification bar | reminders, alerts, news, updates |
| `assets/images/cards/card_09_checklist.png` | window with checked list | tasks, habits, planning, productivity |
| `assets/images/cards/card_10_chat.png` | chat window with send button | AI chat, support, messaging, prompts |
| `assets/images/cards/card_11_spreadsheet.png` | spreadsheet with chart | data, finance, tracking, tables |
| `assets/images/cards/card_12_document.png` | document with highlighted block | writing, notes, reports, contracts |

## Icon sheets (3 present) and sliced icons (48)

Black rounded line icons on white, 4x4 per sheet. Sheets are stored as 8-bit grayscale PNG. Sliced files are `assets/icons/icon_<name>.png`, 384x384 transparent, black line. Order is row by row, left to right.

| Sheet | Row 1 | Row 2 | Row 3 | Row 4 |
|---|---|---|---|---|
| `icons_sheet_A.png` | lightbulb, sparkle, robot, code | terminal, clipboard, checklist, chart_up | calendar, bell, gear, cursor | hand_pointer, play, pencil, plus |
| `icons_sheet_B.png` | money, database, cart, gift | tag, target, rocket, trophy | clock, hourglass, brain, thumbs_up | chat_dots, eye, gift_2, key |
| `icons_sheet_C.png` | file, pdf, download, cloud | link, folder, image, video | mail, chat, search, bookmark | star, heart, lock, share |

Colouring icons in code: on a black stage use CSS `filter: invert(1)`. For an accent colour use `background:#2472FD; mask:url(icon.png) center/contain no-repeat`.

## Built in code, no image needed

Stage colours, hairlines, word wheel, text stacks, rainbow rows, chips, comment bar, typed comment, send button, cursor (use `assets/icons/icon_cursor.png`). Draw these in CSS or SVG. They are not missing assets.

## Fonts (8 families present, in `fonts/`)

Static TTF only, one `OFL.txt` licence per family. Variable-font duplicates were left out, the static files cover every weight.

| Family | Folder | Script | Weights | Default role |
|---|---|---|---|---|
| Vazirmatn | `fonts/Vazirmatn/static/` | Persian, Latin | Thin, ExtraLight, Light, Regular, Medium, SemiBold, Bold, ExtraBold, Black | main Persian face, punch at Black |
| IBM Plex Sans Arabic | `fonts/IBM_Plex_Sans_Arabic/` | Persian, Arabic, Latin | Thin, ExtraLight, Light, Regular, Medium, SemiBold, Bold | tiny held text |
| Lalezar | `fonts/Lalezar/` | Persian, Latin | Regular | optional display punch |
| Playpen Sans Arabic | `fonts/Playpen_Sans_Arabic/static/` | Persian, Arabic, Latin | Thin to ExtraBold (8) | playful topics |
| Markazi Text | `fonts/Markazi_Text/static/` | Persian, Arabic, Latin | Regular, Medium, SemiBold, Bold | editorial titles |
| Parastoo | `fonts/Parastoo/static/` | Persian, Latin | Regular, Medium, SemiBold, Bold | longer lines |
| Lora | `fonts/Lora/static/` | Latin only | Regular, Medium, SemiBold, Bold, plus italics | English words and numbers |
| Nanum Myeongjo | `fonts/Nanum_Myeongjo/` | Latin and Korean | Regular, Bold, ExtraBold | optional Latin display |

## Not part of this style

Gradients, glow, grain, glass, liquid, gloss, caustics, mascots, robots, green-screen cutouts. The reference does not use them. Do not add them.

## Missing, optional

| Item | Status | Note |
|---|---|---|
| Voiceover | not included | your own recording or vidIQ voice, passed to the mix step |
| More cards | optional | prompts below |
| Cursor | use `assets/icons/icon_cursor.png` | invert for white on black |

## Prompts to make more cards (same family as the 12)

Use one new chat per set so the style stays consistent. Attach two existing cards as style references.

```
A single soft 3D white user-interface card floating at a slight tilt on a flat pale grey (#E6E6E6) square plate, with a very faint soft shadow below it. Subject: {SUBJECT, e.g. a calendar with three highlighted days}. Only abstract grey bars stand in for text. One accent colour: blue (#2472FD). Clean, minimal, premium, soft diffused light from the top left. Square 1:1, 1254x1254. No readable text, no letters, no numbers, no logo, no watermark, no brand names, no gradients in the background.
```

Subjects that fit the set and are not made yet: calendar, video player, email inbox, shopping cart, settings panel, map pin card, profile card, payment card, stats badge, code window.

## Prompt to make more icons (same family as the 3 sheets)

```
A 4x4 grid of 16 rounded line icons on a pure white background, evenly spaced with generous margins: {16 NAMES}. Uniform stroke about 3 px, black, rounded caps and joins, identical visual weight and size, flat, no fill, no shadow, no gradient. Landscape 3:2, 1536x1024. No text, no letters, no numbers, no logo, no watermark.
```

Save as `icons_sheet_D.png`, add its 16 names to `SHEETS` in `scripts/slice_icons.py`, and run the script. Keep icons from touching cell edges.

## Tick list

- [x] 12 cards, fixed names
- [x] 3 icon sheets
- [x] 48 sliced icons and manifest
- [x] reference video and frames
- [x] fonts in `fonts/` (8 families)
- [ ] optional extra cards and icons
