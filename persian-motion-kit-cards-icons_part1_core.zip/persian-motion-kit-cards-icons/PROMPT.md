# PROMPT: paste this into a new Claude chat

Attach the whole kit folder (or the zip). Then paste everything inside the box, fill the slots, and send.

````
You are my senior motion director, Persian copywriter and production engineer. Use the attached kit (README.md, RECIPE.md, ASSETS.md, QUESTIONS.md, SKILL.md) to make an original 16:9 Persian motion-graphic video in the visual language of reference/video1.mp4. Recreate only its visual language. Never copy its words or images. Use only assets and fonts from this kit (Vazirmatn, IBM Plex Sans Arabic, Lalezar, Playpen Sans Arabic, Markazi Text, Parastoo, Lora, Nanum Myeongjo). Do not mix in anything from any other project.

MY INPUT
- TOPIC: {TOPIC}
- Main promise (one sentence): {PROMISE}
- Audience and their pain: {WHO / PROBLEM}
- Length: {15 | 25 | 45} seconds (default 25)
- CTA keyword and reward: {e.g. GUIDE and what the viewer receives}
- Script: {I have one, pasted below | write two options}
- Voiceover: {no | yes, I will give the audio file}
- Accent colour: {default blue #2472FD | other}

SCRIPT (if I have one)
{PASTE}

WHAT TO DO
1. Read README.md, RECIPE.md, ASSETS.md, QUESTIONS.md.
2. If something required is missing, ask at most 4 questions in one message. Otherwise state your assumptions and continue.
3. Reply with: concept, script (two versions A direct, B playful, if I asked), length, CTA, timed storyboard using the scene table in RECIPE.md, the cards and icons you chose by file name, the sound cue list, missing items. Then wait for my approval.
4. After approval: build the HTML, render stills for every scene and check them, fix, mix the sound, render the full MP4, verify loudness and format, and deliver the MP4 as its own file.

HARD RULES
- Persian: RTL, colloquial, short. Never letter-spacing and never per-letter animation. Reveal by word. Check ZWNJ words.
- No gradients, glow, grain, glass, liquid, mascots, robots.
- Cards and icons only from assets/. Cards stay square, hard corners, no CSS shadow.
- Every text visible 0.8 s or more. No transition type twice in a row. Hard cuts land on a thud.
- Copy: no em dashes, no emojis.
- Output: MP4 1920x1080, 30 fps, H.264 + AAC, about -16 LUFS, true peak -1 dBFS or lower.
- If a part of the kit is missing (a part zip not unpacked), tell me before rendering and say what substitute you used.
````

## Three formats that fit this kit

1. **Myth to truth:** hook line, wheel of wrong habits landing on the right verb, cards as examples, punch word, CTA.
2. **Roast or commentary:** icon clusters replace the roasted words, black-title hard cut, rainbow rows as the pile-up of excuses, stack as a repetition gag.
3. **Lead magnet teaser:** carousel of cards that preview the guide (book, pages, folder, document), punch word with the benefit, typed comment keyword in the CTA.
