#!/usr/bin/env python3
"""Deterministic HTML -> MP4 renderer (Playwright + ffmpeg).

Contract for the page you render:
  window.loadAll()  -> Promise, loads fonts and images before frame 0
  window.render(t)  -> draws the page at time t (seconds), synchronously, no timers

Examples (run from the kit root):
  python3 scripts/render.py my_video/index.html --duration 25 --stills 0.5,3,9,14,19 --out output/stills
  python3 scripts/render.py my_video/index.html --duration 25 --audio output/audio.wav --out output/video.mp4
"""
import argparse, os, subprocess, sys, shutil
from playwright.sync_api import sync_playwright

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html")
    ap.add_argument("--duration", type=float, default=25.0)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--height", type=int, default=1080)
    ap.add_argument("--audio", default=None, help="wav/mp3 to mux")
    ap.add_argument("--out", default="output/video.mp4", help="mp4 path, or a folder when --stills is used")
    ap.add_argument("--stills", default=None, help="comma list of seconds; writes PNGs instead of video")
    ap.add_argument("--crf", type=int, default=18)
    a = ap.parse_args()

    url = "file://" + os.path.abspath(a.html)
    with sync_playwright() as p:
        b = p.chromium.launch(args=["--font-render-hinting=none", "--allow-file-access-from-files"])
        pg = b.new_page(viewport={"width": a.width, "height": a.height}, device_scale_factor=1)
        logs = []
        pg.on("console", lambda m: logs.append(m.text))
        pg.on("pageerror", lambda e: logs.append("PAGE ERROR: " + str(e)))
        pg.goto(url)
        pg.evaluate("window.loadAll ? window.loadAll() : null")
        pg.wait_for_timeout(300)

        if a.stills:
            os.makedirs(a.out, exist_ok=True)
            for ts in a.stills.split(","):
                t = float(ts)
                pg.evaluate("t => window.render(t)", t)
                f = os.path.join(a.out, f"still_{t:07.3f}.png")
                pg.screenshot(path=f)
                print("wrote", f)
        else:
            if not shutil.which("ffmpeg"):
                sys.exit("ffmpeg not found")
            os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
            cmd = ["ffmpeg", "-y", "-loglevel", "error", "-framerate", str(a.fps),
                   "-f", "image2pipe", "-vcodec", "png", "-i", "-"]
            if a.audio:
                cmd += ["-i", a.audio]
            cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", str(a.crf), "-pix_fmt", "yuv420p"]
            if a.audio:
                cmd += ["-c:a", "aac", "-b:a", "192k", "-shortest"]
            cmd += ["-movflags", "+faststart", a.out]
            ff = subprocess.Popen(cmd, stdin=subprocess.PIPE)
            n = int(round(a.duration * a.fps))
            for i in range(n):
                pg.evaluate("t => window.render(t)", i / a.fps)
                ff.stdin.write(pg.screenshot(type="png"))
                if i % a.fps == 0:
                    print(f"frame {i}/{n}", end="\r", flush=True)
            ff.stdin.close(); ff.wait()
            print(f"\nwrote {a.out}")
        for l in logs:
            print("[page]", l)
        b.close()

if __name__ == "__main__":
    main()
