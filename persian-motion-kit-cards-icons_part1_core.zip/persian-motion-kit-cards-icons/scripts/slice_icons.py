#!/usr/bin/env python3
"""Slice the three 4x4 icon sheets into 48 transparent PNGs (black line, 384x384).

Usage: python3 scripts/slice_icons.py            (run from the kit root)
Output: assets/icons/<name>.png and assets/icons/manifest.json
"""
import json, os, sys
from PIL import Image
import numpy as np
from scipy import ndimage

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHEETS = {
    "icons_sheet_A.png": ["lightbulb","sparkle","robot","code",
                          "terminal","clipboard","checklist","chart_up",
                          "calendar","bell","gear","cursor",
                          "hand_pointer","play","pencil","plus"],
    "icons_sheet_B.png": ["money","database","cart","gift",
                          "tag","target","rocket","trophy",
                          "clock","hourglass","brain","thumbs_up",
                          "chat_dots","eye","gift_2","key"],
    "icons_sheet_C.png": ["file","pdf","download","cloud",
                          "link","folder","image","video",
                          "mail","chat","search","bookmark",
                          "star","heart","lock","share"],
}
OUT = os.path.join(ROOT, "assets", "icons")
SIZE = 384
os.makedirs(OUT, exist_ok=True)
manifest = {}
for sheet, names in SHEETS.items():
    im = Image.open(os.path.join(ROOT, "assets", "images", "icon_sheets", sheet)).convert("L")
    W, H = im.size
    cw, ch = W // 4, H // 4
    for i, name in enumerate(names):
        r, c = divmod(i, 4)
        M = 32  # margin so icons that spill over a cell edge stay whole
        x_a, y_a = max(0, c * cw - M), max(0, r * ch - M)
        x_b, y_b = min(W, (c + 1) * cw + M), min(H, (r + 1) * ch + M)
        cell = np.asarray(im.crop((x_a, y_a, x_b, y_b)), dtype=np.float32)
        alpha = np.clip((255.0 - cell) / 255.0 * 1.15, 0, 1)
        mask = ndimage.binary_dilation(alpha > 0.35, iterations=8)
        lab, n = ndimage.label(mask)
        keep = np.zeros_like(mask)
        for k in range(1, n + 1):
            cy, cx = ndimage.center_of_mass(lab == k)
            gx, gy = cx + x_a, cy + y_a
            if c * cw <= gx < (c + 1) * cw and r * ch <= gy < (r + 1) * ch:
                keep |= lab == k
        alpha = alpha * keep
        ys, xs = np.where(alpha > 0.35)
        if len(xs) == 0:
            print("empty cell", sheet, name, file=sys.stderr); continue
        y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        crop = alpha[y0:y1, x0:x1]
        h, w = crop.shape
        scale = (SIZE * 0.78) / max(h, w)
        nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
        a = Image.fromarray((crop * 255).astype(np.uint8)).resize((nw, nh), Image.LANCZOS)
        canvas = Image.new("RGBA", (SIZE, SIZE), (20, 16, 16, 0))
        black = Image.new("RGBA", (nw, nh), (20, 16, 16, 255))
        black.putalpha(a)
        canvas.paste(black, ((SIZE - nw) // 2, (SIZE - nh) // 2), black)
        fn = f"icon_{name}.png"
        canvas.save(os.path.join(OUT, fn))
        manifest[name] = {"file": f"assets/icons/{fn}", "sheet": sheet, "row": r + 1, "col": c + 1}
with open(os.path.join(OUT, "manifest.json"), "w") as f:
    json.dump(manifest, f, indent=2)
print(f"wrote {len(manifest)} icons to {OUT}")
