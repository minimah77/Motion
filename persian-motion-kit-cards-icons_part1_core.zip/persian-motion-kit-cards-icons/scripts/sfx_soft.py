#!/usr/bin/env python3
"""Synthesised SFX library and cue mixer (numpy + scipy only, no downloads).

  python3 scripts/sfx_soft.py library output/sfx            # writes one wav per sound
  python3 scripts/sfx_soft.py mix cues.json --duration 25 --out output/audio.wav [--bed]

cues.json: [{"t": 0.30, "sfx": "key", "gain": 0.8}, ...]  (t in seconds)
Sounds: key tick pop thud riser glitch swish ding press chime type
Rule: each sound has one job. Use thud only on hard cuts and the dolly hit, ding only on a landing,
chime only on success. Do not put a whoosh on everything.
"""
import json, sys, argparse, subprocess, os
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

SR = 44100
rng = np.random.default_rng(7)

def t_(d): return np.arange(int(SR * d)) / SR
def env(n, a=0.002, r=0.05):
    e = np.ones(n); na, nr = max(1, int(a * SR)), max(1, int(r * SR))
    e[:na] = np.linspace(0, 1, na); e[-nr:] *= np.linspace(1, 0, nr); return e
def hp(x, f): return sosfilt(butter(2, f / (SR / 2), "high", output="sos"), x)
def lp(x, f): return sosfilt(butter(2, f / (SR / 2), "low", output="sos"), x)
def bp(x, lo, hi): return sosfilt(butter(2, [lo / (SR / 2), hi / (SR / 2)], "band", output="sos"), x)
def decay(t, k): return np.exp(-t * k)

def key():   t = t_(0.08); return hp(rng.standard_normal(len(t)), 2500) * decay(t, 70) * 0.5 + np.sin(2*np.pi*1800*t) * decay(t, 90) * 0.25
def tick():  t = t_(0.05); return np.sin(2*np.pi*3200*t) * decay(t, 140) * 0.5
def pop():   t = t_(0.14); f = 520 * np.exp(-t * 12) + 180; return np.sin(2*np.pi*np.cumsum(f)/SR) * decay(t, 28) * 0.8
def thud():
    t = t_(0.9); f = 38 + 70 * np.exp(-t * 18)
    s = np.sin(2*np.pi*np.cumsum(f)/SR) * decay(t, 4.5)
    n = lp(rng.standard_normal(len(t)), 400) * decay(t, 30) * 0.5
    return np.tanh((s + n) * 1.6) * 0.95
def riser(d=1.5):
    t = t_(d); f = 200 * (2 ** (t / d * 3)); n = hp(rng.standard_normal(len(t)), 1500) * (t / d) ** 2
    s = np.sin(2*np.pi*np.cumsum(f)/SR) * (t / d)
    return (0.5 * s + 0.35 * n) * env(len(t), 0.05, 0.02)
def glitch():
    t = t_(0.28); x = np.zeros(len(t))
    for st in (0, .05, .11, .16, .21):
        i = int(st * SR); n = int(0.04 * SR); x[i:i+n] += np.sign(np.sin(2*np.pi*rng.uniform(300, 2200)*t[:n])) * 0.3 * decay(t[:n], 40)
    return bp(x, 400, 6000)
def swish():
    t = t_(0.35); n = bp(rng.standard_normal(len(t)), 800, 6000)
    return n * np.sin(np.pi * t / 0.35) ** 2 * 0.45
def ding():
    t = t_(0.9); return (np.sin(2*np.pi*1568*t) + 0.4*np.sin(2*np.pi*3136*t)) * decay(t, 6) * 0.35
def press():
    t = t_(0.12); return (np.sin(2*np.pi*140*t) * decay(t, 45) + hp(rng.standard_normal(len(t)), 2000) * decay(t, 90) * 0.3) * 0.8
def chime():
    t = t_(1.2); x = sum(np.sin(2*np.pi*f*t) * decay(t, 4 + i) * a for i, (f, a) in enumerate([(1046, .4), (1318, .3), (1568, .3)]))
    return x * 0.6
def typek():
    t = t_(0.06); return hp(rng.standard_normal(len(t)), 3000) * decay(t, 110) * 0.35

LIB = {"key": key, "tick": tick, "pop": pop, "thud": thud, "riser": riser, "glitch": glitch,
       "swish": swish, "ding": ding, "press": press, "chime": chime, "type": typek}

def bed(duration):
    """Quiet pad that gets bassier toward the end. Optional."""
    t = t_(duration); x = np.zeros_like(t)
    x += np.sin(2*np.pi*110*t) * 0.05 + np.sin(2*np.pi*165*t) * 0.03
    x += np.sin(2*np.pi*55*t) * 0.06 * np.clip((t - duration * 0.45) / (duration * 0.3), 0, 1)
    return x * np.clip(t / 2, 0, 1) * np.clip((duration - t) / 1.0, 0, 1)

def mix(cues, duration, with_bed=False):
    out = np.zeros(int(SR * duration) + SR)
    if with_bed: out[:int(SR * duration)] += bed(duration)
    for c in cues:
        s = LIB[c["sfx"]]() * float(c.get("gain", 1.0))
        i = int(c["t"] * SR); out[i:i+len(s)] += s[:len(out) - i]
    out = np.tanh(out * 1.1)                               # soft clip
    out = out[:int(SR * duration)]
    out /= max(1e-9, np.abs(out).max()); out *= 0.84       # peak ~ -1.5 dBFS so true peak stays under -1
    return out

def measure(path):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", path, "-af", "ebur128=peak=true", "-f", "null", "-"],
                       capture_output=True, text=True).stderr
    tail = r[r.rfind("Summary"):] if "Summary" in r else r[-400:]
    print(tail)

def main():
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    l = sub.add_parser("library"); l.add_argument("outdir")
    m = sub.add_parser("mix"); m.add_argument("cues"); m.add_argument("--duration", type=float, default=25)
    m.add_argument("--out", default="output/audio.wav"); m.add_argument("--bed", action="store_true")
    a = ap.parse_args()
    if a.cmd == "library":
        os.makedirs(a.outdir, exist_ok=True)
        for k, fn in LIB.items():
            s = fn(); s = s / max(1e-9, np.abs(s).max()) * 0.89
            wavfile.write(os.path.join(a.outdir, f"{k}.wav"), SR, (s * 32767).astype(np.int16)); print("wrote", k)
    else:
        cues = json.load(open(a.cues)); y = mix(cues, a.duration, a.bed)
        os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
        wavfile.write(a.out, SR, (y * 32767).astype(np.int16)); print("wrote", a.out); measure(a.out)

if __name__ == "__main__":
    main()
