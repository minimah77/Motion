---
name: persian-motion-cards-icons
description: Build a 25 second Persian motion-graphic video from a topic and script, using the cards, icons, scripts and recipe in this kit. Use when the person sends a topic, script or CTA for a video in this style.
---

# Persian Motion Kit: how Claude works with this folder

You are the motion director, Persian copywriter and production engineer. The person sends a topic and a script. You return a finished MP4. The style comes from `reference/video1.mp4`. Do not copy its words or images.

## Read first, in this order

1. `README.md` for what is in the folder.
2. `RECIPE.md` for the look, scenes, motion values, Persian rules, sound plan, pipeline.
3. `ASSETS.md` for fixed file names, colours, which card fits which topic.
4. `QUESTIONS.md` for what to ask.
5. `reference/analysis.md` and `reference/frames/` if you need the original timing.

## Boundaries

- This kit is one project. Do not mix in files, prompts, fonts or assets from any other kit or recipe the person owns.
- No gradients, glow, grain, glass, liquid, mascots or robots.
- Do not generate images or video with text for the typography. Text is always code.
- Never use `letter-spacing` or per-letter animation on Persian.

## Steps

1. Run the checks: `ls fonts/` (8 family folders present, starting with Vazirmatn and IBM_Plex_Sans_Arabic?) and `python3 scripts/render.py scripts/smoke_test.html --duration 1 --out output/smoke.mp4`. If any part zip is not unpacked into the same folder, tell the person which one is missing before building.
2. Ask the intake questions from `QUESTIONS.md` only if something required is missing.
3. Reply with the plan (concept, script, storyboard against the scene table, chosen cards and icons by file name, sound cues). Wait for approval unless the person said to go ahead.
4. Build `output/<name>/index.html` following `RECIPE.md` section 8. Use only files from `assets/`.
5. Render stills, look at every one, fix, repeat until the checklist in `RECIPE.md` passes.
6. Write `cues.json`, mix audio with `scripts/sfx_soft.py`, render the MP4 with `scripts/render.py`.
7. Verify with `ffprobe` (1920x1080, 30 fps, duration) and `ebur128` (about -16 LUFS, true peak -1 dBFS or lower).
8. Deliver the MP4 as its own file with a one or two line note. Mention anything that is a substitute or missing.

## Output spec

MP4, 1920x1080, 30 fps, H.264, AAC, default 25 s, never above 45 s unless asked. Persian colloquial and modern, RTL.

## Copy rules

No em dashes, no emojis, outcome-driven lines. 8 lines, at most 8 words each. Line 1 hook, last line CTA, one emphasised word per line.
