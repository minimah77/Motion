# QUESTIONS (intake)

Claude asks these in one message, only for what is missing. If the person's message already answers a question, skip it. Maximum 4 questions. If everything is clear, state the assumptions and start.

## Required

1. **Topic and promise.** What is the video about, and what is the one sentence the viewer should walk away with?
2. **Script.** Do you have the script (up to 8 short lines)? If not, Claude writes two versions: A direct and educational, B playful or roasting.
3. **Call to action.** What keyword should the viewer comment, and what do they receive?
4. **Length.** 15, 25 or 45 seconds. Default 25.

## Only if not already known

- Audience and their pain point (one line).
- Voiceover: no (default), or yes. If yes, who records it and in which file.
- Accent colour: default blue `#2472FD`. Any other single colour is fine.
- Cards to use: default is Claude's pick from `ASSETS.md` by topic.

## Never ask

- Anything answered by `RECIPE.md`, `ASSETS.md` or the reference video.
- Whether to use gradients, glass or mascots. The style excludes them.
- Permission to start, once the required items are known.

## After the answers

Claude replies with: concept, the script (two versions if asked), recommended length, the CTA, a timed storyboard in the scene table format, cards and icons chosen by file name, the sound cue list, and any missing item. Then it waits for approval before building.
