# Reference Video Analysis (13 sections)

**How this was analysed.** I could not "watch" the video live. I extracted frames (1 fps overview, 4 fps for 0–6 s, 2 fps for 16–26 s, 3 fps for 29–35.7 s), ran scene-cut detection, sampled exact pixel colours, and measured the audio (loudness, envelope, onsets, spectral centroid). Contact sheets (JPEG) are in `reference/frames/`.
**Labels:** **[C]** confirmed from frames/measurements · **[E]** strong estimate · **[L]** low-confidence guess.
Timestamps are accurate to about ±0.3 s (±1 s where I only had 1 fps).

> **Important correction to the earlier brief:** the video has NO meadow, laptop, robot, glass cards, liquid-gradient finale, grain, or comment-bar CTA. It is typographic motion design plus a 3D-looking card carousel. Everything below describes what is really there.

---

## 1. VIDEO OVERVIEW

| Item | Finding |
|---|---|
| Type / genre | Kinetic-typography / motion-graphics piece, art-and-design-institution feel [E]. A poetic text sequence, not a tutorial or ad. |
| Aspect ratio | 16:9 (1276×720 file) [C] |
| Duration / FPS | 35.73 s, 25 fps [C] |
| Platform | Unknown. 16:9 suggests a website, portfolio, YouTube or event screen rather than Reels/TikTok [L] |
| Editing style | Slow, soft word-by-word reveals and dissolves early, then hard cuts in the last 10 s that land on bass hits [C] |
| Audience | Design-literate viewers [E]. The German text suggests a typography/art context [L]. |
| Atmosphere | Calm, clinical, gallery-white; ends loud and graphic (black, saturated blue, rainbow) [C] |
| Source | Not AI-generated footage. All typography is flat graphics; the cards are 2D images in 3D space [E]. |

## 2. COMPLETE TIMELINE

Timings from frame sampling; "Cut" = detected scene change (26.12, 27.56, 28.56, 29.16, 29.76, 30.96, 33.16 s).

| Time | On screen | Text / type | Camera | Object motion | Transition | Effect | Sound [E from envelope] | Dur. |
|---|---|---|---|---|---|---|---|---|
| 0.0–0.25 | Blank near-white | none | static | none | – | – | tiny tick at 0.1–0.2 s | 0.25 s |
| 0.25–1.5 | Small mono line "Design is like a game," typed word by word, ~0.25 s per word | ~20 px mono, black; "is like" then "game," in pale blue | static | each word fades/pops in | – | Two 1-px pale-blue hairlines draw across at the text's top and bottom edges | light ticks (centroid ≈ 3 kHz = bright clicks) | 1.25 s |
| 1.5–2.2 | Same line holds, nudges down | same | static | line drifts ~20 px | soft | hairlines fade | quiet | 0.7 s |
| 2.2–5.0 | Words "Design", "is", "a", "game" are replaced by clusters of 3–4 bold outline icons (heart, paperclip, lightbulb, speech bubble, folder, pencil, arrow, sparkle, smiley, hourglass, cup, gear); "like" stays | icons ~22 px, 2.5 px stroke | static | clusters pop in at word positions, **cycle every ~0.25 s** (slot-machine style), drift to new positions, ~3 rows | cross-pop | none | irregular pops | 2.8 s |
| 4.7–6.0 | "play." fades in beside "like"; icon clusters thin out | "like to play." | static | icons exit | fade | – | build begins | 1.3 s |
| 6–8 | "and I like to play." → "to play." scales up (~1.6×) | larger mono, black | static | scale-up, text slides to centre | morph | – | loudness rising | 2 s |
| 8–9.5 | "to play" bends on an arc and rotates (~−40° to 0°); "to" sits low-left, "play." upper-right | mono ~40 px | static | arc path, rotation | morph | – | **energy peak ≈ 8–9 s** (rms ×10 vs start) | 1.5 s |
| 9.5–11.5 | "to play" settles flat, then grows into "to play is to resist stasis." | mono | static | width expands | – | – | sustained | 2 s |
| 11.5–16.3 | **Word wheel:** fixed sentence "to ___ is to resist stasis." Verbs scroll vertically through the slot (ask, build, dream, wander, create, play, push, fail, collide, burn, spark, dare, seek, break). Centre word is coloured (green → blue → magenta → purple → blue), neighbours light grey, 4–5 words visible each side | mono ~26 px | static | vertical scroll ~3 words/s decelerating, colour swaps per word | – | neighbours fade with distance | steady ticks | 4.8 s |
| 16.0–16.6 | Sentence smears into a vertical streak of faint text (blur) | ghosted text | – | text dissolves | **blur/streak dissolve** | heavy vertical motion blur | – | 0.6 s |
| 16.5–21.5 | **Card carousel:** ~8 pale-grey square cards (photos/3D renders: pink poster "YOUTH FOR ART", blue book, bunny sticker, laptop-in-hands, brown sign, signage), arranged in a ring/3D row, rotating in Y with perspective | none | static/slow | cards drift laterally, skew, overlap, slightly different speeds (parallax) | – | none visible | low steady bed; dip at 18–21 s | 5 s |
| 21.5–25.5 | **Camera dolly-in:** cards scale up 2–3×, Z-rotate ±15°, new cards enter (floral card "1", phone, plant, helmet, device, pattern poster); a stray black italic "A" flies across | "A" ~40 px | push-in | cards fly toward camera | continuous | – | **loudest hit ≈ 22.2 s** (rms 0.40, ~3× the surrounding sound), then low drone | 4 s |
| 26.12–28.5 | Hard cut to **pure black**; "Alles Lebendige" in white mono, centred, held | ~28 px | static | none | **hard cut** | – | hit at 26.0–26.1 s, then bass | 2.4 s |
| 28.56–29.16 | Cut to white: single word "offenbart" huge, black mono, bottom-left, cropped by frame | ~110 px mono | static | none | hard cut | – | – | 0.6 s |
| 29.16–29.76 | Cut to **solid blue (#2472FD)**: giant white word "durch" in a grotesque sans, repeated on two lines, cropped, tilted slightly, sliding | ~230 px | static | slide + crop | hard cut | – | hit ≈ 29.5 s | 0.6 s |
| 29.76–30.96 | Cut to white **rainbow rows** "Mittel der / das Mittel" in mono, rows in green, blue, purple, pink, orange, overlapping and offset; one row motion-blurred | ~70 px | static | rows slide horizontally, offset per row | hard cut | horizontal motion blur on one row | – | 1.2 s |
| 30.96–33.16 | **Black stack:** the word "Bewegung" repeated ~11 rows, widely letter-spaced (wider toward the bottom); one ghost/blurred grey row shimmers from top to bottom | white mono ~22 px | static | rows reveal top-down; ghost row travels | hard cut | blur ghost row | hit ≈ 30.9 s, then drone | 2.2 s |
| 33.16–34.3 | Same stack on **white**, tight spacing, black text | black mono | static | rows settle | hard cut | – | quiet | 1.1 s |
| 34.3–35.7 | Per-letter dissolve: random letters fade/blur out until one grey "g" remains | black → grey | static | per-character opacity | dissolve to empty | per-letter fade (and slight blur) | tail, silence at 35.7 | 1.4 s |

## 3. VISUAL SYSTEM

| Item | Value | Conf. |
|---|---|---|
| Light stage | RGB (253,253,253) = **#FDFDFD** | C |
| Black stage | RGB (1,0,2) = **#010002** (pure black) | C |
| Solid blue block | RGB (36,114,253) = **#2472FD** | C |
| Blue text accent | ≈ **#2F6BE0** (thin anti-aliased pixels read ~#336CDD) | E |
| Wheel / rainbow accents | green ≈ #00D68F, blue, magenta ≈ #C040E0, purple, pink ≈ #F0607A, orange ≈ #FF9A1F — a different hue **per word/row** | E |
| Wheel neighbours | light grey ≈ #C8C8C8–#DADADA (30–45 % opacity black) | E |
| Card plate | pale grey ≈ #E6E6E6, hard square edges, ~0–2 px radius | E |
| Gradients, glow | **None** | C |
| Gloss/liquid/glass/refraction/caustics | **None** | C |
| Grain/noise | None visible (video compression only) | C |
| Shadows / reflections | None or extremely faint under cards | E |
| Blur | Only motion/dissolve blur: vertical smear at ~16 s, horizontal blur on one rainbow row (~30 s), ghost row in the stack | C |
| Borders | Two 1-px pale-blue hairlines in scene 1 only | C |
| Light direction | Flat; none | C |
| Fonts | Monospace for almost everything (looks like Space Mono / IBM Plex Mono / Geist Mono) [L]; the giant "durch" is a neo-grotesque sans (Inter/Helvetica-like) [L] | L |
| Sizing | Body ~3% of frame height; punch scenes up to 30% (cropped) | E |
| Layout | Text on or near the horizontal centre line; huge white space; large type bleeds off-frame | C |

## 4. ASSET INVENTORY

| Asset | Visible? | Static / animated | Can be made with | Likely missing? | Free alternative |
|---|---|---|---|---|---|
| White / black / blue stage backgrounds | Yes | Static | CSS (solid colours) | No | CSS |
| Hairlines (pale blue, 1 px) | Yes, 0.3–2 s | Animated draw | CSS/SVG | No | CSS |
| Icon set (bold outline, ~16 icons) | Yes, 2–5 s | Animated cycling | SVG | Probably | Phosphor Icons (MIT), Lucide, Tabler |
| Mono font | Yes | – | Google Fonts | Maybe | Space Mono, IBM Plex Mono, JetBrains Mono. **Persian: no good mono → use Vazirmatn 700/900** |
| Grotesque display font | Yes (durch) | – | Google Fonts | Maybe | Inter 800, Vazirmatn 900 |
| Card photos/3D renders (8–12) | Yes, 16–26 s | Static, transformed | AI image gen, stock, Blender, your own photos | **Yes — the biggest missing item** | Unsplash/Pexels objects on grey, AI plates |
| 3D camera / perspective | Yes | Animated | CSS 3D transforms, Three.js, After Effects 3D layers | No | CSS `perspective` |
| Word-wheel list | Yes | Animated | HTML/CSS | No | CSS transform |
| Masks / track mattes | Not needed | – | – | – | – |
| Grain / gloss / caustics overlay | **Not in video** | – | – | – | skip |
| Device mockups | Phone/laptop appear inside cards | Static | AI/stock | Optional | Any mockup PNG |
| SFX | Yes (see §7) | – | numpy/scipy, freesound, AI SFX | Probably | Freesound CC0, ElevenLabs SFX |
| Music/bed | Yes | – | AI music, royalty-free | Probably | Pixabay, Suno/Udio-style prompt |
| Voiceover | **Not confirmed** | – | – | – | – |
| Logos | None | – | – | – | – |

## 5. MOTION ANALYSIS

| Mechanic | How it works [E unless noted] | Approx. values |
|---|---|---|
| **Typed word reveal** (0.25–1.5 s) | Per-word opacity step with tiny rise; word-based (not letter) | 250 ms per word, 150 ms fade, 4 px rise, ease-out |
| **Hairlines** | Two thin lines scale from 0 → full width then fade | 500–700 ms, ease-out, opacity 0.35 |
| **Icon slot cycling** | A small set of icons swaps at a fixed interval in the same slot; clusters drift to new positions | swap 250 ms, drift 20–60 px, ease-in-out, no blur |
| **Arc rotation ("to play")** | Text on a curved path, rotating about its centre; scale 0.6 → 1 | 600–900 ms, ease-out with slight overshoot (~1.04) |
| **Word wheel** | Vertical list translates through a fixed slot; non-centre rows fade by distance; colour swaps instantly on centre | ~330 ms/word, easing decelerates over 4.8 s; row pitch ≈ 1.5× font size; opacity falls 100 % → 30 % → 0 over 4 rows |
| **Streak dissolve (~16 s)** | Text plane stretches/blurs vertically while fading | 500 ms, vertical blur 30–60 px |
| **Card carousel** | 3D layers: rotateY ±50°, rotateZ ±8°, parallax speed differs per card; slow lateral drift | 5 s, linear-ish drift, perspective ≈ 800–1200 px |
| **Dolly-in (21.5–25.5)** | Camera moves toward cards (or all layers scale up 2–3×) while Z-rotation grows | 4 s, ease-in; hit at start |
| **Hard cuts (26–33 s)** | No transition; 0 ms | – |
| **Giant crop ("durch")** | Type scaled so letters exceed frame; slow slide in X | 230 px, 80–120 px travel in 0.6 s |
| **Rainbow rows** | Rows of the same phrase with different X offsets, each with its own hue; one row blurred | blur ≈ 8–12 px horizontal on one row |
| **Stack** | Rows reveal top-down; widening letter-spacing; a ghost row travels | ~60 ms per row, ghost row speed ≈ 1 row per 0.2 s |
| **Per-letter dissolve** | Random per-character opacity/blur to 0 | 1.4 s, random order, ease-in |
| Parallax / motion blur | Parallax in the cards; motion blur only on streak, rainbow row and ghost row | – |
| Liquid distortion / refraction / light sweeps | **None** | – |

Technique guess: After Effects-style 3D layers + text animators (random order, per-character opacity/blur), or a code-driven system (HTML/Three.js/Cavalry) [L–E]. Keyframes + camera movement; no mattes or masks needed.

## 6. GLOSSY / LIQUID EFFECT

**There isn't one.** The only "liquid-feeling" elements are (a) the vertical streak dissolve at ~16 s, (b) the horizontally blurred rainbow row at ~30 s, and (c) the blurred ghost row in the black stack. Likely tool: **F — a combination of 3D layers and text animators in a motion tool; no gloss/glass layers** [E].
Practical recipe for the blur-streak look: duplicate the text layer, apply a one-directional blur of 40–60 px (vertical for 16 s, horizontal 8–12 px for the rainbow row), cross-fade original → blurred over 500 ms while opacity drops to 0.
If you want gloss/liquid for the finale of your own videos, treat it as an optional addition, not part of the reference style.

## 7. AUDIO ANALYSIS

Measured on the file; I cannot "hear" it, so timbre is inferred from envelope and spectrum.
- **Loudness:** −14.6 LUFS integrated, loudness range 10.9 LU [C]. Louder than a −16 LUFS target.
- **Voiceover:** no evidence of speech in the envelope or spectrum [L]. Treat as no voiceover.
- **Spectrum:** high-frequency clicks early (centroid ≈ 3.1 kHz at 0–5 s), moving lower and bassier toward the end (≈ 0.9 kHz at 20–30 s) [C].
- **Energy:** quiet start; rising build to a peak at ≈ 8–9 s; steady ≈ 10–17 s; a dip at 18–21 s; **biggest transient at ≈ 22.2 s**; onsets at 26.0, 29.5, 30.9 s; tail to silence at 35.7 s [C].
- **Probable layers:** soft ticks/clicks on text; pops for icons; a sustained synth/bass bed; deep hits on the cuts [E].
- **Ducking / compression / reverb:** not determinable [L].

## 8. SOFTWARE IDENTIFICATION

| Tool | Evidence | Confidence | Beginner alternative |
|---|---|---|---|
| After Effects | 3D layers with parallax, text animators with random per-character fade, motion blur | Medium | CapCut (limited), or HTML/CSS |
| Code-driven (HTML / Three.js / Cavalry) | Exactly regular wheel, slot-cycling icons, precise repetition | Low–medium | This Playwright/ffmpeg kit |
| Jitter / Figma | Possible for text and wheel | Low | – |
| Blender | 3D-rendered objects may be Blender/AI renders (cards only) | Low | Stock photos |
| CapCut / Alight Motion | Unlikely for the camera and text animators | Low | – |
| Runway / Kling / Veo / Sora | No evidence — all graphics are clean vectors and still images | Low (very unlikely) | – |

## 9. RECREATION WORKFLOWS

**A. CapCut.** Solid-colour backgrounds; text with "typewriter"/"word fade" in; icons as stickers; word wheel by keyframing a text stack; cards as stickers with Zoom keyframes; hard cuts on beat; SFX track. Limits: no true 3D carousel, no per-word wheel precision.
**B. After Effects.** Comp 1920×1080/30. Text layers + Animator (opacity, blur, random order); a null-driven 3D camera for cards (3D layers with Y-rotation, camera dolly); a precomp for the wheel (position keyframes with easing); expressions for slot-cycling icons; hard cuts by trimming layers; render with H.264.
**C. Browser-based.** One HTML page, deterministic `render(t)`, Playwright screenshots → ffmpeg (see `02_master_prompt_for_claude.md`). Best for repeating across topics.
**D. AI-assisted.** Use AI only for card images and SFX/music; animate in HTML/AE. Do not use text-to-video for the typography (it garbles text, especially Persian).

Order for all four: script → storyboard (use the scene table) → assets → set up colours/fonts → animate → SFX → music → loudness → export.

## 10. MISSING-ASSET CHECKLIST

- **I already have:** Vazirmatn, Lalezar, robot PNGs (not used by this style), arrow PNGs (optional).
- **I need to create:** hairlines, icon slots, wheel, stacks, hard-cut scenes (all CSS/SVG).
- **I need to download:** a bold outline icon pack (Phosphor/Lucide), a mono font for Latin words.
- **I need to record:** nothing (voiceover only if wanted).
- **I need to generate with AI:** 8–12 card plates (objects/posters on pale-grey squares, Persian-text-free); optional music and SFX.
- **Optional premium:** custom 3D renders, licensed music.

## 11. REUSABLE TEMPLATE SYSTEM

- **Scene structure (25 s):** hook line → icon replacement → arc word → wheel → card carousel + dolly → black title → blue punch → rainbow/stack → dissolve → CTA.
- **Text hierarchy:** L1 body (3% height), L2 emphasis (weight 900 + hue), L3 punch (up to 30% height, cropped).
- **Card types:** photo plate, poster plate, object plate, device plate; all on #E6E6E6 squares.
- **Backgrounds:** #FDFDFD, #010002, #2472FD (swap blue for a topic accent).
- **Transitions:** blur-streak dissolve, hard cut on beat, scale-through, whip-pan (optional).
- **Animation presets:** typed-word (250 ms/word), icon-cycle (250 ms), arc-in (700 ms), wheel (decelerate 4.8 s), dolly-in (4 s ease-in), stack-reveal (60 ms/row), per-word dissolve (1.4 s).
- **SFX library:** tick, pop, thud, riser, glitch, swish, ding, key click.
- **Variables:** `--bg-light:#FDFDFD; --bg-dark:#010002; --accent:#2472FD; --card:#E6E6E6; --muted:#C8C8C8`.
- **Export:** 1920×1080, 30 fps, H.264, AAC, −16 LUFS, ≤ −1 dBFS.

## 12. EXACT CREATION PROMPTS
See `03_creation_prompts.md`.

## 13. FINAL RECOMMENDATION

- **Most likely method:** After Effects-style 3D layers + text animators, or code-driven HTML/3D [E–L].
- **Three most important effects:** (1) hard cuts landing on bass hits; (2) the word wheel with colour-changing centre word; (3) the card carousel with a dolly-in.
- **Three assets you're missing most:** card plate images, a bold outline icon pack, a sound bed with hits.
- **Fastest tool:** the HTML + Playwright + ffmpeg pipeline already in the master prompt (repeatable per topic).
- **Hardest part:** the 3D-looking card carousel and dolly-in; the second hardest is making Persian letter-spaced/per-letter effects without breaking joins (see master prompt, "Persian rules").
- **Beginner plan:** generate 8 card images and 16 icons, then build scenes 1, 4 (wheel), 5 (cards), 6–8 first. Add the stack and per-word dissolve last.
