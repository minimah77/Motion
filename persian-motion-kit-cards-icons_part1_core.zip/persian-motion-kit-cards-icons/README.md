# Persian Motion Kit: Cards and Icons

One project. Give Claude a topic and a script, and it builds a 25 second Persian motion video in the style of `reference/video1.mp4`, using the digital cards and line icons in this kit.

This kit is separate from every other project. Nothing in it comes from any other recipe or kit.

## How the zips fit together

Three zips, each under 10 MB, all with the same root folder `persian-motion-kit-cards-icons/`. Unzip all three into the same place and they merge into one folder. No file appears in more than one zip.

| Zip | Size | Holds |
|---|---|---|
| `..._part1_core.zip` | about 8.5 MB | docs, `scripts/`, `reference/`, `output/`, `assets/images/icon_sheets/`, `assets/icons/`, and cards 01 to 03 |
| `..._part2_fonts.zip` | about 7 MB | `fonts/` (8 families) |
| `..._part3_cards.zip` | about 8.5 MB | cards 04 to 12 |

## Folder map after unzipping

| Path | What it is |
|---|---|
| `PROMPT.md` | The prompt you paste into a new Claude chat. Fill the topic slots and send. |
| `SKILL.md` | Step by step instructions Claude follows with this kit (also usable as a skill file). |
| `QUESTIONS.md` | The short intake Claude asks before building. |
| `RECIPE.md` | The build recipe: look, scene table, motion values, Persian rules, fonts, transitions, sound plan, pipeline, quality checks. |
| `ASSETS.md` | Every asset with its fixed file name, colours, fonts, and prompts to make more. |
| `assets/images/cards/` | 12 digital cards, 1254x1254 PNG, `card_01_download.png` to `card_12_document.png`. |
| `assets/images/icon_sheets/` | 3 sheets, 16 line icons each. |
| `assets/icons/` | The 48 icons sliced into transparent PNGs, plus `manifest.json`. |
| `fonts/` | 8 families: Vazirmatn, IBM Plex Sans Arabic, Lalezar, Playpen Sans Arabic, Markazi Text, Parastoo, Lora, Nanum Myeongjo (static TTF plus licence). |
| `scripts/render.py` | Playwright to frames to MP4, or still images for checking. |
| `scripts/sfx_soft.py` | Sound effects synthesised in code, plus a cue mixer. No downloads. |
| `scripts/slice_icons.py` | Re-slices the icon sheets if you replace them. |
| `scripts/smoke_test.html` | A tiny page that proves the renderer and the Persian font work on your machine. |
| `reference/video1.mp4` | The video we recreate with our own topics (35.7 s, 1276x720, 25 fps). |
| `reference/frames/` | Contact sheets of the reference (JPEG). |
| `reference/analysis.md` | Timeline and measurements of the reference. |
| `output/` | Empty. Renders land here. |

## Quick start

```
pip install playwright numpy scipy pillow --break-system-packages
python3 -m playwright install chromium
python3 scripts/render.py scripts/smoke_test.html --duration 1 --out output/smoke.mp4
```

If `output/smoke.mp4` plays and shows Persian text (Vazirmatn Bold), the pipeline works. Then paste `PROMPT.md` into a new Claude, attach the unpacked folder, and send your topic and script.

## Known gaps, stated plainly

- **No example video.** By design. The reference video is the example.
- **No sound files.** `scripts/sfx_soft.py` makes them. Voiceover is not generated; record or create it separately and pass it to the mixer step.
- **Only a one second page has been rendered** with `render.py`. A full 25 second video has not been built from this kit yet.
- **Lora and Nanum Myeongjo have no Persian letters.** Use them for English words and numbers only. The other six families carry the Persian.
- **Size reductions, no visual change:** cards were re-saved losslessly (pixels identical), icon sheets are stored as grayscale, reference contact sheets are JPEG.
- Icon sheet B contains the gift icon twice. The slicer keeps both as `icon_gift` and `icon_gift_2`.
