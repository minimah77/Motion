# Motion Video Recipe 1 (Persian, soft-UI, Apple-style)

One zip = everything Claude needs to build a polished 16:9 motion-graphic video from a topic.
Claude builds it by code (HTML + Playwright + ffmpeg). You only supply images, a topic and a script.

## How to start (3 steps)
1. Generate the images in `ASSETS.md` and drop them into `assets/images/` (names are fixed).
2. Open a new Claude chat, attach this zip (or its unzipped folder) and paste `PROMPT.md`.
3. Answer Claude's questions (`QUESTIONS.md`), send your script, and say **yes** to start.

## What is inside
| File / folder | Purpose |
|---|---|
| PROMPT.md | The prompt to paste in a new chat |
| SKILL.md | The same rules as a skill (save it in Claude if you want it permanent) |
| QUESTIONS.md | Questions Claude asks before building |
| RECIPE.md | Look, motion values, transition library, sound design, pipeline |
| ASSETS.md | Every image to generate, with file names and prompts |
| assets/images | Put your generated PNGs here |
| assets/robot | Put your robot mascot PNG sequences here (optional) |
| cursors | Arrow cursors (dark/white) |
| fonts | Vazirmatn (Persian) + Lalezar, OFL licence |
| scripts/render.py | Frame renderer (Playwright -> JPEG frames) |
| scripts/sfx_soft.py | Soft Apple-style sound-effect synthesizer (run it for a demo) |
| examples | A finished 25 s composition to copy structure from |

## Rules baked in
- Soft, cute, professional Apple-style UI sounds, synthesized by Claude (no downloads).
- Voice-over made with vidIQ only after you send the script and say yes.
- Claude asks whether to use your robot mascot.
- Claude asks the length and recommends the best one.
- The strongest trending transitions are used (see RECIPE.md).

## Install (3 zips, same top folder)
Unzip all three into the SAME place and merge the folder `motion-video-recipe-1/`:
1. motion-video-recipe-1_part1_core.zip   - docs, scripts, fonts, cursors, example, reference video
2. motion-video-recipe-1_part2_visuals.zip - images, gradients, overlays, grain
3. motion-video-recipe-1_part3_robot.zip   - robot mascot frame sequences (optional)

## Notes (changes from the original kits)
- Images are now .webp (not .png) to fit the size limit. Same names. Two were renamed by you earlier:
  card_glass -> frosted_file_card.webp, tiles_grid -> same_look_tiles.webp. Cut-outs still sit on flat #00FF00 (key it out in code).
- Overlays/grain are re-compressed JPEGs (slightly lower quality, fine for blend layers).
- reference/video1.mp4 is the style reference, re-encoded to 960x540 to save space.
- The example HTML mentions Vazirmatn-ExtraBold, which is not included; use Black/Bold instead.
- QUESTIONS.md mentions archetypes A-K, but RECIPE.md only has the Video-1 look: treat Video-1 as the default.
