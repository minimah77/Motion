"""Soft, cute, Apple-style UI sound effects, synthesized (numpy + scipy only).
Usage:
  from sfx_soft import mix
  mix([(0.5,'pop',1.0),(1.2,'swish',0.8),(2.0,'chime',1.0,1.0)], dur=25.0, out='audio.wav')
Cue = (time_seconds, name, gain, pitch_multiplier[optional]).
Names: tap, pop, swish, whoosh_soft, chime, success, send, key, sparkle, toggle_on,
       toggle_off, drop, notify, error_soft, riser_soft, count
Run `python3 sfx_soft.py demo.wav` to hear every sound once."""
import sys, numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
from scipy.io import wavfile
SR = 44100
rng = np.random.default_rng(7)
def T(d): return np.arange(int(d*SR))/SR
def env(n, a=.004, d=.12, curve=4.0):
    t = np.arange(n)/SR; e = np.minimum(1, t/max(a,1e-4))*np.exp(-curve*t/max(d,1e-3)); return e
def sine(f, d, a=.004, dec=None, curve=5.0):
    t = T(d); dec = dec or d; return np.sin(2*np.pi*f*t)*env(len(t), a, dec, curve)
def bell(f, d=.7, p=1.0):
    f *= p; t = T(d); out = np.zeros_like(t)
    for k, (m, g, dc) in enumerate([(1,1,1),(2.01,.35,.7),(3.02,.18,.5),(4.1,.08,.35)]):
        out += g*np.sin(2*np.pi*f*m*t)*np.exp(-t*(5/(d*dc)))
    return out*np.minimum(1, t/.003)
def bp(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], 'bandpass', fs=SR, output='sos'), x)
def lp(x, f): return sosfilt(butter(2, f, 'lowpass', fs=SR, output='sos'), x)
def noise(d): return rng.standard_normal(int(d*SR))
def sweep_noise(d, f0, f1, q=.5):
    n = noise(d); out = np.zeros_like(n); steps = 24; seg = len(n)//steps
    for i in range(steps):
        f = f0*(f1/f0)**(i/(steps-1)); lo, hi = max(60, f*(1-q/2)), min(SR/2-100, f*(1+q/2))
        out[i*seg:(i+1)*seg] = sosfilt(butter(2, [lo, hi], 'bandpass', fs=SR, output='sos'), n[i*seg:(i+1)*seg])
    t = np.arange(len(out))/SR; e = np.sin(np.pi*np.clip(t/d, 0, 1))**1.6
    return out*e
def A(*xs):
    n = max(len(x) for x in xs); o = np.zeros(n)
    for x in xs: o[:len(x)] += x
    return o
def S(name, p=1.0):
    if name == 'tap':      # soft glass tap
        return A(.8*sine(1500*p, .09, dec=.05, curve=6), .25*sine(3000*p, .05, dec=.03))
    if name == 'pop':      # bubble pop: quick upward blip
        t = T(.12); f = 420*p*(1+1.8*np.exp(-t*38)); ph = 2*np.pi*np.cumsum(f)/SR
        return .9*np.sin(ph)*env(len(t), .002, .09, 6)
    if name == 'swish':    # soft airy swipe
        return .55*sweep_noise(.32, 900*p, 4200*p, .9)
    if name == 'whoosh_soft':
        return .5*sweep_noise(.55, 300*p, 2400*p, 1.2)
    if name == 'chime':    # gentle two-note bell
        a = bell(1046.5, .8, p); b = np.concatenate([np.zeros(int(.09*SR)), bell(1568, .8, p)])
        n = max(len(a), len(b)); o = np.zeros(n); o[:len(a)] += .7*a; o[:len(b)] += .6*b; return o
    if name == 'success':  # rising triad
        o = np.zeros(int(1.1*SR))
        for i, f in enumerate([783.99, 987.77, 1318.5]):
            b = bell(f, .7, p)*(.7+.1*i); s = int(i*.085*SR); o[s:s+len(b)] += b[:len(o)-s]
        return o
    if name == 'send':     # upward whoosh + tiny tick
        sw = .35*sweep_noise(.26, 1200*p, 5200*p, .8); k = np.zeros_like(sw)
        b = sine(1800*p, .08, dec=.04)*.6; k[:len(b)] += b; return A(sw, k)
    if name == 'key':      # soft keyboard tick
        n = bp(noise(.03), 1800, 5200)*env(int(.03*SR), .001, .02, 7)*.9
        return A(n, .35*sine(240*p, .03, dec=.02))
    if name == 'sparkle':
        o = np.zeros(int(.8*SR))
        for i in range(5):
            f = rng.choice([2093, 2637, 3136, 3520, 4186])*p; b = bell(f, .25)*(.5-.07*i); s = int(i*.055*SR); o[s:s+len(b)] += b[:len(o)-s]
        return o*.7
    if name == 'toggle_on':
        return _pair(900*p, 1350*p)
    if name == 'toggle_off':
        return _pair(1200*p, 800*p)
    if name == 'drop':     # soft landing thump
        t = T(.28); f = 140*p*np.exp(-t*7)+55; return .9*np.sin(2*np.pi*np.cumsum(f)/SR)*env(len(t), .003, .2, 5)
    if name == 'notify':
        a = bell(1318.5, .5, p); b = np.concatenate([np.zeros(int(.12*SR)), bell(1760, .6, p)])
        n = max(len(a), len(b)); o = np.zeros(n); o[:len(a)] += .6*a; o[:len(b)] += .6*b; return o
    if name == 'error_soft':
        return _pair(330*p, 247*p, gap=.11, d=.18)
    if name == 'riser_soft':
        return A(.45*sweep_noise(.9, 500*p, 6000*p, 1.0), .2*sine(300*p, .9, a=.5, dec=.9, curve=.5)*np.linspace(0, 1, int(.9*SR)))
    if name == 'count':    # counter tick
        return .6*sine(2000*p, .03, dec=.02)
    raise KeyError(name)
def _pair(f1, f2, gap=.05, d=.1):
    a = sine(f1, d, dec=d*.6); b = sine(f2, d*1.2, dec=d*.7); n = int((gap+d*1.2)*SR); o = np.zeros(n)
    o[:len(a)] += .7*a; s = int(gap*SR); o[s:s+len(b)] += .7*b[:n-s]; return o
def room(x, size=.35):   # tiny airy reverb for the "soft" feel
    n = int(size*SR); ir = rng.standard_normal(n)*np.exp(-np.arange(n)/SR*9); ir = lp(ir, 5000); ir /= np.abs(ir).sum()
    return x+0.35*fftconvolve(x, ir)[:len(x)]*8
def mix(cues, dur, out='audio.wav', peak=.85, wet=True, bed=None):
    buf = np.zeros(int((dur+1.5)*SR))
    for c in cues:
        t, name, g = c[0], c[1], c[2]; p = c[3] if len(c) > 3 else 1.0
        s = S(name, p); i = int(t*SR); buf[i:i+len(s)] += g*s[:len(buf)-i]
    if bed is not None: buf[:len(bed)] += bed[:len(buf)]
    if wet: buf = room(buf)
    buf = np.tanh(buf*1.1)/np.tanh(1.1); buf = buf[:int(dur*SR)]; buf *= peak/max(1e-6, np.abs(buf).max())
    st = np.stack([buf, buf*.985], 1); wavfile.write(out, SR, (st*32767).astype(np.int16)); return out
if __name__ == '__main__':
    names = ['tap','pop','swish','whoosh_soft','chime','success','send','key','sparkle','toggle_on','toggle_off','drop','notify','error_soft','riser_soft','count']
    mix([(0.3+i*1.0, n, 1.0) for i, n in enumerate(names)], 0.3+len(names)*1.0, sys.argv[1] if len(sys.argv) > 1 else 'demo.wav')
