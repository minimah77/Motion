# Images to generate (ChatGPT). Save as PNG with these exact names in assets/images/
Paste this style line first in every chat:
"Clean modern product-video style, soft light from the top left, no text, no logos. Palette: blue #1F4FD8, white, black #141010, dark brown #4E3B33, red #E5342B, yellow #FFC933, green #12B76A."
Cut-outs use a flat #00FF00 background; Claude removes it.

| # | File | Prompt |
|---|---|---|
| 1 | bg_meadow.png | Wide overcast meadow with rolling green hills, soft clouds, muted natural colours, photoreal, calm, empty, 16:9. |
| 2 | laptop_grass.png | A closed silver laptop standing upright in tall green grass on a hill, overcast light, photoreal, shallow depth of field, blank dark screen, 16:9. |
| 3 | bg_pale_studio.png | Minimal pale grey-white studio background, soft radial light from the top centre, very soft vignette, empty, 16:9. |
| 4 | bg_liquid.png (+ bg_liquid_2.png) | Abstract glossy liquid gradient, large smooth swirls, soft white highlights, no objects, 16:9. Version 1 navy+teal, version 2 blue+yellow+red on dark brown. |
| 5 | tiles_grid.png | A tilted grid of 25 identical rounded rectangle cards, each with an empty image block and two blank lines, same colour scheme, flat lay, no readable text, 16:9. |
| 6 | window_blank.png | One blank white app window, rounded corners, title bar with three dots, empty content, large soft shadow, slight 3D angle, flat #00FF00 background. |
| 7 | icons_files.png | Four glossy soft-3D app icons on flat #00FF00, evenly spaced: document, folder, zipped file, PDF file. |
| 8 | chips.png | Six empty rounded label shapes of different widths on flat #00FF00: white, black, blue, red, yellow, green. Soft glow, no text. |
| 9 | comment_bar.png | One empty white pill input bar with a round avatar on the left and a round blue send button on the right, soft shadow, flat #00FF00, no text. |
| 10 | card_glass.png | A frosted-glass file card with a small document icon and two blank lines, rounded corners, soft shadow, white at 20% opacity, flat #00FF00, no text. |
| 11 | icons_small.png | 24 flat rounded icons on flat #00FF00: sparkle, crown, paper plane, heart, chat bubble, price tag, check, lightning, lock, bell, play, arrow. |
| 12 | bg_sky_clouds.png | Soft blue sky with large white clouds, bright, airy, photoreal, empty, 16:9. |
| 13 | bg_dark_studio.png | Deep black-brown studio background, soft warm spotlight from above, fine haze, vignette, empty, 16:9. |
| 14 | overlay_grain.png | Fine film grain and tiny dust specks on pure black, seamless, high contrast, 16:9. |
| 15 | phone_blank.png | One modern smartphone, blank dark screen, slight 3D angle, soft shadow, flat #00FF00. |
| 16 | objects_3d.png | 12 glossy soft-3D objects on flat #00FF00: lightbulb, book, trophy, key, clock, magnifying glass, heart, star, gift, coin, target, rocket. |
Not images: sound effects (Claude synthesizes), music (Claude synthesizes), voice (vidIQ), fonts (included).
