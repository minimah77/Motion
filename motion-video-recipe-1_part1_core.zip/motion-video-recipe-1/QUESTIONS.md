# Questions Claude asks (once, short, with a recommendation on each)
1. **Topic + promise:** what is the video about and what does the viewer get?
2. **Audience + pain:** who is it for, what annoys them? (Roast tone allowed.)
3. **Script:** do you have it, or should I write 2 options? (6-10 short colloquial lines, hook first, CTA last.)
4. **CTA keyword:** which word should people comment, and what do you send them?
5. **Length:** 15 s / 25-30 s / 45 s. Recommendation: **30 s** for Reels/Shorts/TikTok (enough for hook, 3 proof beats, demo, CTA); 15 s for a teaser; 45 s only for a demo-heavy explainer.
6. **Robot mascot:** use your robot (assets/robot) or no robot?
7. **Style:** Video-1 look (default) or an archetype A-K from the recipe pack; one or several.
8. **Voice:** vidIQ voice-over (I pick a Persian voice and show you the choice) or text + sound effects only?
9. **Palette / music mood:** keep blue, white, black, brown, red, yellow, green? Soft or energetic bed?
After the answers Claude says the plan in 5 lines and waits for: script + "yes".
