# Motion Asset Library - Step 3: Cutouts, UI Pop-ups and 3D Objects

24 PNGs with transparent backgrounds (RGBA), independent of each other. Steps 1 and 2 were not touched.

## Contents
- 01_Photo_Cutouts (8, 1024x1024): sunglasses, headphones, digital camera, retro phone, butterfly, bouquet, sneaker, peace-sign hand. NOTE: these are rendered/illustrated, not real photographs (see QC report).
- 02_UI_Popups (8, native aspect ratios): retro notification, message bubble, like notification, comment card, music player, loading dialog, system alert, NEW! sticker. Three styles: retro pixel, glossy Y2K, clean modern.
- 03_3D_Objects (8, 1024x1024): chrome sphere, iridescent orb, metal ring, inflatable heart, 3D star, liquid chrome blob, glass cube, ringed planet. Soft glow baked in, no floor.
- 04_Preview_Sheets: master sheet and one sheet per category. Backgrounds and labels exist only in these previews, never in the assets.
- 05_Documentation: manifest_cutouts_ui_3d.csv, QC_report_step3.txt, this README.

## Using them in CapCut
1. Put your base clip on the main track. Add an asset via Overlay (or a second video track) so the transparency is kept.
2. Resize with the pinch handles or the Scale slider. On a 9:16 canvas, UI pop-ups sit well at 60-90% of screen width. Objects and cutouts work at 15-45%.
3. Layer order: background clip, 3D objects behind the subject, cutouts, UI pop-ups on top. Keep UI inside the safe area, away from the top 12% and bottom 20%.
4. Animate with keyframes: pop-in = Scale 0% to 110% to 100% over about 6-8 frames. Float = Position Y +/-20 px over 1-2 seconds, looping. Spin 3D objects slowly with Rotation keyframes. Add Shadow or Glow in Effects if you want more depth.
5. Sync entrances to beat markers. UI pop-ups work well with a click or pop SFX.
6. Do not stretch non-uniformly. Use a Mask or Opacity keyframe to fade out.
