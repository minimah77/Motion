#!/usr/bin/env bash
# Real glitch effects that distort the FOOTAGE itself (a transparent PNG cannot do this).
# Needs ffmpeg on a computer. Usage:  ./glitch_footage_recipes.sh input.mp4 rgb|slices|both [start_sec] [duration_sec]
# Output: <input>_glitch_<mode>.mp4 (audio is copied untouched).
set -euo pipefail
IN="${1:?input video}"; MODE="${2:-both}"; T0="${3:-0.4}"; DUR="${4:-0.35}"; T1=$(python3 -c "print($T0+$DUR)")
# 1) RGB colour separation: red channel shifted left, blue shifted right, only during the burst
RGB="rgbashift=rh=-14:bh=14:rv=2:bv=-2:enable='between(t,$T0,$T1)'"
# 2) Horizontal slice displacement: bands of 36 px are pushed sideways by a time-varying hash (changes every frame at 24 fps)
H="sin(floor(Y/36)*12.9898+floor(T*24)*78.233)*43758.5453"
OFF="st(0,$H);st(1,ld(0)-floor(ld(0)));if(gt(ld(1),0.82),(ld(1)-0.91)*620,0)"
SL="format=gbrp,geq=r='p(X+($OFF),Y)':g='p(X+($OFF),Y)':b='p(X+($OFF),Y)':enable='between(t,$T0,$T1)'"
case "$MODE" in rgb) VF="$RGB";; slices) VF="$SL";; both) VF="$SL,format=rgb24,$RGB";; *) echo "mode: rgb|slices|both"; exit 1;; esac
ffmpeg -y -i "$IN" -vf "$VF,format=yuv420p" -c:v libx264 -crf 17 -c:a copy "${IN%.*}_glitch_${MODE}.mp4"
