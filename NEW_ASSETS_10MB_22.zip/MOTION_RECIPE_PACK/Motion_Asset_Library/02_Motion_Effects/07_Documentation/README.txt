MOTION ASSET LIBRARY - PACK 02: MOTION EFFECTS & GRAPHIC OVERLAYS
================================================================

28 transparent PNG overlays for Reels / TikTok edits, in 5 categories. Step 1 (arrows, scribbles,
3D icons, symbols) lives in 01_Doodles_Icons_Symbols and is untouched.

IMPORTANT: STATIC VS ANIMATED
- All 28 numbered assets are STATIC PNGs. None of them moves on its own. Animate them with your editor's
  keyframes, in/out animations, opacity flicker or a quick scale.
- A static PNG cannot displace or recolour the footage under it. The glitch PNGs are overlays that LOOK like
  glitches on top of the picture; they do not shift your video. For real distortion use the extras in
  05_Glitch_Effects/animated and 07_Documentation/glitch_footage_recipes.sh (see GLITCH below).

FOLDERS
01_Speed_Lines/        6  full-frame 1440x2560 (impact burst is 1600x1600)
02_Light_Flares/       5  soft glow with real soft alpha (2048x2048, 1536x1536, 2560x768, leak 1440x2560)
03_Halftone_Dots/      5  transparent dots, full-frame 1440x2560
04_Highlight_Circles/  6  2048x2048, circle centred with clear space
05_Glitch_Effects/     6  full-frame 1440x2560 PNGs + animated/ (1 extra animated burst, 2 formats)
06_Previews/           master contact sheet + one sheet per category (dark and light backgrounds)
07_Documentation/      this README, manifest_motion_effects.csv, QC report, footage glitch recipe

Preview backgrounds are for browsing only. They are never part of the PNG files.

CATEGORIES AND WHAT TO USE THEM FOR
Speed lines   radial (zoom/hit), horizontal streaks (pans, whoosh), diagonal action (black, for bright clips),
              short impact lines (punch accent), tunnel (zoom-through transitions), subtle streaks (gentle motion).
Light flares  cinematic soft amber, anamorphic blue streak, small white star twinkle, warm light leak (left edge),
              cool violet flare. Place over a bright spot; try Screen or Lighten blend if your editor has it.
Halftone      fine dots (texture), comic pink (corner accent), radial black (vignette), diagonal blue, vintage amber.
Highlight     thin, rough marker, double ring, incomplete stroke, neon glow, sketch oval. Scale and move onto the
circles       subject. Wipe-in animation on the incomplete and rough circles looks drawn on.
Glitch        rgb split, horizontal displacement, scanlines, pixel blocks, signal interference, chromatic edge.
              Use for 3 to 8 frames (0.1 to 0.3 s) over a cut; flicker by cutting the clip into short pieces.

IMPORTING INTO CAPCUT (phone or desktop)
1. Put your video on the main track.
2. Overlay > Add overlay (desktop: drag onto a track above the video) and pick the PNG. Transparency is kept.
3. Pinch/drag to fit. Full-frame effects are 9:16: scale them to fill the frame.
4. Optional: blend mode (Screen/Lighten for flares and glows), opacity, and keyframes for position, scale and
   opacity. Menu names differ slightly by app version; any editor that reads PNG alpha works the same way.
5. Light assets (white, amber) vanish on bright footage and black assets vanish on dark footage: pick by clip.

GLITCH: REAL DISTORTION OF YOUR FOOTAGE
a) 05_Glitch_Effects/animated/glitch_burst_animated_alpha.mov  - transparent ProRes 4444, 0.75 s, 1080x1920, 24 fps.
   Works in editors that read alpha video (Premiere, Final Cut, Resolve). It is an overlay animation; it does
   not move the footage underneath either.
b) glitch_burst_animated_on_black.mp4 - the same animation on black. In apps without alpha video support,
   place it as an overlay and set the blend mode to Screen/Lighten so the black disappears.
c) 07_Documentation/glitch_footage_recipes.sh - ffmpeg script (needs a computer with ffmpeg) that really
   splits RGB channels and displaces horizontal slices of your own video for a chosen time window:
       ./glitch_footage_recipes.sh clip.mp4 both 0.4 0.35
   Modes: rgb, slices, both. Audio is copied unchanged.

FILE FORMAT
PNG, RGBA, true alpha, transparent wherever there is no effect. Soft effects (flares, glows) keep smooth alpha
falloff and reach zero before the canvas edge. Full-frame patterns (halftone, scanlines, tunnel, chromatic edge,
streaks) are meant to cover the frame by design.
