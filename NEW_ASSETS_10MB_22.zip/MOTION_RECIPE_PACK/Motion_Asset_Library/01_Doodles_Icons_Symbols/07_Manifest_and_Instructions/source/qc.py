"""QC + packaging. Verifies every PNG, manifest<->disk match, preview sheets, then zips."""
import os, csv, glob, zipfile, sys
import numpy as np
from PIL import Image

ROOT = "/home/claude/Motion_Asset_Library"
PACK = f"{ROOT}/01_Doodles_Icons_Symbols"
ZIP = "/home/claude/Motion_Asset_Library_01_Doodles_Icons_Symbols.zip"
MIN_MARGIN = 60   # px of clear space required on every side (1024 canvas)

rows = list(csv.DictReader(open(f"{PACK}/07_Manifest_and_Instructions/manifest.csv")))
problems, stats = [], dict(checked=0, with_alpha=0, min_margin=9999)

manifest_paths = set()
for r in rows:
    p = f"{PACK}/{r['relative_path']}"
    manifest_paths.add(os.path.normpath(p))
    if not os.path.exists(p):
        problems.append(f"MISSING {r['relative_path']}")
        continue
    if os.path.basename(p) != r["filename"]:
        problems.append(f"NAME MISMATCH {r['filename']}")
    im = Image.open(p)
    im.load()
    stats["checked"] += 1
    if im.mode != "RGBA":
        problems.append(f"NOT RGBA {r['filename']}")
        continue
    if im.size != (1024, 1024):
        problems.append(f"SIZE {r['filename']} {im.size}")
    a = np.array(im)[:, :, 3]
    transparent = (a == 0).mean()
    if a.min() == 0 and 0.02 < transparent < 0.995:
        stats["with_alpha"] += 1
    else:
        problems.append(f"ALPHA {r['filename']} transparent={transparent:.3f}")
    # corners fully clear (no baked background)
    if a[:8, :8].max() or a[-8:, -8:].max() or a[:8, -8:].max() or a[-8:, :8].max():
        problems.append(f"CORNER NOT CLEAR {r['filename']}")
    ys, xs = np.where(a > 4)
    m = min(xs.min(), ys.min(), 1023 - xs.max(), 1023 - ys.max())
    stats["min_margin"] = min(stats["min_margin"], int(m))
    if m < MIN_MARGIN:
        problems.append(f"CLIPPING RISK {r['filename']} margin={m}px")

# every PNG on disk (outside previews) must be in the manifest
for p in glob.glob(f"{PACK}/**/*.png", recursive=True):
    if "06_Preview_Sheets" in p:
        continue
    if os.path.normpath(p) not in manifest_paths:
        problems.append(f"NOT IN MANIFEST {os.path.relpath(p, PACK)}")

# naming convention
import re
pat = re.compile(r"^[a-z0-9]+(_[a-z0-9]+)+_(white|black|chrome|electric_blue|violet|pink|yellow)_\d{2}\.png$")
for r in rows:
    if not pat.match(r["filename"]):
        problems.append(f"BAD NAME {r['filename']}")
# duplicates
names = [r["filename"] for r in rows]
if len(names) != len(set(names)):
    problems.append("DUPLICATE FILENAMES")

sheets = glob.glob(f"{PACK}/06_Preview_Sheets/*.png")
if not any("MASTER_contact_sheet" in s for s in sheets):
    problems.append("MASTER SHEET MISSING")

masters = [r for r in rows if not r["variant_of"]]
print(f"checked {stats['checked']} PNGs | with real alpha: {stats['with_alpha']} | "
      f"masters: {len(masters)} | min clear margin: {stats['min_margin']}px | sheets: {len(sheets)}")
if problems:
    print("PROBLEMS:")
    for p in problems:
        print(" -", p)
    sys.exit(1)

# ------------------------------------------------------------------ zip
if os.path.exists(ZIP):
    os.remove(ZIP)
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for dp, dn, fn in os.walk(ROOT):
        for d in sorted(dn):   # keep empty folders (families not built yet)
            full = os.path.join(dp, d)
            z.write(full, os.path.relpath(full, os.path.dirname(ROOT)))
        for f in sorted(fn):
            full = os.path.join(dp, f)
            z.write(full, os.path.relpath(full, os.path.dirname(ROOT)))
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
    names = z.namelist()
tops = sorted({"/".join(n.split("/")[:3]) for n in names if n.count("/") >= 2})
print("ZIP ok:", ZIP, f"{os.path.getsize(ZIP)/1e6:.1f} MB,", len(names), "entries")
for t in tops:
    print("  ", t)
