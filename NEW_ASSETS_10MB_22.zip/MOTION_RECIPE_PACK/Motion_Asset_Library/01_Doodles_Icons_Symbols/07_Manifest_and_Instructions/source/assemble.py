"""Assemble the pack: preview sheets, merged manifest, README, QC report, ZIP.
Re-run after every step; it picks up whatever manifest parts exist."""
import os, sys, csv, glob, shutil, zipfile, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from PIL import Image
from sheets import contact_sheet

ROOT = "/home/claude/Motion_Asset_Library"
PACK = f"{ROOT}/01_Doodles_Icons_Symbols"
PARTS = "/home/claude/motion_build/manifest_parts"
SHEETS = f"{PACK}/06_Preview_Sheets"
INFO = f"{PACK}/07_Manifest_and_Instructions"
ZIP = "/home/claude/Motion_Asset_Library_01_Doodles_Icons_Symbols.zip"

# ---------------------------------------------------------------- manifest
rows = []
fields = None
for p in sorted(glob.glob(f"{PARTS}/*.csv")):
    with open(p, newline="") as f:
        rd = csv.DictReader(f)
        fields = fields or rd.fieldnames
        rows.extend(rd)
os.makedirs(INFO, exist_ok=True)
with open(f"{INFO}/manifest.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    w.writerows(rows)
with open(f"{INFO}/manifest.json", "w") as f:
    json.dump(rows, f, indent=1)

masters = [r for r in rows if not r["variant_of"]]
fams = {}
for r in masters:
    fams.setdefault(r["family"], []).append(r)
P = lambda r: f"{PACK}/{r['relative_path']}"

# ---------------------------------------------------------------- sheets
for old in glob.glob(f"{SHEETS}/*.png"):
    os.remove(old)

# master contact sheet: every master design, contrasting tile per asset
contact_sheet([(P(r), r["filename"][:-4]) for r in masters],
              f"{SHEETS}/MASTER_contact_sheet.png",
              f"Motion Asset Library - Pack 01  |  {len(masters)} designs (primary colour, contrast tiles)",
              cols=8, cell=230, bg_mode="contrast")

def variant_path(r, color):
    base = r["filename"]
    fn = base.replace(f"_{r['primary_color']}_", f"_{color}_")
    if color == r["primary_color"]:
        return P(r)
    return f"{PACK}/05_Color_Variants/{ {'arrow':'arrows','scribble':'scribbles','icon':'icons'}[r['category']] }/{color}/{fn}"

for fam, items in fams.items():
    tag = items[0]["category"]
    contact_sheet([(variant_path(r, "white"), os.path.basename(variant_path(r, "white"))[:-4]) for r in items],
                  f"{SHEETS}/sheet_{tag}_white_on_dark.png",
                  f"{fam} - all designs in white on dark", cols=6, cell=250, bg_mode="dark")
    contact_sheet([(variant_path(r, "black"), os.path.basename(variant_path(r, "black"))[:-4]) for r in items],
                  f"{SHEETS}/sheet_{tag}_black_on_light.png",
                  f"{fam} - all designs in black on light", cols=6, cell=250, bg_mode="light")
    contact_sheet([(variant_path(r, "electric_blue"), os.path.basename(variant_path(r, "electric_blue"))[:-4]) for r in items],
                  f"{SHEETS}/sheet_{tag}_electric_blue_on_light.png",
                  f"{fam} - electric blue on light", cols=6, cell=250, bg_mode="light")
    contact_sheet([(P(r), r["filename"][:-4]) for r in items],
                  f"{SHEETS}/sheet_{tag}_masters_contrast.png",
                  f"{fam} - masters (primary colours on contrast tiles)", cols=6, cell=250, bg_mode="contrast")

# ---------------------------------------------------------------- README
n_files = len(rows)
n_masters = len(masters)
counts = "\n".join(f"- {fam}: {len(items)} distinct designs" for fam, items in fams.items())
readme = f"""MOTION ASSET LIBRARY - PACK 01: DOODLES, ICONS & SYMBOLS
=========================================================

Built step by step. This archive is cumulative: each step adds to it.

COMPLETED SO FAR
{counts}
Total individual PNG files: {n_files}  ({n_masters} master designs + colour variants)

FOLDER STRUCTURE
01_Doodle_Arrows/       Master arrows, each in its primary colour
02_Scribbles/           Master scribbles, squiggles, hatching, highlights, doodle clusters
03_3D_Icons/            Master 3D glossy icons (lit heightfield renders with soft shadows)
04_Symbols/             (later step)
05_Color_Variants/      Every design recoloured: white, black, chrome, electric_blue,
                        violet, pink, yellow (sub-folders per family and colour)
06_Preview_Sheets/      Contact sheets. MASTER_contact_sheet.png shows every design.
                        Sheet backgrounds are for browsing only - never part of assets.
07_Manifest_and_Instructions/   manifest.csv / manifest.json, this README, source code

FILE FORMAT
All assets: PNG, 1024 x 1024 px, RGBA with real alpha transparency. Artwork is centred
with about 10% padding on every side so nothing is clipped. No backgrounds, labels
or watermarks are baked in.

NAMING
<family>_<design>_<colour>_<NN>.png   e.g. arrow_curved_s_white_06.png
NN is the design number. The same NN in a different colour is the same design recoloured.

IMPORTING INTO CAPCUT (phone or desktop)
1. Create your project and add your footage to the main track.
2. Tap/click Overlay (mobile: Overlay > Add overlay) or Media > Import, then pick the PNG.
   Desktop: drag the PNG onto a track above your video.
3. PNG transparency is kept automatically. Pinch or drag the corners to resize and move.
4. Animate it: Animations > In (Wipe, Zoom, Pop) works well for arrows; or add keyframes
   for scale and position. For a hand-drawn "draw-on" feel, use Wipe on a short duration.
5. Tip: white and yellow assets vanish on bright footage. Swap to the black or
   electric_blue version from 05_Color_Variants/ rather than recolouring in the editor.
Other editors: Premiere, DaVinci Resolve, Final Cut, VN, InShot and Canva all read
PNG alpha - place the file on a track above the video.

ANIMATION
This pack contains static PNGs only. Nothing here is a pre-animated GIF or WebM.
Animate them with your editor's keyframes and in/out animations.
"""
with open(f"{INFO}/README.txt", "w") as f:
    f.write(readme)

# ---------------------------------------------------------------- source
src = f"{INFO}/source"
os.makedirs(src, exist_ok=True)
for fn in ("engine.py", "arrows.py", "build_arrows.py", "scribbles.py", "build_scribbles.py", "threed.py", "icons3d.py", "build_icons.py", "sheets.py", "assemble.py", "qc.py"):
    p = f"/home/claude/motion_build/{fn}"
    if os.path.exists(p):
        shutil.copy(p, src)

print("manifest rows:", len(rows), "| masters:", n_masters, "| sheets:", len(glob.glob(f'{SHEETS}/*.png')))
