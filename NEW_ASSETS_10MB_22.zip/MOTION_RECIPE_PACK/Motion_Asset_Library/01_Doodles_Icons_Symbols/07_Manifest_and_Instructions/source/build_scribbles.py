import os, sys, csv, shutil
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from engine import *
import scribbles as arrows

PACK = "/home/claude/Motion_Asset_Library/01_Doodles_Icons_Symbols"
MASTER_DIR = f"{PACK}/02_Scribbles"
VAR_DIR = f"{PACK}/05_Color_Variants/scribbles"
PART = "/home/claude/motion_build/manifest_parts/scribbles.csv"

# clean old output so reruns never leave stale files
for d in (MASTER_DIR, VAR_DIR):
    if os.path.isdir(d):
        shutil.rmtree(d)
    os.makedirs(d)

rows = []
for i, d in enumerate(arrows.D, start=1):
    nn = f"{i:02d}"
    rng = np.random.default_rng(1000 + i * 17)
    art = d["build"](rng)
    mask = render_mask(art)
    for color in COLOR_ORDER:
        img = colorize(mask, color)
        fn = f"scribble_{d['slug']}_{color}_{nn}.png"
        is_master = color == d["color"]
        if is_master:
            path = f"{MASTER_DIR}/{fn}"
            rel = f"02_Scribbles/{fn}"
        else:
            os.makedirs(f"{VAR_DIR}/{color}", exist_ok=True)
            path = f"{VAR_DIR}/{color}/{fn}"
            rel = f"05_Color_Variants/scribbles/{color}/{fn}"
        img.save(path, optimize=True)
        rows.append(dict(
            asset_id=f"B{nn}", filename=fn, relative_path=rel, family="Scribbles",
            category="scribble", style=d["treatment"], primary_color=color,
            intended_use=d["use"], arrowhead=d.get("head", ""), design_name=d["name"],
            variant_of="" if is_master else f"B{nn} master ({d['color']})",
            width_px=OUT, height_px=OUT, format="PNG RGBA"))

with open(PART, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
print(len(arrows.D), "designs,", len(rows), "files")
