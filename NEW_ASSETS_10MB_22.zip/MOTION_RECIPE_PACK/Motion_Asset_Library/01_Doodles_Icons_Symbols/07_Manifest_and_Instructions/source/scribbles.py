"""
Family B - Scribbles & hand-drawn marks. 36 distinct designs.
"""
import numpy as np
from engine import *

W = 24.0
CW = 22.0
D = []


def design(slug, name, treatment, color, use):
    def deco(fn):
        D.append(dict(slug=slug, name=name, treatment=treatment, color=color, use=use, build=fn))
        return fn
    return deco


def ell(cx, cy, rx, ry, a0, a1, n=300, rot_deg=0.0, drift=0.0):
    a = np.radians(np.linspace(a0, a1, n))
    k = np.linspace(1, 1 + drift, n)
    x, y = rx * k * np.cos(a), ry * k * np.sin(a)
    r = np.radians(rot_deg)
    return np.stack([cx + x * np.cos(r) - y * np.sin(r), cy + x * np.sin(r) + y * np.cos(r)], axis=1)


def hw(a, P, rng, amp=4.0, fine=1.0, w=W, profile=None, pressure=0.15):
    a.stroke(wobble(P, rng, amp, fine), w, profile=profile, rng=rng, pressure=pressure)
    return a


def hatch(a, rng, box, spacing, angle_deg, w=16.0, amp=2.5, trim=0.10):
    x0, y0, x1, y1 = box
    diag = np.hypot(x1 - x0, y1 - y0)
    d = np.array([np.cos(np.radians(angle_deg)), np.sin(np.radians(angle_deg))])
    nrm = np.array([-d[1], d[0]])
    c = np.array([(x0 + x1) / 2, (y0 + y1) / 2])
    for o in np.arange(-diag / 2, diag / 2, spacing):
        t = np.linspace(-diag, diag, 600)
        pts = c + nrm * o + np.outer(t, d)
        m = (pts[:, 0] >= x0) & (pts[:, 0] <= x1) & (pts[:, 1] >= y0) & (pts[:, 1] <= y1)
        if m.sum() < 10:
            continue
        seg = pts[m]
        L = len(seg)
        s0 = int(L * rng.uniform(0, trim))
        s1 = L - int(L * rng.uniform(0, trim))
        if s1 - s0 < 6:
            continue
        a.stroke(wobble(seg[s0:s1], rng, amp, 0.6), w, rng=rng, pressure=0.2)
    return a


# --------------------------------------------------------------- squiggles
@design("squiggle_loose", "Loose squiggle", "hand-drawn", "yellow", "Decorating empty space")
def _(rng):
    a = Art()
    pts = [(120, 560), (230, 430), (330, 640), (440, 420), (540, 650), (650, 430), (760, 620), (880, 470)]
    return hw(a, spline(pts, 30), rng, 3, 1.0)


@design("squiggle_tight", "Tight squiggle", "hand-drawn", "pink", "Adding energy to a word or edge")
def _(rng):
    a = Art()
    return hw(a, wave((110, 500), (890, 500), 42, 7, 600), rng, 2, 0.8)


@design("squiggle_tangle", "Tangled scribble", "hand-drawn", "white", "Messy emphasis / crossed-out feel")
def _(rng):
    a = Art()
    pts = [(220, 470), (700, 360), (260, 540), (760, 470), (230, 610), (730, 600), (300, 690), (680, 700)]
    return hw(a, spline(pts, 24), rng, 4, 1.2, w=20)


# --------------------------------------------------------------- spirals
@design("spiral_tight", "Tight spiral", "hand-drawn", "violet", "Hypnotic emphasis / dizzy reaction")
def _(rng):
    a = Art()
    return hw(a, arc(500, 500, 20, 0, 360 * 4.2, 700, r1=330), rng, 3, 0.8, w=20)


@design("spiral_loose", "Loose spiral", "hand-drawn", "electric_blue", "Decorating empty space")
def _(rng):
    a = Art()
    return hw(a, arc(500, 500, 40, -40, 360 * 2.6, 600, r1=360), rng, 5, 1.2)


# --------------------------------------------------------------- circle scribbles
@design("circle_single", "Overshoot circle", "hand-drawn", "pink", "Highlighting a face or object")
def _(rng):
    a = Art()
    return hw(a, ell(500, 500, 360, 310, -110, 290, 300, rot_deg=-8, drift=0.07), rng, 5, 1.0)


@design("circle_double", "Double-loop circle", "hand-drawn", "yellow", "Strong highlight of a subject")
def _(rng):
    a = Art()
    return hw(a, ell(500, 500, 300, 260, -100, 640, 520, rot_deg=-6, drift=0.34), rng, 6, 1.1, w=22)


@design("circle_messy", "Messy ring scribble", "hand-drawn", "white", "Hand-marked emphasis on a detail")
def _(rng):
    a = Art()
    cfg = ((-30, -20, 330, 280, -140, 190, -14), (35, 25, 290, 330, -60, 250, 10), (-10, 40, 360, 240, 20, 300, -4))
    for dx, dy, rx, ry, a0, a1, rot_ in cfg:
        P = ell(500 + dx, 500 + dy, rx, ry, a0, a1, 260, rot_deg=rot_)
        hw(a, P, rng, 9, 1.4, w=17)
    return a


@design("circle_oval_wide", "Wide oval marker", "hand-drawn", "electric_blue", "Circling a word or caption")
def _(rng):
    a = Art()
    return hw(a, ell(500, 500, 400, 190, -150, 230, 320, rot_deg=-4, drift=0.05), rng, 5, 1.0)


# --------------------------------------------------------------- zigzags
@design("zigzag_sharp", "Sharp zigzag", "hand-drawn", "yellow", "Electric / alert emphasis")
def _(rng):
    a = Art()
    pts = [(110, 640), (230, 380), (350, 640), (470, 380), (590, 640), (710, 380), (830, 640)]
    return hw(a, np.array(pts, float), rng, 2, 0.8)


@design("zigzag_wide", "Wide zigzag", "hand-drawn", "white", "Underline or divider")
def _(rng):
    a = Art()
    pts = [(100, 560), (340, 430), (480, 590), (720, 420), (900, 570)]
    return hw(a, np.array(pts, float), rng, 3, 0.9)


@design("zigzag_rounded", "Rounded zigzag", "hand-drawn", "pink", "Playful emphasis")
def _(rng):
    a = Art()
    pts = [(110, 680), (290, 330), (500, 680), (710, 330), (890, 680)]
    return hw(a, rounded_poly(pts, 150), rng, 3, 0.9, w=28)


@design("zigzag_vertical", "Vertical zigzag", "hand-drawn", "violet", "Edge accent beside text")
def _(rng):
    a = Art()
    pts = [(420, 110), (600, 230), (400, 340), (610, 460), (400, 580), (610, 700), (420, 810)]
    return hw(a, np.array(pts, float), rng, 3, 0.9)


# --------------------------------------------------------------- wavy lines
@design("wavy_long", "Long wavy line", "hand-drawn", "electric_blue", "Divider or underline")
def _(rng):
    a = Art()
    return hw(a, wave((100, 500), (900, 500), 55, 3.5, 500), rng, 2, 0.7)


@design("wavy_double", "Double wave", "hand-drawn", "pink", "Underline a headline")
def _(rng):
    a = Art()
    hw(a, wave((110, 440), (890, 440), 40, 3, 500), rng, 2, 0.7, w=20)
    hw(a, wave((110, 580), (890, 580), 40, 3, 500, phase=1.2), rng, 2, 0.7, w=20)
    return a


@design("wavy_taper", "Tapered wave", "hand-drawn", "white", "Flowing underline")
def _(rng):
    a = Art()
    return hw(a, wave((100, 500), (900, 520), 60, 2.5, 500), rng, 2, 0.7, w=34, profile="taper_both")


# --------------------------------------------------------------- underlines
@design("underline_single", "Marker underline", "hand-drawn", "yellow", "Emphasizing a word")
def _(rng):
    a = Art()
    return hw(a, bez([100, 540], [350, 500], [650, 520], [900, 470]), rng, 4, 0.9, w=30)


@design("underline_double", "Double underline", "hand-drawn", "white", "Strong word emphasis")
def _(rng):
    a = Art()
    hw(a, bez([110, 450], [380, 425], [650, 450], [890, 420]), rng, 3, 0.8, w=22)
    hw(a, bez([150, 570], [400, 545], [660, 580], [870, 540]), rng, 3, 0.8, w=22)
    return a


@design("underline_swoosh", "Swoosh underline", "hand-drawn", "pink", "Dynamic emphasis under a title")
def _(rng):
    a = Art()
    return hw(a, bez([100, 600], [320, 640], [640, 560], [900, 400]), rng, 3, 0.8, w=38, profile="taper_both")


@design("underline_scribble", "Scribbled underline", "hand-drawn", "electric_blue", "Rough hand-marked underline")
def _(rng):
    a = Art()
    pts = [(110, 560), (880, 500), (150, 590), (860, 560), (190, 620), (820, 610)]
    return hw(a, spline(pts, 22), rng, 3, 1.0, w=18)


# --------------------------------------------------------------- hatching
@design("hatch_diagonal", "Diagonal hatching", "hand-drawn", "white", "Shading or texture patch")
def _(rng):
    a = Art()
    return hatch(a, rng, (180, 200, 820, 800), 62, 55)


@design("hatch_cross", "Crosshatching", "hand-drawn", "violet", "Dense texture / censor patch")
def _(rng):
    a = Art()
    hatch(a, rng, (200, 240, 800, 760), 70, 50, w=14)
    hatch(a, rng, (200, 240, 800, 760), 70, -50, w=14)
    return a


@design("hatch_vertical", "Vertical strokes", "hand-drawn", "yellow", "Texture beside an object")
def _(rng):
    a = Art()
    return hatch(a, rng, (200, 260, 800, 740), 56, 88, w=16, trim=0.2)


# --------------------------------------------------------------- emphasis marks
@design("burst_rays", "Radiating burst", "hand-drawn", "yellow", "Highlighting a face or reaction")
def _(rng):
    a = Art()
    n = 12
    for i in range(n):
        ang = np.radians(i * 360 / n + rng.uniform(-6, 6))
        r0, r1 = 210 + rng.uniform(-10, 20), 400 + rng.uniform(-40, 40)
        d = np.array([np.cos(ang), np.sin(ang)])
        P = np.array([500 + d * r0, 500 + d * r1])
        a.stroke(wobble(P, rng, 2, 0.6), 24, profile="taper_end", rng=rng)
    return a


@design("burst_half", "Half burst", "hand-drawn", "pink", "Accent above an object")
def _(rng):
    a = Art()
    for i, deg in enumerate(np.linspace(190, 350, 7)):
        ang = np.radians(deg + rng.uniform(-4, 4))
        d = np.array([np.cos(ang), np.sin(ang)])
        r0, r1 = 230, 420 + rng.uniform(-30, 30)
        a.stroke(wobble(np.array([[500, 760] + d * r0, [500, 760] + d * r1]).reshape(2, 2), rng, 2, 0.6),
                 24, profile="taper_end", rng=rng)
    return a


@design("ticks_trio", "Three emphasis ticks", "hand-drawn", "white", "Pop beside a word or object")
def _(rng):
    a = Art()
    for dx, dy, L in ((-130, 20, 270), (0, 0, 330), (130, 20, 270)):
        c = np.array([500 + dx, 500 + dy])
        P = np.array([c + [-60, L / 2], c + [60, -L / 2]])
        a.stroke(wobble(P, rng, 3, 0.7), 28, rng=rng, pressure=0.15)
    return a


@design("scratch_out", "Scratch-out", "hand-drawn", "pink", "Crossing out / messy emphasis")
def _(rng):
    a = Art()
    pts, y = [], 300
    for i in range(9):
        x = 230 if i % 2 == 0 else 770
        pts.append((x + rng.uniform(-25, 25), y + rng.uniform(-12, 12)))
        y += 52
    return hw(a, np.array(pts, float), rng, 3, 1.0, w=22)


@design("x_scribble", "Scribbled X", "hand-drawn", "electric_blue", "Cancel / wrong reaction")
def _(rng):
    a = Art()
    hw(a, np.array([[250, 250], [760, 760]], float), rng, 5, 1.0, w=30)
    hw(a, np.array([[760, 240], [240, 770]], float), rng, 5, 1.0, w=30)
    hw(a, np.array([[300, 240], [790, 740]], float), rng, 5, 1.0, w=16)
    return a


# --------------------------------------------------------------- loops
@design("loops_chain", "Cursive loop chain", "hand-drawn", "violet", "Decorative connector")
def _(rng):
    a = Art()
    pts = []
    for i in range(5):
        x = 150 + i * 160
        pts += [(x, 600), (x + 70, 470), (x + 130, 560), (x + 60, 650), (x + 30, 560)]
    pts.append((880, 600))
    return hw(a, spline(pts, 18), rng, 2, 0.7, w=20)


@design("loop_big", "Big single loop", "hand-drawn", "yellow", "Playful accent")
def _(rng):
    a = Art()
    pts = [(120, 700), (330, 640), (560, 300), (470, 150), (330, 270), (460, 520), (700, 660), (890, 560)]
    return hw(a, spline(pts, 30), rng, 3, 0.9)


@design("figure_eight", "Figure-eight loop", "hand-drawn", "pink", "Infinity / endless reaction")
def _(rng):
    a = Art()
    t = np.linspace(0, 2 * np.pi, 400)
    x = 500 + 330 * np.sin(t)
    y = 500 + 190 * np.sin(2 * t) * 1.0
    return hw(a, np.stack([x, y], 1), rng, 4, 1.0)


# --------------------------------------------------------------- marker & highlight
@design("marker_bold", "Bold marker dash", "hand-drawn", "white", "Quick emphasis stroke")
def _(rng):
    a = Art()
    return hw(a, bez([200, 520], [380, 490], [620, 530], [800, 480]), rng, 3, 0.8, w=64, profile="taper_both")


@design("marker_diagonal", "Diagonal marker stroke", "hand-drawn", "electric_blue", "Slash accent / transition")
def _(rng):
    a = Art()
    return hw(a, bez([230, 780], [380, 600], [600, 400], [780, 230]), rng, 3, 0.8, w=60, profile="taper_both")


@design("highlight_swipe", "Highlighter swipe", "hand-drawn", "yellow", "Highlighting a line of text")
def _(rng):
    a = Art()
    prof = lambda t: 0.9 + 0.1 * np.sin(t * 9)
    return hw(a, bez([130, 520], [380, 505], [640, 530], [870, 500]), rng, 3, 0.6, w=105, profile=prof, pressure=0.04)


@design("highlight_double", "Double highlight", "hand-drawn", "pink", "Highlighting two lines of text")
def _(rng):
    a = Art()
    hw(a, bez([140, 400], [380, 390], [640, 410], [860, 385]), rng, 3, 0.6, w=95, pressure=0.04)
    hw(a, bez([180, 600], [400, 615], [640, 590], [830, 610]), rng, 3, 0.6, w=95, pressure=0.04)
    return a


@design("highlight_box", "Rough frame", "hand-drawn", "yellow", "Boxing a word or object")
def _(rng):
    a = Art()
    x0, y0, x1, y1 = 150, 290, 850, 710
    sides = [((x0 - 30, y0), (x1 + 20, y0 + 8)), ((x1, y0 - 24), (x1 - 8, y1 + 30)),
             ((x1 + 22, y1), (x0 - 24, y1 - 10)), ((x0, y1 + 24), (x0 + 10, y0 - 28))]
    for p, q in sides:
        hw(a, np.array([p, q], float), rng, 3, 0.8, w=22)
    return a


# --------------------------------------------------------------- doodle clusters
def plus(a, c, s, w, rng):
    a.stroke(wobble(np.array([[c[0] - s, c[1]], [c[0] + s, c[1]]], float), rng, 1, 0.3), w)
    a.stroke(wobble(np.array([[c[0], c[1] - s], [c[0], c[1] + s]], float), rng, 1, 0.3), w)


@design("cluster_sparkles", "Sparkle doodle cluster", "hand-drawn", "white", "Decorating empty space")
def _(rng):
    a = Art()
    for c, s in (((330, 380), 110), ((620, 250), 70), ((650, 640), 95), ((250, 690), 55)):
        plus(a, c, s, 20, rng)
    for c in ((470, 560), (780, 430), (180, 520)):
        a.dot(c[0], c[1], 20)
    return a


@design("cluster_dots_dashes", "Dots and dashes", "hand-drawn", "yellow", "Adding personality to an edit")
def _(rng):
    a = Art()
    for c in ((250, 300), (360, 250), (470, 320), (700, 300), (610, 380)):
        a.dot(c[0], c[1], 24)
    for p, q in (((250, 580), (400, 540)), ((470, 620), (650, 570)), ((350, 720), (560, 730)), ((690, 700), (780, 650))):
        a.stroke(wobble(np.array([p, q], float), rng, 2, 0.5), 22, rng=rng)
    return a


@design("cluster_confetti", "Doodle confetti", "hand-drawn", "pink", "Celebration / reaction")
def _(rng):
    a = Art()
    hw(a, wave((190, 300), (370, 330), 28, 2, 120), rng, 1, 0.4, w=20)
    hw(a, ell(650, 290, 55, 55, 0, 340, 80), rng, 2, 0.5, w=20)
    plus(a, (300, 560), 60, 20, rng)
    hw(a, np.array([[600, 520], [760, 620]], float), rng, 2, 0.5, w=22)
    hw(a, np.array([[640, 650], [700, 760]], float), rng, 2, 0.5, w=22)
    hw(a, rounded_poly([(430, 400), (470, 480), (520, 410), (560, 480)], 20), rng, 1, 0.4, w=20)
    a.dot(220, 740, 24)
    a.dot(470, 720, 20)
    return a


# --------------------------------------------------------------- clean graphic
@design("clean_wave", "Clean wave line", "clean-graphic", "electric_blue", "Divider / underline for info edits")
def _(rng):
    a = Art()
    a.stroke(wave((100, 500), (900, 500), 55, 3, 500), CW)
    return a


@design("clean_zigzag", "Clean zigzag", "clean-graphic", "white", "Alert accent for info edits")
def _(rng):
    a = Art()
    pts = [(110, 620), (240, 380), (370, 620), (500, 380), (630, 620), (760, 380), (890, 620)]
    a.stroke(resample(np.array(pts, float), 3), CW)
    return a


@design("clean_spiral", "Clean spiral", "clean-graphic", "violet", "Focus-pull / loading accent")
def _(rng):
    a = Art()
    a.stroke(arc(500, 500, 30, 0, 360 * 3, 700, r1=340), CW)
    return a
