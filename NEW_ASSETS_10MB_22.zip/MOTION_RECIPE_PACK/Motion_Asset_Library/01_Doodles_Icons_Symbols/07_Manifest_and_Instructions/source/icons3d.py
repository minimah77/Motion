"""
Family C - 3D glossy icons. Each icon builds a list of Parts (masks + material hints).
Colour is applied at render time via themes, so every icon exists in 7 colourways.
"""
import numpy as np
from threed import *

ICONS = []


def icon(slug, name, color, use):
    def deco(fn):
        ICONS.append(dict(slug=slug, name=name, color=color, use=use, build=fn))
        return fn
    return deco


def starpts(cx, cy, R, r, n=5, rot=-90):
    pts = []
    for i in range(n * 2):
        a = np.radians(rot + i * 180 / n)
        rr = R if i % 2 == 0 else r
        pts.append((cx + rr * np.cos(a), cy + rr * np.sin(a)))
    return pts


def heartpts(cx, cy, s):
    t = np.linspace(0, 2 * np.pi, 400)
    x = 16 * np.sin(t) ** 3
    y = -(13 * np.cos(t) - 5 * np.cos(2 * t) - 2 * np.cos(3 * t) - np.cos(4 * t))
    return np.stack([cx + x * s, cy + y * s], 1)


@icon("glossy_star", "Glossy star", "yellow", "Rating, highlight, reaction pop")
def _():
    m = rounded(poly(starpts(500, 520, 380, 175)), 14)
    return [Part(m, "T", bevel=95, dome=0.45, shin=80)]


@icon("heart", "Puffy heart", "pink", "Like / love reaction")
def _():
    m = poly(heartpts(500, 500, 24))
    return [Part(m, "T", bevel=130, dome=0.6, shin=90)]


@icon("sphere", "Glossy sphere", "electric_blue", "Bullet point, bokeh accent, decoration")
def _():
    return [Part(circle(500, 500, 300), "T", bevel=300, dome=0.0, shin=120, spec=1.0)]


@icon("smiley", "Smiley face", "yellow", "Happy reaction")
def _():
    face = Part(circle(500, 500, 330), "T", bevel=260, dome=0.0, shin=100)
    eyeL = Part(ellipse(390, 430, 36, 62), "A", bevel=36, dome=0.3, shin=90, shadow=0.35)
    eyeR = Part(ellipse(610, 430, 36, 62), "A", bevel=36, dome=0.3, shin=90, shadow=0.35)
    smile = Part(stroke(arcpts(500, 520, 175, 150, 20, 160), 38), "A", bevel=19, dome=0.3, shin=80, shadow=0.3)
    return [face, eyeL, eyeR, smile]


# ------------------------------------------------------------------ helpers
_YY, _XX = np.mgrid[0:N, 0:N].astype(np.float32) * (1000.0 / N)


def halfplane(cx, cy, ang, side):
    """Mask of one side of a line through (cx,cy) at angle ang (deg). side=-1: 'above' (smaller y)."""
    a = np.radians(ang)
    nx, ny = -np.sin(a), np.cos(a)
    v = (_XX - cx) * nx + (_YY - cy) * ny
    return (np.clip(v * -side * 0.5 + 0.5, 0, 1) if True else v)


def hp(cx, cy, ang, side):
    a = np.radians(ang)
    nx, ny = -np.sin(a), np.cos(a)
    v = ((_XX - cx) * nx + (_YY - cy) * ny) * side
    return np.clip(v * 0.5 + 0.5, 0, 1)   # 1px soft edge in 1000-unit space


def astroid(cx, cy, R, pinch=3, n=400):
    t = np.linspace(0, 2 * np.pi, n)
    return np.stack([cx + R * np.cos(t) ** pinch * np.sign(np.cos(t)) ** (pinch + 1),
                     cy + R * np.sin(t) ** pinch * np.sign(np.sin(t)) ** (pinch + 1)], 1)


def spline_closed(pts, n=24):
    from engine import spline
    return spline(pts, n, closed=True)


# ------------------------------------------------------------------ icons
@icon("speech_bubble", "Speech bubble", "electric_blue", "Comment, caption pop, quote")
def _():
    body = union(rrect(150, 190, 850, 650, 140), poly([(250, 600), (225, 850), (480, 640)]))
    body = rounded(body, 9)
    dots = [Part(circle(x, 420, 46), "AW", bevel=46, dome=0.2, shin=90, shadow=0.35) for x in (350, 500, 650)]
    return [Part(body, "T", bevel=105, dome=0.45, shin=85)] + dots


@icon("lightning_bolt", "Lightning bolt", "violet", "Energy, impact, shock cut")
def _():
    m = rounded(poly([(600, 90), (240, 550), (445, 550), (365, 910), (770, 400), (550, 400), (670, 90)]), 12)
    return [Part(m, "T", bevel=75, dome=0.35, shin=90)]


@icon("flower", "Six-petal flower", "pink", "Spring / cute reaction, decoration")
def _():
    parts = []
    for i in range(6):
        a = np.radians(i * 60 - 90)
        parts.append(Part(ellipse(500 + 175 * np.cos(a), 500 + 175 * np.sin(a), 160, 100, i * 60 - 90),
                          "T", bevel=95, dome=0.4, shin=85, shadow=0.4))
    parts.append(Part(circle(500, 500, 112), "C", bevel=112, dome=0.0, shin=110, shadow=0.4))
    return parts


@icon("cloud", "Puffy cloud", "white", "Dreamy mood, weather, filler decoration")
def _():
    m = union(rrect(210, 520, 800, 730, 105), circle(370, 520, 150), circle(550, 440, 205), circle(690, 540, 135))
    return [Part(rounded(m, 10), "T", bevel=140, dome=0.6, shin=60, spec=0.7)]


@icon("camera", "Mini camera", "violet", "Photo moment, flash cut, creator vibe")
def _():
    body = Part(rrect(170, 330, 830, 740, 80), "T", bevel=80, dome=0.3, shin=90)
    bump = Part(rrect(330, 240, 530, 360, 36), "T", bevel=40, dome=0.3, shin=80, shadow=0.3)
    ring = Part(circle(500, 540, 175), "D", bevel=60, dome=0.2, shin=100, shadow=0.45)
    rim = Part(circle(500, 540, 138), "CHROME", bevel=42, dome=0.1, shin=120)
    lens = Part(circle(500, 540, 98), "B", bevel=98, dome=0.0, shin=160, refl=0.35, shadow=0.35)
    hi = Part(circle(462, 500, 20), "W", bevel=20, dome=0.0, shin=60, spec=0.0, relief=0.2)
    flash = Part(rrect(690, 385, 775, 440, 18), "W", bevel=22, dome=0.2, shin=90, shadow=0.35)
    return [body, bump, ring, rim, lens, hi, flash]


@icon("headphones", "Headphones", "electric_blue", "Music moment, listening, audio edit")
def _():
    band = Part(stroke(arcpts(500, 520, 270, 300, 180, 360), 64), "T", bevel=32, dome=0.2, shin=90, relief=1.3)
    cupL = Part(rrect(170, 500, 350, 790, 80), "T", bevel=90, dome=0.4, shin=85, shadow=0.4)
    cupR = Part(rrect(650, 500, 830, 790, 80), "T", bevel=90, dome=0.4, shin=85, shadow=0.4)
    padL = Part(rrect(290, 550, 360, 740, 30), "D", bevel=35, dome=0.2, shin=60, shadow=0.35)
    padR = Part(rrect(640, 550, 710, 740, 30), "D", bevel=35, dome=0.2, shin=60, shadow=0.35)
    return [band, cupL, cupR, padL, padR]


@icon("phone", "Smartphone", "violet", "Screen-recording, app reveal, DM")
def _():
    body = Part(rrect(290, 110, 710, 890, 95), "T", bevel=60, dome=0.2, shin=90)
    screen = Part(rrect(325, 170, 675, 830, 60), "D", bevel=30, dome=0.0, flat=0.6, shin=80, shadow=0.4)
    pill = Part(rrect(445, 195, 555, 222, 13), "T", bevel=13, dome=0.0, shin=60)
    tri = Part(rounded(poly([(430, 400), (430, 600), (610, 500)]), 7), "AW", bevel=40, dome=0.3, shin=100, shadow=0.35)
    return [body, screen, pill, tri]


@icon("gift_box", "Gift box", "pink", "Surprise, giveaway, celebration")
def _():
    box = Part(rrect(220, 470, 780, 850, 45), "T", bevel=75, dome=0.2, shin=70)
    lid = Part(rrect(185, 340, 815, 510, 45), "TL", bevel=75, dome=0.2, shin=70, shadow=0.45)
    rib1 = Part(rrect(452, 340, 548, 850, 14), "C", bevel=45, dome=0.2, shin=100, shadow=0.35)
    loopL = Part(ellipse(390, 280, 115, 68, -28), "C", bevel=60, dome=0.3, shin=90, shadow=0.35)
    loopR = Part(ellipse(610, 280, 115, 68, 28), "C", bevel=60, dome=0.3, shin=90, shadow=0.35)
    knot = Part(circle(500, 320, 52), "C", bevel=52, dome=0.0, shin=110, shadow=0.4)
    return [box, lid, rib1, loopL, loopR, knot]


@icon("music_note", "Beamed notes", "electric_blue", "Music cue, beat drop, audio sticker")
def _():
    m = union(ellipse(320, 770, 108, 80, -22), ellipse(705, 705, 108, 80, -22),
              rrect(400, 250, 455, 750, 22), rrect(785, 190, 840, 690, 22),
              poly([(400, 250), (840, 180), (840, 320), (400, 395)]))
    return [Part(rounded(m, 5), "T", bevel=45, dome=0.3, shin=90)]


@icon("planet", "Tiny planet", "violet", "Space, travel, 'out of this world'")
def _():
    ang = -18
    ring = sub(ellipse(500, 520, 355, 108, ang), ellipse(500, 520, 275, 62, ang))
    back = inter(ring, hp(500, 520, ang, -1))
    front = inter(ring, hp(500, 520, ang, 1))
    return [Part(back, "C", bevel=40, dome=0.0, relief=1.2, shin=90),
            Part(circle(500, 500, 225), "T", bevel=225, dome=0.0, shin=110),
            Part(front, "C", bevel=40, dome=0.0, relief=1.2, shin=90, shadow=0.4)]


@icon("torus_ring", "Glossy ring", "chrome", "Frame accent, loading ring, jewelry vibe")
def _():
    m = sub(circle(500, 500, 310), circle(500, 500, 175))
    return [Part(m, "T", bevel=68, dome=0.0, relief=1.4, shin=100)]


@icon("sparkles", "Sparkle trio", "white", "Magic, shine, 'glow-up' accent")
def _():
    big = rounded(poly(astroid(450, 560, 330, 3)), 3)
    s1 = rounded(poly(astroid(745, 270, 150, 3)), 3)
    s2 = rounded(poly(astroid(240, 270, 95, 3)), 3)
    return [Part(big, "T", bevel=60, dome=0.5, shin=90), Part(s1, "T", bevel=40, dome=0.5, shin=90),
            Part(s2, "T", bevel=28, dome=0.5, shin=90)]


@icon("play_button", "Play button", "pink", "Video / 'watch' call-to-action")
def _():
    base = Part(rrect(160, 250, 840, 750, 170), "T", bevel=125, dome=0.3, shin=80)
    tri = Part(rounded(poly([(415, 360), (415, 640), (665, 500)]), 12), "AW", bevel=55, dome=0.3, shin=100, shadow=0.4)
    return [base, tri]


@icon("bell", "Notification bell", "yellow", "Notification, subscribe, reminder")
def _():
    body = union(circle(500, 410, 235), poly([(268, 470), (732, 470), (800, 700), (200, 700)]),
                 rrect(170, 670, 830, 765, 45), circle(500, 185, 44))
    return [Part(rounded(body, 18), "T", bevel=125, dome=0.45, shin=85),
            Part(circle(500, 825, 68), "C", bevel=68, dome=0.0, shin=100, shadow=0.35)]


@icon("flame", "Hot flame", "pink", "'Fire' reaction, trending, hot take")
def _():
    pts = [(500, 90), (620, 270), (770, 470), (755, 660), (640, 810), (500, 870), (360, 810), (245, 660), (240, 500),
           (320, 380), (385, 470), (420, 270)]
    outer = rounded(poly(spline_closed(pts)), 7)
    c = np.array([500, 810])
    inner = rounded(poly(spline_closed([tuple(c + (np.array(p) - c) * 0.52) for p in pts])), 6)
    return [Part(outer, "T", bevel=130, dome=0.4, shin=80), Part(inner, "C", bevel=70, dome=0.4, shin=90, shadow=0.35)]


@icon("gem", "Cut gem", "electric_blue", "Premium, reward, 'value' accent")
def _():
    base = Part(poly([(300, 260), (700, 260), (850, 430), (500, 870), (150, 430)]), "T", bevel=45, dome=0.0, flat=0.5, shin=90)
    def f(pts, col):
        return Part(poly(pts), col, bevel=30, dome=0.0, flat=0.9, shin=130, spec=0.8)
    return [base,
            f([(150, 430), (300, 430), (500, 870)], "TL"), f([(300, 430), (700, 430), (500, 870)], "T"),
            f([(700, 430), (850, 430), (500, 870)], "TD"),
            f([(300, 260), (385, 260), (300, 430), (150, 430)], "TL"),
            f([(385, 260), (615, 260), (700, 430), (300, 430)], "TL"),
            f([(615, 260), (700, 260), (850, 430), (700, 430)], "TD")]


@icon("balloon", "Balloon", "violet", "Party, celebration, floating accent")
def _():
    body = Part(ellipse(500, 400, 235, 290), "T", bevel=235, dome=0.0, shin=100)
    knot = Part(rounded(poly([(500, 685), (440, 775), (560, 775)]), 8), "TD", bevel=38, dome=0.3, shin=80)
    from engine import spline
    s = spline([(500, 765), (528, 810), (474, 850), (505, 895)], 30)
    string = Part(stroke(s, 15), "G", bevel=7.5, dome=0.0, shin=40, spec=0.5, relief=0.6)
    return [string, body, knot]


@icon("location_pin", "Location pin", "pink", "'Here' marker, place reveal")
def _():
    m = rounded(union(circle(500, 395, 262), poly([(262, 520), (738, 520), (500, 890)])), 20)
    return [Part(m, "T", bevel=160, dome=0.4, shin=85),
            Part(circle(500, 395, 108), "W", bevel=108, dome=0.0, shin=110, shadow=0.45)]


@icon("crescent_moon", "Crescent moon", "yellow", "Night, calm, 'sleep' mood")
def _():
    m = rounded(sub(circle(470, 500, 340), circle(625, 430, 285)), 5)
    st = rounded(poly(astroid(745, 300, 105, 3)), 3)
    return [Part(m, "T", bevel=125, dome=0.3, shin=85), Part(st, "C", bevel=50, dome=0.5, shin=90, shadow=0.3)]


@icon("microphone", "Microphone", "black", "Voiceover, podcast, 'speak up'")
def _():
    from engine import arc as _arc
    holder = Part(stroke(arcpts(500, 450, 205, 195, 0, 180), 38), "CHROME", bevel=19, dome=0.1, shin=100, relief=1.3)
    stem = Part(rrect(478, 640, 522, 790, 14), "CHROME", bevel=22, dome=0.1, shin=90)
    base = Part(rrect(350, 775, 650, 845, 34), "CHROME", bevel=35, dome=0.2, shin=90)
    cap = Part(rrect(370, 110, 630, 590, 130), "T", bevel=130, dome=0.0, shin=90, shadow=0.4)
    grille = [Part(rrect(398, y, 602, y + 22, 11), "A", bevel=11, dome=0.0, shin=40, spec=0.4, shadow=0.0, relief=0.7)
              for y in (230, 290, 350, 410)]
    return [holder, stem, base, cap] + grille


@icon("crown", "Gem crown", "yellow", "Winner, 'king/queen', top-rank edit")
def _():
    body = rounded(poly([(170, 710), (140, 320), (340, 520), (500, 250), (660, 520), (860, 320), (830, 710)]), 16)
    band = Part(rrect(165, 690, 835, 800, 45), "TL", bevel=55, dome=0.2, shin=85, shadow=0.35)
    gems = [Part(circle(500, 250, 50), "P", bevel=50, dome=0.0, shin=130, shadow=0.35),
            Part(circle(140, 320, 42), "B", bevel=42, dome=0.0, shin=130, shadow=0.35),
            Part(circle(860, 320, 42), "B", bevel=42, dome=0.0, shin=130, shadow=0.35),
            Part(circle(500, 745, 38), "P", bevel=38, dome=0.0, shin=130, shadow=0.35)]
    return [Part(body, "T", bevel=85, dome=0.3, shin=85), band] + gems


@icon("envelope", "Message envelope", "electric_blue", "DM / email / 'new message' cue")
def _():
    body = Part(rrect(140, 250, 860, 750, 65), "T", bevel=80, dome=0.2, shin=80)
    flap = Part(rounded(poly([(150, 265), (850, 265), (500, 590)]), 12), "TL", bevel=55, dome=0.3, shin=90, shadow=0.5)
    seal = Part(poly(heartpts(500, 575, 5.2)), "C", bevel=40, dome=0.4, shin=110, shadow=0.4)
    return [body, flap, seal]


@icon("hashtag", "Hashtag", "violet", "Topic tag, trend, caption accent")
def _():
    bars = [stroke([(405, 170), (335, 830)], 88), stroke([(675, 170), (605, 830)], 88),
            stroke([(170, 400), (830, 380)], 88), stroke([(150, 640), (810, 620)], 88)]
    return [Part(b, "T", bevel=44, dome=0.1, shin=90, shadow=0.45, relief=1.2) for b in bars]


@icon("heart_eyes", "Heart-eyes emoji", "yellow", "'Obsessed' reaction")
def _():
    face = Part(circle(500, 500, 335), "T", bevel=265, dome=0.0, shin=100)
    heL = Part(poly(heartpts(375, 420, 6.6)), "P", bevel=45, dome=0.5, shin=110, shadow=0.35)
    heR = Part(poly(heartpts(625, 420, 6.6)), "P", bevel=45, dome=0.5, shin=110, shadow=0.35)
    mouth = inter(ellipse(500, 590, 160, 125), hp(500, 590, 0, 1))
    mp = Part(mouth, "D", bevel=60, dome=0.2, shin=90, shadow=0.4)
    tongue = Part(inter(ellipse(500, 690, 78, 52), mouth), "P", bevel=35, dome=0.3, shin=80)
    return [face, heL, heR, mp, tongue]
