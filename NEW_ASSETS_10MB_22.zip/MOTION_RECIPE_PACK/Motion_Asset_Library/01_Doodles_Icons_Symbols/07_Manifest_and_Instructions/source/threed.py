"""
3D glossy icon renderer: analytic heightfield -> normals -> lit/reflective shading.
Pure numpy/scipy/PIL. Output is RGBA with real alpha (incl. soft drop shadow).
"""
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as ndi

N = 1024
SSR = 2
KK = N * SSR / 1000.0

# ------------------------------------------------------------------ masks
def _new():
    img = Image.new("L", (N * SSR, N * SSR), 0)
    return img, ImageDraw.Draw(img)


def _fin(img):
    return np.asarray(img.resize((N, N), Image.LANCZOS), dtype=np.float32) / 255.0


def circle(cx, cy, r):
    img, d = _new()
    d.ellipse(((cx - r) * KK, (cy - r) * KK, (cx + r) * KK, (cy + r) * KK), fill=255)
    return _fin(img)


def ellipse(cx, cy, rx, ry, rot=0.0):
    t = np.linspace(0, 2 * np.pi, 200)
    x, y = rx * np.cos(t), ry * np.sin(t)
    a = np.radians(rot)
    return poly(np.stack([cx + x * np.cos(a) - y * np.sin(a), cy + x * np.sin(a) + y * np.cos(a)], 1))


def rrect(x0, y0, x1, y1, r):
    img, d = _new()
    d.rounded_rectangle((x0 * KK, y0 * KK, x1 * KK, y1 * KK), radius=r * KK, fill=255)
    return _fin(img)


def poly(pts):
    img, d = _new()
    d.polygon([(x * KK, y * KK) for x, y in pts], fill=255)
    return _fin(img)


def stroke(P, w):
    """Thick round-capped polyline."""
    img, d = _new()
    P = np.asarray(P, float)
    seg = np.hypot(*np.diff(P, axis=0).T)
    cum = np.concatenate([[0], np.cumsum(seg)])
    n = max(int(cum[-1] / 1.5), 2)
    t = np.linspace(0, cum[-1], n)
    X, Y = np.interp(t, cum, P[:, 0]), np.interp(t, cum, P[:, 1])
    r = w / 2 * KK
    for x, y in zip(X * KK, Y * KK):
        d.ellipse((x - r, y - r, x + r, y + r), fill=255)
    return _fin(img)


def arcpts(cx, cy, rx, ry, a0, a1, n=120):
    a = np.radians(np.linspace(a0, a1, n))
    return np.stack([cx + rx * np.cos(a), cy + ry * np.sin(a)], 1)


def rounded(mask, s):
    """Round off corners (convex AND concave) by blur + re-threshold."""
    b = ndi.gaussian_filter(mask, s)
    return np.clip((b - 0.5) * (s * 1.4) + 0.5, 0, 1)


def union(*ms):
    return np.clip(np.max(ms, axis=0), 0, 1)


def sub(a, b):
    return np.clip(a * (1 - b), 0, 1)


def inter(a, b):
    return np.clip(a * b, 0, 1)


def shift(m, dx, dy):
    return ndi.shift(m, (dy, dx), order=1, mode="constant")


# ------------------------------------------------------------------ colours
def rgb(h):
    return np.array([int(h[i:i + 2], 16) for i in (1, 3, 5)], np.float32) / 255.0


THEMES = {
    "white":         dict(base=rgb("#F4F6FB"), mat="glossy", dark=False),
    "black":         dict(base=rgb("#17171D"), mat="glossy", dark=True),
    "chrome":        dict(base=rgb("#C9CFD9"), mat="chrome", dark=False),
    "electric_blue": dict(base=rgb("#1F63FF"), mat="glossy", dark=False),
    "violet":        dict(base=rgb("#8B4DFF"), mat="glossy", dark=False),
    "pink":          dict(base=rgb("#FF4DA6"), mat="glossy", dark=False),
    "yellow":        dict(base=rgb("#FFC21F"), mat="glossy", dark=False),
}
FIXED = {
    "W": rgb("#F6F7FB"), "D": rgb("#14141A"), "Y": rgb("#FFC21F"), "P": rgb("#FF4DA6"),
    "B": rgb("#1F63FF"), "V": rgb("#8B4DFF"), "G": rgb("#CBD1DB"),
}


def resolve(spec, theme):
    """Return (base_rgb, mat) for a part colour spec under a theme."""
    th = THEMES[theme]
    if isinstance(spec, tuple):
        return np.array(spec, np.float32), "glossy"
    if spec == "T":
        return th["base"], th["mat"]
    if spec == "TL":
        b = th["base"] + (1 - th["base"]) * 0.35
        return (b if th["mat"] != "chrome" else th["base"]), th["mat"]
    if spec == "TD":
        return th["base"] * 0.68, th["mat"]
    if spec == "A":   # contrasting accent for details on a theme body
        return (FIXED["W"] if th["dark"] else FIXED["D"]), "glossy"
    if spec == "C":   # contrasting complementary colour (yellow unless theme is yellow)
        return (FIXED["P"] if theme == "yellow" else FIXED["Y"]), "glossy"
    if spec == "AW":  # white detail on saturated/black bodies, dark detail on light bodies
        return (FIXED["W"] if theme in ("electric_blue", "violet", "pink", "black") else FIXED["D"]), "glossy"
    if spec == "CHROME":
        return FIXED["G"], "chrome"
    return FIXED[spec], "glossy"


# ------------------------------------------------------------------ shading
LV = np.array([-0.46, -0.62, 0.64], np.float32)
LV /= np.linalg.norm(LV)
HV = LV + np.array([0, 0, 1], np.float32)
HV /= np.linalg.norm(HV)
L2 = np.array([0.55, 0.5, 0.45], np.float32)
L2 /= np.linalg.norm(L2)
H2 = L2 + np.array([0, 0, 1], np.float32)
H2 /= np.linalg.norm(H2)

_STOPS = np.array([0.0, 0.2, 0.38, 0.47, 0.58, 0.78, 1.0])
_CHROME = np.array([[232, 237, 246], [158, 168, 186], [26, 32, 46], [70, 80, 102],
                    [208, 221, 240], [250, 252, 255], [255, 255, 255]], np.float32) / 255.0
_GSTOPS = np.array([0.0, 0.36, 0.52, 0.72, 1.0])
_GLOSS_ENV = np.array([[0.03, 0.03, 0.05], [0.03, 0.03, 0.05], [0.18, 0.2, 0.26], [0.85, 0.9, 0.98],
                       [1.0, 1.0, 1.0]], np.float32)


def _lut(u, table, stops=None):
    st = _STOPS if stops is None else stops
    return np.stack([np.interp(u, st, table[:, i]) for i in range(3)], axis=-1)


class Part:
    def __init__(self, mask, color="T", bevel=60, dome=0.5, relief=1.0, shin=70, spec=1.0,
                 shadow=0.0, flat=0.0, refl=None, alpha=1.0):
        self.mask = np.clip(mask, 0, 1).astype(np.float32)
        self.color, self.bevel, self.dome, self.relief = color, bevel, dome, relief
        self.shin, self.spec, self.shadow, self.flat, self.refl, self.alpha = shin, spec, shadow, flat, refl, alpha
        self._n = None

    def normals(self):
        if self._n is not None:
            return self._n
        m = self.mask
        binary = m > 0.5
        d = ndi.distance_transform_edt(binary).astype(np.float32)
        t = np.clip(d / max(self.bevel, 1), 0, 1)
        h = self.bevel * np.sqrt(np.clip(1 - (1 - t) ** 2, 0, 1))
        if self.dome:
            dm = d / max(d.max(), 1)
            h = h + self.dome * self.bevel * np.sqrt(dm)
        if self.flat:
            h = h * (1 - self.flat)
        h = ndi.gaussian_filter(h, max(2.0, self.bevel * 0.085))
        gy, gx = np.gradient(h)
        nx, ny = -gx * self.relief, -gy * self.relief
        nz = np.ones_like(nx)
        inv = 1 / np.sqrt(nx * nx + ny * ny + nz * nz)
        self._n = (nx * inv, ny * inv, nz * inv, d)
        return self._n

    def shade(self, theme):
        nx, ny, nz, d = self.normals()
        base, mat = resolve(self.color, theme)
        dark = (base.sum() < 0.9)
        ndl = np.clip(nx * LV[0] + ny * LV[1] + nz * LV[2], 0, 1)
        ys, xs = np.nonzero(self.mask > 0.5)
        if len(ys):
            yrel = np.clip((np.arange(N)[:, None] - ys.min()) / max(ys.max() - ys.min(), 1), 0, 1)
        else:
            yrel = np.zeros((N, 1))
        ry = 2 * nz * ny
        rx = 2 * nz * nx
        u = np.clip((-ry + 1) / 2 + 0.14 * rx + 0.05, 0, 1)
        if mat == "chrome":
            col = _lut(u, _CHROME) * (0.82 + 0.28 * ndl[..., None])
            col = col * (0.93 + 0.07 * (1 - yrel))[..., None]
            tint = np.array([0.97, 0.99, 1.04], np.float32)
            col = col * tint
        else:
            amb = 0.50 if not dark else 0.30
            col = base[None, None, :] * (amb + (1.05 - amb) * ndl[..., None])
            col = col * (0.94 + 0.12 * (1 - yrel))[..., None]
            # saturated falloff toward the bottom edge (subsurface-ish)
            bottom = np.clip(ny, 0, 1)[..., None]
            col = col + base[None, None, :] * 0.18 * bottom * (0.7 if not dark else 0.4)
            refl_w = self.refl if self.refl is not None else (0.20 if dark else (0.10 if base.min() > 0.85 else 0.07))
            col = col + _lut(u, _GLOSS_ENV, _GSTOPS) * refl_w
            rim = ((1 - nz) ** 2.2)[..., None]
            col = col + rim * (0.20 if not dark else 0.35) * (0.45 * base + 0.55)[None, None, :]
        # specular (key + soft fill)
        sp = np.clip(nx * HV[0] + ny * HV[1] + nz * HV[2], 0, 1)
        spec = (sp ** self.shin) * (0.95 * self.spec) + (sp ** max(self.shin / 6, 6)) * (0.18 * self.spec)
        sp2 = np.clip(nx * H2[0] + ny * H2[1] + nz * H2[2], 0, 1)
        spec2 = (sp2 ** 24) * (0.22 * self.spec)
        col = col + spec[..., None] + spec2[..., None] * (0.6 * base + 0.4)[None, None, :]
        # soft edge darkening gives the bevel a contact feel
        edge = np.clip(d / 5.0, 0, 1)
        col = col * (0.88 + 0.12 * edge)[..., None]
        return np.clip(col, 0, 1), self.mask * self.alpha


def _over(rgb_c, a_c, rgb_l, a_l):
    out_a = a_l + a_c * (1 - a_l)
    safe = np.maximum(out_a, 1e-6)
    out = (rgb_l * a_l[..., None] + rgb_c * (a_c * (1 - a_l))[..., None]) / safe[..., None]
    return out, out_a


def render(parts, theme, shadow=True, offset=(8, 20), blur=17, sh_op=0.36, center=True):
    rgb_c = np.zeros((N, N, 3), np.float32)
    a_c = np.zeros((N, N), np.float32)
    for p in parts:
        col, a = p.shade(theme)
        if p.shadow > 0:   # soft contact shadow of this part falling on what is beneath
            s = ndi.gaussian_filter(shift(p.mask, 4, 9), 7) * p.shadow
            rgb_c = rgb_c * (1 - (s * (a_c > 0.01))[..., None])
        rgb_c, a_c = _over(rgb_c, a_c, col, a)
    obj_a = a_c.copy()
    # centre the object
    ys, xs = np.nonzero(obj_a > 0.03)
    dx = int(round(N / 2 - (xs.min() + xs.max()) / 2))
    dy = int(round(N / 2 - 14 - (ys.min() + ys.max()) / 2))
    rgb_c = ndi.shift(rgb_c, (dy, dx, 0), order=1, mode="constant")
    a_c = ndi.shift(a_c, (dy, dx), order=1, mode="constant")
    if shadow:
        sh = ndi.gaussian_filter(shift(a_c, *offset), blur) * sh_op
        base_rgb = np.zeros_like(rgb_c)
        rgb_c, a_c = _over(base_rgb, sh, rgb_c, a_c)
    out = np.dstack([np.clip(rgb_c, 0, 1), a_c])
    return Image.fromarray((out * 255 + 0.5).astype(np.uint8), "RGBA")
