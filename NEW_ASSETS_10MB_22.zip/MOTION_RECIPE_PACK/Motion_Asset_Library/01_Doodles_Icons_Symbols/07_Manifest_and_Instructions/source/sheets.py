import os, glob
from PIL import Image, ImageDraw, ImageFont

FONT = "/usr/share/fonts/opentype/inter/Inter-Medium.otf"
if not os.path.exists(FONT):
    FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

DARK = (18, 18, 24)
DARK_TILE = (30, 31, 40)
LIGHT = (240, 241, 245)
LIGHT_TILE = (255, 255, 255)
LIGHT_COLORS = ("white", "chrome", "yellow", "pink")  # need a dark tile


def color_of(fn):
    for c in ("electric_blue", "white", "black", "chrome", "violet", "pink", "yellow"):
        if f"_{c}_" in fn:
            return c
    return "white"


def contact_sheet(items, out, title, cols=6, cell=250, bg_mode="contrast", sheet_bg=None):
    """items: list of (path, label). bg_mode: 'dark' | 'light' | 'contrast'."""
    font = ImageFont.truetype(FONT, 13)
    tfont = ImageFont.truetype(FONT, 26)
    pad, label_h, head = 18, 34, 78
    rows = -(-len(items) // cols)
    W = cols * (cell + pad) + pad
    H = head + rows * (cell + label_h + pad) + pad
    if sheet_bg is None:
        sheet_bg = LIGHT if bg_mode == "light" else DARK
    sheet = Image.new("RGB", (W, H), sheet_bg)
    dr = ImageDraw.Draw(sheet)
    txt_col = (20, 20, 28) if sheet_bg == LIGHT else (235, 236, 242)
    dr.text((pad, 24), title, font=tfont, fill=txt_col)
    for i, (path, label) in enumerate(items):
        r, c = divmod(i, cols)
        x = pad + c * (cell + pad)
        y = head + r * (cell + label_h + pad)
        mode = bg_mode
        if bg_mode == "contrast":
            mode = "dark" if color_of(os.path.basename(path)) in LIGHT_COLORS else "light"
        if mode == "dark":
            tile = DARK_TILE
        else:
            tile = LIGHT_TILE if sheet_bg == LIGHT else (226, 228, 236)
        dr.rounded_rectangle((x, y, x + cell, y + cell), 14, fill=tile)
        im = Image.open(path).convert("RGBA")
        inner = cell - 20
        im = im.resize((inner, inner), Image.LANCZOS)
        sheet.paste(im, (x + 10, y + 10), im)
        f2, size = font, 13
        while dr.textlength(label, font=f2) > cell - 6 and size > 8:
            size -= 1
            f2 = ImageFont.truetype(FONT, size)
        dr.text((x + (cell - dr.textlength(label, font=f2)) / 2, y + cell + 8), label, font=f2, fill=txt_col)
    sheet.save(out, optimize=True)
    return out
