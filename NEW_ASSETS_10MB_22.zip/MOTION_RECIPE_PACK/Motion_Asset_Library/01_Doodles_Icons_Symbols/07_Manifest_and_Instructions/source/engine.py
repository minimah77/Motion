"""
Motion Asset Library - shared stroke/render engine (Pillow + numpy only).

Design space is a 1000 x 1000 box (y down). Artwork is rendered supersampled
into an 'L' alpha mask, downsampled, centred on a transparent RGBA canvas, and
then colourised. One mask -> any number of colour variants.
"""
import math
import numpy as np
from PIL import Image, ImageDraw

OUT = 1024          # final export size (px)
SS = 3              # supersampling factor
K = OUT * SS / 1000.0   # design units -> supersampled pixels

COLORS = {
    "white":         "#FFFFFF",
    "black":         "#0D0D10",
    "chrome":        ("#F6F8FB", "#9AA3B0"),   # vertical silver gradient
    "electric_blue": "#1F63FF",
    "violet":        "#8B4DFF",
    "pink":          "#FF4DA6",
    "yellow":        "#FFC21F",
}
COLOR_ORDER = ["white", "black", "chrome", "electric_blue", "violet", "pink", "yellow"]


# ------------------------------------------------------------------ geometry
def arr(p):
    return np.asarray(p, dtype=float)


def seglen(P):
    return np.hypot(*np.diff(P, axis=0).T)


def total_len(P):
    return float(seglen(P).sum())


def resample(P, step=4.0):
    P = arr(P)
    d = np.concatenate([[0], np.cumsum(seglen(P))])
    if d[-1] < 1e-6:
        return P
    n = max(int(d[-1] / step), 2)
    t = np.linspace(0, d[-1], n)
    return np.stack([np.interp(t, d, P[:, 0]), np.interp(t, d, P[:, 1])], axis=1)


def bez(p0, p1, p2, p3, n=200):
    t = np.linspace(0, 1, n)[:, None]
    p0, p1, p2, p3 = map(arr, (p0, p1, p2, p3))
    return ((1 - t) ** 3) * p0 + 3 * ((1 - t) ** 2) * t * p1 + 3 * (1 - t) * t * t * p2 + t ** 3 * p3


def qbez(p0, p1, p2, n=40):
    t = np.linspace(0, 1, n)[:, None]
    p0, p1, p2 = map(arr, (p0, p1, p2))
    return ((1 - t) ** 2) * p0 + 2 * (1 - t) * t * p1 + t * t * p2


def spline(pts, n_per=30, closed=False):
    """Uniform Catmull-Rom spline through points."""
    P = arr(pts)
    if closed:
        P = np.vstack([P[-1], P, P[0], P[1]])
    else:
        P = np.vstack([2 * P[0] - P[1], P, 2 * P[-1] - P[-2]])
    out = []
    for i in range(1, len(P) - 2):
        p0, p1, p2, p3 = P[i - 1], P[i], P[i + 1], P[i + 2]
        for t in np.linspace(0, 1, n_per, endpoint=False):
            t2, t3 = t * t, t * t * t
            out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 +
                              (-p0 + 3 * p1 - 3 * p2 + p3) * t3))
    out.append(P[-2] if not closed else P[2])
    return arr(out)


def arc(cx, cy, r, a0, a1, n=240, r1=None):
    """Arc in screen coords (y down); angles in degrees, increasing = clockwise.
    Optional r1 -> radius changes linearly (spiral)."""
    a = np.radians(np.linspace(a0, a1, n))
    rr = np.linspace(r, r if r1 is None else r1, n)
    return np.stack([cx + rr * np.cos(a), cy + rr * np.sin(a)], axis=1)


def rounded_poly(pts, radius=60, n=24):
    pts = arr(pts)
    out = [pts[0]]
    for i in range(1, len(pts) - 1):
        a, b, c = pts[i - 1], pts[i], pts[i + 1]
        r = min(radius, np.linalg.norm(b - a) / 2.2, np.linalg.norm(c - b) / 2.2)
        u1 = (a - b) / np.linalg.norm(a - b)
        u2 = (c - b) / np.linalg.norm(c - b)
        s, e = b + u1 * r, b + u2 * r
        out.extend(qbez(s, b, e, n))
    out.append(pts[-1])
    return arr(out)


def wave(p0, p1, amp, cycles, n=400, env=None, phase=0.0):
    p0, p1 = arr(p0), arr(p1)
    d = p1 - p0
    L = np.linalg.norm(d)
    u = d / L
    nrm = np.array([-u[1], u[0]])
    t = np.linspace(0, 1, n)
    a = amp * (np.ones_like(t) if env is None else env(t))
    off = a * np.sin(2 * math.pi * cycles * t + phase)
    return p0 + np.outer(t * L, u) + np.outer(off, nrm)


def smooth_noise(n, wl, rng):
    k = int(n / max(wl, 1)) + 3
    vals = rng.uniform(-1, 1, k)
    x = np.arange(n) / max(wl, 1)
    i = x.astype(int)
    f = x - i
    f = f * f * (3 - 2 * f)
    return vals[i] * (1 - f) + vals[i + 1] * f


def normals(P):
    g = np.gradient(P, axis=0)
    g /= np.maximum(np.linalg.norm(g, axis=1, keepdims=True), 1e-9)
    return np.stack([-g[:, 1], g[:, 0]], axis=1)


def wobble(P, rng, amp=5.0, fine=1.1, step=5.0, pin_ends=False):
    """Hand-drawn wobble: low-frequency drift + a touch of tremor."""
    P = resample(P, step)
    n = len(P)
    off = amp * smooth_noise(n, 40, rng) + fine * smooth_noise(n, 9, rng)
    if pin_ends:
        env = np.minimum(1, np.minimum(np.arange(n), np.arange(n)[::-1]) / 8.0)
        off = off * env
    return P + normals(P) * off[:, None]


def trim_end(P, dist):
    P = arr(P)
    d = np.concatenate([[0], np.cumsum(seglen(P))])
    keep = d <= d[-1] - dist
    if keep.sum() < 2:
        return P
    Q = P[keep]
    t = d[-1] - dist
    j = np.searchsorted(d, t)
    a, b = P[j - 1], P[j]
    f = (t - d[j - 1]) / max(d[j] - d[j - 1], 1e-9)
    return np.vstack([Q, a + (b - a) * f])


def trim_start(P, dist):
    return trim_end(arr(P)[::-1], dist)[::-1]


def end_dir(P, look=40.0):
    P = arr(P)
    d = np.concatenate([[0], np.cumsum(seglen(P))])
    j = np.searchsorted(d, max(d[-1] - look, 0))
    v = P[-1] - P[min(j, len(P) - 2)]
    return v / max(np.linalg.norm(v), 1e-9)


def rot(v, deg):
    a = math.radians(deg)
    c, s = math.cos(a), math.sin(a)
    return np.array([c * v[0] - s * v[1], s * v[0] + c * v[1]])


def dashes(P, dash, gap, rng=None, jitter=0.0):
    P = resample(P, 3.0)
    d = np.concatenate([[0], np.cumsum(seglen(P))])
    out, pos = [], 0.0
    while pos < d[-1]:
        dl = dash * (1 + (rng.uniform(-jitter, jitter) if rng is not None else 0))
        e = min(pos + dl, d[-1])
        m = (d >= pos) & (d <= e)
        if m.sum() >= 2:
            out.append(P[m])
        pos = e + gap * (1 + (rng.uniform(-jitter, jitter) if rng is not None else 0))
    return out


# ------------------------------------------------------------------ artwork
class Art:
    """Container of strokes (variable-width polylines), fills and dots."""

    def __init__(self):
        self.strokes = []   # (P, widths)
        self.polys = []     # closed polygons (filled)
        self.dots = []      # (x, y, r)

    def stroke(self, P, w=26.0, profile=None, rng=None, pressure=0.0):
        P = resample(P, 2.0)
        n = len(P)
        t = np.linspace(0, 1, n)
        W = np.full(n, float(w))
        if pressure and rng is not None:
            W *= 1 + pressure * smooth_noise(n, 90, rng)
        if profile == "taper_start":
            W *= 0.08 + 0.92 * np.clip(t / 0.85, 0, 1) ** 0.9
        elif profile == "taper_end":
            W *= 0.12 + 0.88 * np.clip((1 - t) / 0.85, 0, 1) ** 0.9
        elif profile == "taper_both":
            W *= 0.1 + 0.9 * np.sin(np.pi * np.clip(t, 0, 1)) ** 0.7
        elif profile == "swell":
            W *= 0.35 + 0.65 * np.clip(t, 0, 1) ** 0.8
        elif callable(profile):
            W *= profile(t)
        self.strokes.append((P, W))
        return self

    def poly(self, pts, outline=10.0, rng=None, wob=0.0):
        pts = arr(pts)
        closed = np.vstack([pts, pts[:1]])
        P = resample(closed, 3.0)
        if rng is not None and wob > 0:
            n = len(P)
            off = wob * smooth_noise(n, 14, rng)
            P = P + normals(P) * off[:, None]
        self.polys.append(P)
        if outline > 0:
            self.stroke(P, w=outline)
        return self

    def dot(self, x, y, r):
        self.dots.append((x, y, r))
        return self


def render_mask(art, canvas_units=1000.0):
    size = OUT * SS
    m = Image.new("L", (size, size), 0)
    dr = ImageDraw.Draw(m)
    for P in art.polys:
        dr.polygon([(x * K, y * K) for x, y in P], fill=255)
    for P, W in art.strokes:
        for (x, y), w in zip(P, W):
            r = max(w * 0.5 * K, 0.6)
            dr.ellipse((x * K - r, y * K - r, x * K + r, y * K + r), fill=255)
    for x, y, r in art.dots:
        r *= K
        dr.ellipse((x * K - r, y * K - r, x * K + r, y * K + r), fill=255)
    m = m.resize((OUT, OUT), Image.LANCZOS)
    return center_mask(m)


def center_mask(m):
    bb = m.point(lambda v: 255 if v > 8 else 0).getbbox()
    if not bb:
        return m
    cx, cy = (bb[0] + bb[2]) / 2, (bb[1] + bb[3]) / 2
    dx, dy = int(round(OUT / 2 - cx)), int(round(OUT / 2 - cy))
    out = Image.new("L", m.size, 0)
    out.paste(m, (dx, dy))
    return out


def colorize(mask, color):
    spec = COLORS[color]
    size = mask.size
    if isinstance(spec, tuple):
        top = np.array([int(spec[0][i:i + 2], 16) for i in (1, 3, 5)], float)
        bot = np.array([int(spec[1][i:i + 2], 16) for i in (1, 3, 5)], float)
        bb = mask.getbbox() or (0, 0, size[0], size[1])
        y = np.clip((np.arange(size[1]) - bb[1]) / max(bb[3] - bb[1], 1), 0, 1)[:, None, None]
        rgb = (top * (1 - y) + bot * y) * np.ones((1, size[0], 1))
        rgb = rgb.astype(np.uint8)
        img = Image.fromarray(rgb, "RGB")
    else:
        rgb = tuple(int(spec[i:i + 2], 16) for i in (1, 3, 5))
        img = Image.new("RGB", size, rgb)
    out = img.convert("RGBA")
    out.putalpha(mask)
    return out
