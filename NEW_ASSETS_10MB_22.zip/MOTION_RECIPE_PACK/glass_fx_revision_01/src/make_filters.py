"""Builds the 5 SVG glass/distortion filters, demo SVGs, displacement-map PNGs,
filtered PNG renders and before/after comparisons."""
import os, json
import numpy as np
from PIL import Image
from common import *

OUT = os.path.join(ROOT, "svg_filters")
MAPS = os.path.join(ROOT, "displacement_maps")
REGION = 'filterUnits="userSpaceOnUse" x="-200" y="-200" width="1480" height="2320" color-interpolation-filters="sRGB"'
IDENT = "1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 0 1"   # force alpha=1 on noise

# ---------------------------------------------------------------- filters
F = {}

# 01 — wavy optical distortion with chromatic split (3 displacement passes)
F["01_wavy_optical"] = dict(
    id="gf-wavy-optical", title="Wavy optical distortion (chromatic split)",
    body=f'''<filter id="gf-wavy-optical" {REGION}>
  <!-- stretched low-frequency noise = long horizontal swells -->
  <feTurbulence type="fractalNoise" baseFrequency="0.0016 0.0062" numOctaves="1" seed="7" result="n"/>
  <feColorMatrix in="n" type="matrix" values="{IDENT}" result="m0"/>
  <feComponentTransfer in="m0" result="map">
    <feFuncR type="linear" slope="2.6" intercept="-0.8"/><feFuncG type="linear" slope="1.7" intercept="-0.35"/>
  </feComponentTransfer>
  <!-- one displacement per colour channel, different strength = optical dispersion -->
  <feDisplacementMap in="SourceGraphic" in2="map" scale="74" xChannelSelector="R" yChannelSelector="G" result="dR"/>
  <feDisplacementMap in="SourceGraphic" in2="map" scale="62"  xChannelSelector="R" yChannelSelector="G" result="dG"/>
  <feDisplacementMap in="SourceGraphic" in2="map" scale="50"  xChannelSelector="R" yChannelSelector="G" result="dB"/>
  <feColorMatrix in="dR" type="matrix" values="1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0" result="cR"/>
  <feColorMatrix in="dG" type="matrix" values="0 0 0 0 0  0 1 0 0 0  0 0 0 0 0  0 0 0 1 0" result="cG"/>
  <feColorMatrix in="dB" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 1 0 0  0 0 0 1 0" result="cB"/>
  <feBlend in="cR" in2="cG" mode="screen" result="rg"/>
  <feBlend in="rg" in2="cB" mode="screen"/>
</filter>''',
    map_chain=f'''<feTurbulence type="fractalNoise" baseFrequency="0.0016 0.0062" numOctaves="1" seed="7" result="n"/>
  <feColorMatrix in="n" type="matrix" values="{IDENT}" result="m0"/>
  <feComponentTransfer in="m0"><feFuncR type="linear" slope="2.6" intercept="-0.8"/><feFuncG type="linear" slope="1.7" intercept="-0.35"/></feComponentTransfer>''',
    params="displacement scale 74/62/50 px (R/G/B) · noise 0.0016×0.0062 · 1 octave · seed 7")

# 02 — liquid refraction: smooth warp + lit liquid surface (specular + diffuse)
F["02_liquid_refraction"] = dict(
    id="gf-liquid-refraction", title="Liquid refraction (warp + specular surface)",
    body=f'''<filter id="gf-liquid-refraction" {REGION}>
  <feTurbulence type="fractalNoise" baseFrequency="0.0042 0.0042" numOctaves="2" seed="21" result="n"/>
  <feColorMatrix in="n" type="matrix" values="{IDENT}" result="m0"/>
  <feComponentTransfer in="m0" result="map">
    <feFuncR type="linear" slope="2.7" intercept="-0.85"/><feFuncG type="linear" slope="2.7" intercept="-0.85"/>
  </feComponentTransfer>
  <feGaussianBlur in="SourceGraphic" stdDeviation="0.5" result="src"/>
  <feDisplacementMap in="src" in2="map" scale="96" xChannelSelector="R" yChannelSelector="G" result="warp"/>
  <!-- noise R channel becomes the height field for the liquid surface -->
  <feColorMatrix in="m0" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  1 0 0 0 0" result="h0"/>
  <feGaussianBlur in="h0" stdDeviation="7" result="h"/>
  <feDiffuseLighting in="h" surfaceScale="40" diffuseConstant="1" lighting-color="#ffffff" result="diff">
    <feDistantLight azimuth="230" elevation="52"/>
  </feDiffuseLighting>
  <feComponentTransfer in="diff" result="diffBoost"><feFuncR type="linear" slope="1.27"/><feFuncG type="linear" slope="1.27"/><feFuncB type="linear" slope="1.27"/></feComponentTransfer>
  <feBlend in="warp" in2="diffBoost" mode="multiply" result="shaded"/>
  <feSpecularLighting in="h" surfaceScale="40" specularConstant="0.9" specularExponent="70" lighting-color="#ffffff" result="spec">
    <feDistantLight azimuth="230" elevation="44"/>
  </feSpecularLighting>
  <feComposite in="spec" in2="shaded" operator="arithmetic" k1="0" k2="1" k3="1" k4="0"/>
</filter>''',
    map_chain=f'''<feTurbulence type="fractalNoise" baseFrequency="0.0042 0.0042" numOctaves="2" seed="21" result="n"/>
  <feColorMatrix in="n" type="matrix" values="{IDENT}" result="m0"/>
  <feComponentTransfer in="m0"><feFuncR type="linear" slope="2.7" intercept="-0.85"/><feFuncG type="linear" slope="2.7" intercept="-0.85"/></feComponentTransfer>''',
    params="displacement scale 96 px · noise 0.0042 · 2 octaves · seed 21 · height blur σ7 · light az 230° el 44–52° · surfaceScale 40")

# 03 — heat-wave shimmer: horizontal-only displacement from vertically-fine noise
F["03_heat_wave"] = dict(
    id="gf-heat-wave", title="Heat-wave shimmer",
    body=f'''<filter id="gf-heat-wave" {REGION}>
  <feTurbulence type="fractalNoise" baseFrequency="0.0035 0.028" numOctaves="2" seed="3" result="n"/>
  <!-- G forced to ~0.5 + a trace of noise: displacement is almost purely horizontal -->
  <feColorMatrix in="n" type="matrix" values="1 0 0 0 0  0.22 0 0 0 0.39  0 0 1 0 0  0 0 0 0 1" result="m0"/>
  <feComponentTransfer in="m0" result="map">
    <feFuncR type="linear" slope="2.5" intercept="-0.75"/>
  </feComponentTransfer>
  <feDisplacementMap in="SourceGraphic" in2="map" scale="30" xChannelSelector="R" yChannelSelector="G" result="shimmer"/>
  <!-- the faint horizontal smear real heat haze has -->
  <feGaussianBlur in="shimmer" stdDeviation="0.9 0.3" result="soft"/>
  <feComposite in="soft" in2="shimmer" operator="arithmetic" k1="0" k2="0.6" k3="0.4" k4="0"/>
</filter>''',
    map_chain=f'''<feTurbulence type="fractalNoise" baseFrequency="0.0035 0.028" numOctaves="2" seed="3" result="n"/>
  <feColorMatrix in="n" type="matrix" values="1 0 0 0 0  0.22 0 0 0 0.39  0 0 1 0 0  0 0 0 0 1" result="m0"/>
  <feComponentTransfer in="m0"><feFuncR type="linear" slope="2.5" intercept="-0.75"/></feComponentTransfer>''',
    params="displacement scale 30 px (mostly X) · noise 0.0035×0.028 · 2 octaves · seed 3 · blur 0.9×0.3")

# 04 — organic uneven refractive surface (crease network, hammered/crinkled glass)
F["04_organic_refractive"] = dict(
    id="gf-organic-refractive", title="Organic uneven refractive surface",
    body=f'''<filter id="gf-organic-refractive" {REGION}>
  <!-- "turbulence" noise = crease/valley network (cell-like lenses); re-centre its 0.26 mean to 0.5 -->
  <feTurbulence type="turbulence" baseFrequency="0.0062 0.0062" numOctaves="1" seed="44" result="n"/>
  <feColorMatrix in="n" type="matrix" values="{IDENT}" result="m0"/>
  <feComponentTransfer in="m0" result="mapRaw">
    <feFuncR type="linear" slope="2.0" intercept="-0.02"/><feFuncG type="linear" slope="2.0" intercept="-0.02"/>
  </feComponentTransfer>
  <!-- soften the creases so they bend light instead of tearing it -->
  <feGaussianBlur in="mapRaw" stdDeviation="3" result="map"/>
  <feGaussianBlur in="SourceGraphic" stdDeviation="0.5" result="src"/>
  <feDisplacementMap in="src" in2="map" scale="44" xChannelSelector="R" yChannelSelector="G" result="w1"/>
  <!-- second, finer unevenness -->
  <feTurbulence type="fractalNoise" baseFrequency="0.038" numOctaves="2" seed="12" result="n2"/>
  <feColorMatrix in="n2" type="matrix" values="{IDENT}" result="m2"/>
  <feComponentTransfer in="m2" result="map2">
    <feFuncR type="linear" slope="2.2" intercept="-0.6"/><feFuncG type="linear" slope="2.2" intercept="-0.6"/>
  </feComponentTransfer>
  <feDisplacementMap in="w1" in2="map2" scale="12" xChannelSelector="R" yChannelSelector="G" result="w2"/>
  <!-- only sparse, tight glints where the surface turns toward the light -->
  <feColorMatrix in="m0" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  1 0 0 0 0" result="h0"/>
  <feGaussianBlur in="h0" stdDeviation="3.5" result="h"/>
  <feSpecularLighting in="h" surfaceScale="16" specularConstant="0.7" specularExponent="80" lighting-color="#e8f6ff" result="spec">
    <feDistantLight azimuth="300" elevation="38"/>
  </feSpecularLighting>
  <feComposite in="spec" in2="w2" operator="arithmetic" k1="0" k2="1" k3="1" k4="0"/>
</filter>''',
    map_chain=f'''<feTurbulence type="turbulence" baseFrequency="0.0062 0.0062" numOctaves="1" seed="44" result="n"/>
  <feColorMatrix in="n" type="matrix" values="{IDENT}" result="m0"/>
  <feComponentTransfer in="m0" result="mapRaw"><feFuncR type="linear" slope="2.0" intercept="-0.02"/><feFuncG type="linear" slope="2.0" intercept="-0.02"/></feComponentTransfer>
  <feGaussianBlur in="mapRaw" stdDeviation="3"/>''',
    params="pass 1: scale 44 px, creased noise 0.0062 ×1 octave (map blur σ3) · pass 2: scale 12 px, noise 0.038 · sparse specular glints (exp 80)")

# 05 — frosted glass: micro-scatter + two-scale blur + grain + milky veil
F["05_frosted_scatter"] = dict(
    id="gf-frosted-scatter", title="Frosted glass (scatter + two-scale blur)",
    body=f'''<filter id="gf-frosted-scatter" {REGION}>
  <!-- micro-surface roughness scatters rays: very fine, strong-frequency displacement -->
  <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="2" seed="9" result="n"/>
  <feColorMatrix in="n" type="matrix" values="{IDENT}" result="m0"/>
  <feComponentTransfer in="m0" result="map">
    <feFuncR type="linear" slope="2.4" intercept="-0.7"/><feFuncG type="linear" slope="2.4" intercept="-0.7"/>
  </feComponentTransfer>
  <feDisplacementMap in="SourceGraphic" in2="map" scale="34" xChannelSelector="R" yChannelSelector="G" result="scatter"/>
  <!-- real frost = a tight core + a wide halo: blend two blur radii -->
  <feGaussianBlur in="scatter" stdDeviation="3" result="tight"/>
  <feGaussianBlur in="scatter" stdDeviation="13" result="wide"/>
  <feComposite in="tight" in2="wide" operator="arithmetic" k1="0" k2="0.6" k3="0.4" k4="0" result="blur"/>
  <!-- milky veil: lift blacks, slight desaturation -->
  <feComponentTransfer in="blur" result="lift">
    <feFuncR type="linear" slope="0.9" intercept="0.07"/><feFuncG type="linear" slope="0.9" intercept="0.07"/><feFuncB type="linear" slope="0.9" intercept="0.07"/>
  </feComponentTransfer>
  <feColorMatrix in="lift" type="saturate" values="0.82" result="veil"/>
  <!-- surface grain -->
  <feTurbulence type="fractalNoise" baseFrequency="1.35" numOctaves="1" seed="31" result="g"/>
  <feColorMatrix in="g" type="matrix" values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0.55 0 0 0 -0.2" result="grain"/>
  <feComposite in="grain" in2="veil" operator="over"/>
</filter>''',
    map_chain=f'''<feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="2" seed="9" result="n"/>
  <feColorMatrix in="n" type="matrix" values="{IDENT}" result="m0"/>
  <feComponentTransfer in="m0"><feFuncR type="linear" slope="2.4" intercept="-0.7"/><feFuncG type="linear" slope="2.4" intercept="-0.7"/></feComponentTransfer>''',
    params="scatter scale 34 px · noise 0.65 · blur σ 3 (60%) + σ 13 (40%) · veil +0.07 / sat 0.82 · grain 1.35")


def build():
    jobs, maps_jobs = [], []
    pattern = test_pattern_group()
    # reference
    ref_svg = os.path.join(OUT, "00_test_pattern_reference.svg")
    open(ref_svg, "w").write(svg_wrap(pattern))
    jobs.append((ref_svg, os.path.join(OUT, "00_test_pattern_reference.png")))
    for key, f in F.items():
        svg = svg_wrap(f'<g filter="url(#{f["id"]})">\n{pattern}\n</g>', defs=f["body"])
        sp = os.path.join(OUT, f"{key}.svg")
        open(sp, "w").write(svg)
        jobs.append((sp, os.path.join(OUT, f"{key}.png")))
        # displacement map export
        mf = f'<filter id="m" {REGION}>{f["map_chain"]}</filter>'
        msp = os.path.join(MAPS, f"{key}_map.svg")
        open(msp, "w").write(svg_wrap('<rect width="1080" height="1920" filter="url(#m)"/>', defs=mf))
        maps_jobs.append((msp, os.path.join(MAPS, f"{key}_map.png")))
    # library of bare filters (no artwork) for drop-in use
    lib = "\n".join(f"<!-- {k}: {f['title']} | {f['params']} -->\n{f['body']}" for k, f in F.items())
    open(os.path.join(OUT, "glass_filters_library.svg"), "w").write(
        '<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute">\n<defs>\n' + lib + "\n</defs>\n</svg>\n")
    render_many(jobs)
    render_many(maps_jobs)
    return list(F.keys())


def side_by_side():
    ref = Image.open(os.path.join(OUT, "00_test_pattern_reference.png")).convert("RGB")
    for key in F:
        img = Image.open(os.path.join(OUT, f"{key}.png")).convert("RGB")
        s = 0.5
        a = ref.resize((int(W * s), int(H * s)), Image.LANCZOS)
        b = img.resize((int(W * s), int(H * s)), Image.LANCZOS)
        sheet = Image.new("RGB", (a.width * 2 + 30, a.height), (24, 24, 26))
        sheet.paste(a, (0, 0)); sheet.paste(b, (a.width + 30, 0))
        sheet.save(os.path.join(OUT, f"{key}_before_after.png"))


def measure():
    """Quantify distortion so 'tested' means something."""
    ref = np.asarray(Image.open(os.path.join(OUT, "00_test_pattern_reference.png")).convert("RGB")).astype(float)
    res = {}
    def gray(a): return a.mean(axis=2)
    def lapvar(a):
        g = gray(a)
        lap = g[1:-1, 1:-1] * 4 - g[:-2, 1:-1] - g[2:, 1:-1] - g[1:-1, :-2] - g[1:-1, 2:]
        return float(lap.var())
    # reference peak positions of the 90-px vertical grid lines on two clean rows
    def peaks(row, xs, half=50):
        out = []
        for x in xs:
            seg = row[max(0, x - half): x + half + 1]
            out.append(max(0, x - half) + int(np.argmax(seg)))
        return np.array(out)
    xs = [x for x in range(90, 1080, 90) if not (360 <= x <= 720)]
    for key in F:
        img = np.asarray(Image.open(os.path.join(OUT, f"{key}.png")).convert("RGB")).astype(float)
        mae = float(np.abs(img - ref).mean())
        shifts = []
        for y in (250, 1500):
            r0 = gray(ref)[y]; r1 = gray(img)[y]
            p0 = peaks(r0, xs, 6)  # exact line centres in reference
            p1 = peaks(r1, xs, 50)
            shifts += list(np.abs(p1 - p0))
        res[key] = dict(mean_abs_diff_0_255=round(mae, 2),
                        grid_line_shift_px_mean=round(float(np.mean(shifts)), 1),
                        grid_line_shift_px_max=int(np.max(shifts)),
                        sharpness_ratio=round(lapvar(img) / lapvar(ref), 3),
                        alpha_note="opaque test pattern")
    return res


if __name__ == "__main__":
    build()
    side_by_side()
    m = measure()
    json.dump(m, open(os.path.join(ROOT, "tests", "filter_measurements.json"), "w"), indent=2)
    for k, v in m.items():
        print(k, v)
