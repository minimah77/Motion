"""Physically-based caustic overlays (white light, straight alpha PNG).

Method: a uniform grid of 'photons' is shot through a refracting height field H(x,y).
Each photon is deflected by k * grad(H) and splatted (bilinear) where it lands.
Where rays converge -> bright fold lines / cusps (real caustic structure).
Where they diverge -> darkness (transparent). Energy is conserved.
"""
import os, sys, time
import numpy as np
from scipy.ndimage import gaussian_filter, rotate
from PIL import Image
from common import ROOT

W, H = 1080, 1920
PAD = 280
Hp, Wp = H + 2 * PAD, W + 2 * PAD
OUT = os.path.join(ROOT, "caustics")


# ------------------------------------------------------------ height fields
def smooth_noise(seed, sigma, shape=(Hp, Wp)):
    r = np.random.default_rng(seed)
    n = gaussian_filter(r.standard_normal(shape).astype(np.float32), sigma, mode="wrap")
    return n / n.std()


def directional_noise(seed, sy, sx, angle):
    """Anisotropic noise stretched along a direction (flowing light)."""
    big = (int(Hp * 1.5), int(Wp * 1.5))
    r = np.random.default_rng(seed)
    n = gaussian_filter(r.standard_normal(big).astype(np.float32), (sy, sx), mode="wrap")
    n = rotate(n, angle, reshape=False, order=1, mode="wrap")
    y0, x0 = (big[0] - Hp) // 2, (big[1] - Wp) // 2
    n = n[y0:y0 + Hp, x0:x0 + Wp]
    return n / n.std()


def ripple_field(seed, lam, n_plane=7, n_point=14):
    r = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:Hp, 0:Wp].astype(np.float32)
    f = np.zeros((Hp, Wp), np.float32)
    for _ in range(n_plane):
        th = r.uniform(0, 2 * np.pi); l = lam * r.uniform(0.8, 1.7); ph = r.uniform(0, 2 * np.pi)
        f += r.uniform(0.5, 1.0) * np.cos(2 * np.pi / l * (xx * np.cos(th) + yy * np.sin(th)) + ph)
    for _ in range(n_point):
        cx, cy = r.uniform(-100, Wp + 100), r.uniform(-100, Hp + 100)
        l = lam * r.uniform(0.8, 1.5); ph = r.uniform(0, 2 * np.pi)
        d = np.hypot(xx - cx, yy - cy)
        f += r.uniform(0.7, 1.4) * np.cos(2 * np.pi / l * d + ph) / np.sqrt(1 + d / (6 * l))
    return f / f.std()


# ------------------------------------------------------------ photon splat
def shoot(field, focus, ss=3, disp=(1.0,), block=90):
    """Return list of intensity maps (one per dispersion factor), normalised to mean 1."""
    gy, gx = np.gradient(field.astype(np.float32))
    gyy = np.gradient(gy, axis=0); gxx = np.gradient(gx, axis=1)
    k0 = focus / np.std(gxx + gyy)
    outs = [np.zeros(Hp * Wp, np.float64) for _ in disp]
    xs = (np.arange(Wp * ss) + 0.5) / ss - 0.5
    x0 = np.clip(np.floor(xs).astype(int), 0, Wp - 1); x1 = np.minimum(x0 + 1, Wp - 1); fx = (xs - x0)[None, :].astype(np.float32)
    wph = 1.0 / (ss * ss)
    for r0 in range(0, Hp, block):
        r1 = min(Hp, r0 + block)
        ys = r0 + (np.arange((r1 - r0) * ss) + 0.5) / ss - 0.5
        ys = np.clip(ys, 0, Hp - 1)
        y0 = np.floor(ys).astype(int); y1 = np.minimum(y0 + 1, Hp - 1); fy = (ys - y0)[:, None].astype(np.float32)

        def samp(G):
            rows = G[y0] * (1 - fy) + G[y1] * fy
            return rows[:, x0] * (1 - fx) + rows[:, x1] * fx
        sgx, sgy = samp(gx), samp(gy)
        ysrc = (ys)[:, None].astype(np.float32); xsrc = xs[None, :].astype(np.float32)
        for oi, dfac in enumerate(disp):
            k = k0 * dfac
            px = xsrc + k * sgx; py = ysrc + k * sgy
            ix = np.floor(px).astype(np.int32); iy = np.floor(py).astype(np.int32)
            fxx = px - ix; fyy = py - iy
            ok = (ix >= 0) & (ix < Wp - 1) & (iy >= 0) & (iy < Hp - 1)
            ixo, iyo, fxo, fyo = ix[ok], iy[ok], fxx[ok], fyy[ok]
            base = iyo * Wp + ixo
            for off, w in ((0, (1 - fxo) * (1 - fyo)), (1, fxo * (1 - fyo)), (Wp, (1 - fxo) * fyo), (Wp + 1, fxo * fyo)):
                outs[oi] += np.bincount(base + off, weights=w * wph, minlength=Hp * Wp)
    res = []
    for o in outs:
        a = o.reshape(Hp, Wp)[PAD:PAD + H, PAD:PAD + W].astype(np.float32)
        res.append(a / a.mean())
    return res


def tone(I, post=0.7, lo=0.3, hi_pct=99.7, gamma=1.2, gain=1.0):
    if post > 0:
        I = gaussian_filter(I, post)
    hi = np.percentile(I, hi_pct)
    a = np.clip((I - lo) / (hi - lo), 0, 1) ** gamma
    return np.clip(a * gain, 0, 1)


def save_white(a, name):
    rgba = np.empty((H, W, 4), np.uint8)
    rgba[..., :3] = 255          # white light everywhere (no dark halo when resampled)
    rgba[..., 3] = np.round(a * 255).astype(np.uint8)
    Image.fromarray(rgba, "RGBA").save(os.path.join(OUT, name + ".png"), optimize=True)


def save_color(ac, name, strength=0.8):
    """ac: list of 3 per-channel alphas. Straight-alpha RGBA with restrained spectral edges."""
    A = np.maximum.reduce(ac)
    safe = np.where(A > 1e-4, A, 1.0)
    rgba = np.empty((H, W, 4), np.uint8)
    for i in range(3):
        frac = np.where(A > 1e-4, ac[i] / safe, 1.0)
        rgba[..., i] = np.round(255 * (1 - strength * (1 - frac))).astype(np.uint8)
    rgba[..., 3] = np.round(A * 255).astype(np.uint8)
    Image.fromarray(rgba, "RGBA").save(os.path.join(OUT, name + ".png"), optimize=True)


def stats(a):
    return dict(alpha_min=float(a.min()), alpha_max=float(a.max()), pct_fully_transparent=round(float((a < 1/255).mean() * 100), 1),
                pct_opaque_gt_50=round(float((a > .5).mean() * 100), 1))


RECIPES = {}


def recipe(fn):
    RECIPES[fn.__name__] = fn
    return fn


@recipe
def c01_underwater_network():
    f = smooth_noise(11, 34) + 0.45 * smooth_noise(12, 72) + 0.12 * smooth_noise(13, 14)
    (I,) = shoot(f, focus=1.55, ss=3)
    a = tone(I, post=0.8, lo=0.42, hi_pct=99.6, gamma=1.15)
    save_white(a, "01_underwater_network"); return stats(a)


@recipe
def c02_sharp_ripples():
    f = ripple_field(21, lam=46, n_plane=2, n_point=26)
    (I,) = shoot(f, focus=0.85, ss=4)
    a = tone(I, post=0.6, lo=0.7, hi_pct=99.5, gamma=0.9)
    save_white(a, "02_sharp_ripples"); return stats(a)


@recipe
def c03_soft_flow():
    f = directional_noise(31, 52, 210, 36) + 0.5 * directional_noise(32, 26, 100, 36)
    (I,) = shoot(f, focus=1.1, ss=3)
    a = tone(I, post=5.0, lo=0.25, hi_pct=99.5, gamma=0.95)
    save_white(a, "03_soft_flow"); return stats(a)


@recipe
def c04_glass_fold_edges():
    f = smooth_noise(41, 170) + 0.3 * smooth_noise(42, 80)
    (I,) = shoot(f, focus=1.7, ss=6)
    a = tone(I, post=1.2, lo=0.4, hi_pct=99.3, gamma=1.1)
    save_white(a, "04_glass_fold_edges"); return stats(a)


@recipe
def c05_rainbow_refraction():
    f = smooth_noise(51, 52) + 0.4 * smooth_noise(52, 110) + 0.1 * smooth_noise(53, 20)
    Ir, Ig, Ib = shoot(f, focus=1.4, ss=3, disp=(0.93, 1.0, 1.07))
    mx = np.percentile(gaussian_filter(Ig, .8), 99.6)
    ac = [np.clip((gaussian_filter(I, 0.8) - 0.4) / (mx - 0.4), 0, 1) ** 1.2 for I in (Ir, Ig, Ib)]
    save_color(ac, "05_rainbow_refraction", strength=0.85)
    return stats(np.maximum.reduce(ac))


if __name__ == "__main__":
    import json
    names = sys.argv[1:] or list(RECIPES)
    for n in names:
        t = time.time()
        s = RECIPES[n]()
        print(n, f"{time.time()-t:.0f}s", s, flush=True)
