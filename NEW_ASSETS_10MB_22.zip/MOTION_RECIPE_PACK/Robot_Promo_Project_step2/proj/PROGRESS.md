# Progress log (Robot Promo, episode 1)
- Step 1 DONE: environment check.
- Step 2 DONE: project folder built (deck.html, render.py, fonts/, robot/, frames/). Smoke test: frame 45 renders, no console errors, ready=true after ~3 s.
  - deck.html = the FIRST paste (half-spaces written as \u200c escapes, so they survive copy/paste). The second paste lost them: do not use it.
  - render.py changed from the recipe: viewport 1080x1920, and it AWAITS renderFrame (the engine's renderFrame is async because it decodes robot images).
  - robot/<pose>/NNN.webp = robot_lib frames renamed (only the 7 poses the engine uses). Shadows not used.
- Step 3 NEXT: contact sheets (1 frame per scene + 5 across each transition). Show user before full render.
## Known issues seen on smoke frame (not fixed yet, fix in step 3)
- Scene 1 headline wraps to 2 lines at 168 px and the 2nd line touches the plan card; underline only under the first accent word.
- Pill text "قسمت ۱ · ایده": check the middle dot and digit order at zoom.
- Bubble tail is partly covered by the robot; check at full speed.
## Sound plan (user's newer rules, replaces START_HERE section 8): original synthesis only, sfx_original/ kit, cue sheet BEFORE mixing, peaks about -6 dB, no sfx/ or sound_references/ audio, deliver MP4 with and without sound.
