import sys, os, base64, time
from playwright.sync_api import sync_playwright
# usage: render.py outdir fps start end      (or)  render.py outdir fps 12,34,56   (comma list of frame numbers)
out, fps = sys.argv[1], int(sys.argv[2])
if ',' in sys.argv[3] or len(sys.argv) < 5:
    frames = [int(x) for x in sys.argv[3].split(',')]
else:
    frames = list(range(int(sys.argv[3]), int(sys.argv[4])))
a = frames[0]
os.makedirs(out, exist_ok=True)
url = "file://" + os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "deck.html"))
with sync_playwright() as p:
    br = p.chromium.launch(args=["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist", "--allow-file-access-from-files"])
    pg = br.new_page(viewport={"width": 1080, "height": 1920})
    pg.on("console", lambda m: print("console:", m.text) if m.type == "error" else None)
    pg.on("pageerror", lambda e: print("pageerror:", e))
    pg.goto(url); pg.wait_for_function("window.ready===true", timeout=60000)
    t0 = time.time()
    for f in frames:
        d = pg.evaluate("async (a)=>{await renderFrame(a[0],a[1]);return document.getElementById('gl').toDataURL('image/jpeg',0.95)}", [f, fps])
        open(os.path.join(out, f"f{f:05d}.jpg"), "wb").write(base64.b64decode(d.split(",")[1]))
        if (f - a) % 20 == 0: print(f, round(time.time() - t0, 1), flush=True)
    print("total", pg.evaluate("window.TOTAL"))
    br.close()
