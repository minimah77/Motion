import sys,os,wave,csv,glob,subprocess,re
import numpy as np
root=sys.argv[1]; SR=48000
def read(p):
    with wave.open(p) as w:
        ch,sw,fr,n=w.getnchannels(),w.getsampwidth(),w.getframerate(),w.getnframes(); raw=w.readframes(n)
    b=np.frombuffer(raw,np.uint8).reshape(-1,3)
    v=(b[:,0].astype(np.int32)|(b[:,1].astype(np.int32)<<8)|(b[:,2].astype(np.int32)<<16))
    v=np.where(v>=1<<23,v-(1<<24),v)/8388608.0
    return v.reshape(-1,ch),ch,sw,fr
STEREO={'transitions','ambience'}
rows=[];fails=[]
for p in sorted(glob.glob(root+'/*/*.wav')):
    cat=p.split('/')[-2]; name=os.path.basename(p)
    x,ch,sw,fr=read(p); m=x.mean(1)
    f=[]
    if fr!=SR: f.append(f"rate {fr}")
    if sw!=3: f.append(f"bytes/sample {sw}")
    if (cat in STEREO)!=(ch==2): f.append(f"channels {ch}")
    pk=20*np.log10(np.max(np.abs(x))+1e-12)
    if abs(pk+3)>0.06: f.append(f"peak {pk:.2f}")
    clips=int((np.abs(x)>=0.99999).sum())
    if clips: f.append(f"clipped {clips}")
    if not np.isfinite(x).all(): f.append("NaN")
    dc=float(abs(m.mean()))
    if dc>0.002: f.append(f"DC {dc:.4f}")
    rms=20*np.log10(np.sqrt((m**2).mean())+1e-12)
    if rms<-55: f.append(f"nearly silent rms {rms:.1f}")
    loop='room_tone' in name
    e0=float(np.abs(x[0]).max()); e1=float(np.abs(x[-1]).max())
    if not loop and (e0>0.002 or e1>0.002): f.append(f"edge click start {e0:.4f} end {e1:.4f}")
    if loop:
        seam=float(np.abs(x[-1]-x[0]).max()); typ=float(np.abs(np.diff(x,axis=0)).max())
        if seam>4*typ: f.append(f"loop seam jump {seam:.4f} vs typical step {typ:.4f}")
    # sub-60Hz energy (only for non-impact, non-ambience files)
    spec=np.abs(np.fft.rfft(m*np.hanning(len(m))))**2; fq=np.fft.rfftfreq(len(m),1/SR)
    low=float(spec[fq<50].sum()/(spec.sum()+1e-20)); cen=float((spec*fq).sum()/(spec.sum()+1e-20))
    if cat not in('impacts',) and 'zero_hit' not in name and 'room_tone' not in name and low>0.01: f.append(f"sub-50Hz energy {low*100:.1f}%")
    if ch==2 and cat=='transitions':
        cc=float(np.corrcoef(x[:,0],x[:,1])[0,1])
        if cc>0.98: f.append(f"channels nearly identical corr {cc:.3f}")
    # independent peak cross-check with ffmpeg
    r=subprocess.run(['ffmpeg','-hide_banner','-nostats','-i',p,'-af','volumedetect','-f','null','-'],capture_output=True,text=True).stderr
    mx=re.search(r'max_volume: (-?[\d.]+) dB',r); ffpk=float(mx.group(1)) if mx else None
    if ffpk is None or abs(ffpk-pk)>0.3: f.append(f"ffmpeg peak {ffpk} vs mine {pk:.2f}")
    rows.append((cat,name,ch,len(x)/SR,pk,ffpk,rms,cen,"OK" if not f else "; ".join(f)))
    if f: fails.append((cat+'/'+name,f))
print(f"{len(rows)} files checked; {len(fails)} with flags")
for n,f in fails: print("FLAG",n,f)
print("\nshortest/longest:",min(r[3] for r in rows),max(r[3] for r in rows))
print("peak range dBFS:",round(min(r[4] for r in rows),2),round(max(r[4] for r in rows),2))
with open(root+'/_measurements.csv','w',newline='') as fo:
    w=csv.writer(fo); w.writerow(['category','file','channels','length_s','peak_dBFS','ffmpeg_peak_dBFS','rms_dBFS','spectral_centroid_Hz','check'])
    for r in rows: w.writerow([r[0],r[1],r[2],round(r[3],3),round(r[4],2),r[5],round(r[6],1),round(r[7]),r[8]])
