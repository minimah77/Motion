#!/usr/bin/env python3
"""Original synthesized SFX kit (Essential). numpy + scipy only. No samples, no recordings.
Output: WAV 48 kHz 24-bit, mono for UI, stereo for whooshes/risers/ambience.
Rules from 03_SFX_ZIP_SPEC.md: 5-20 ms fades, peaks -3 dBFS, high-pass 60 Hz except impacts.
"""
import os, sys, wave, zlib, csv
import numpy as np
import scipy.signal as sg

SR = 48000
OUT = sys.argv[1] if len(sys.argv) > 1 else "SFX_PACK"

def T(d): return np.arange(int(round(d * SR))) / SR
def RG(name, v): return np.random.default_rng(zlib.crc32(name.encode()) + 7919 * v)

def _sos(kind, f, order=2):
    return sg.butter(order, f, btype=kind, fs=SR, output="sos")
def lp(x, f, order=2): return sg.sosfilt(_sos("low", f, order), x, axis=0)
def hp(x, f, order=2): return sg.sosfilt(_sos("high", f, order), x, axis=0)
def bp(x, lo, hi, order=2): return sg.sosfilt(_sos("band", [lo, hi], order), x, axis=0)

def sweep_filter(x, f0, f1, width=0.5, block=256, exp=True):
    """band-pass whose centre moves f0->f1 across the signal (block-wise, state carried)."""
    n = len(x); y = np.zeros(n); zi = np.zeros((2, 2))
    nb = (n + block - 1) // block
    for i in range(nb):
        a = i / max(nb - 1, 1)
        fc = f0 * (f1 / f0) ** a if exp else f0 + (f1 - f0) * a
        lo = max(fc / (1 + width), 20); hi = min(fc * (1 + width), SR / 2 - 100)
        sos = sg.butter(2, [lo, hi], btype="band", fs=SR, output="sos")
        seg, zi = sg.sosfilt(sos, x[i * block:(i + 1) * block], zi=zi)
        y[i * block:(i + 1) * block] = seg
    return y

def sweep_sine(f0, f1, d, exp=True, curve=1.0):
    tt = T(d); a = (tt / d) ** curve
    f = f0 * (f1 / f0) ** a if exp else f0 + (f1 - f0) * a
    return np.sin(2 * np.pi * np.cumsum(f) / SR)

def tone(f, d, tau, harm=((1, 1.0),), atk=0.002):
    tt = T(d)
    y = sum(a * np.sin(2 * np.pi * f * h * tt) for h, a in harm)
    return y * (1 - np.exp(-tt / atk)) * np.exp(-tt / tau)

def nburst(rg, d, tau, lo, hi, atk=0.0005):
    n = rg.standard_normal(int(d * SR)); n = bp(n, lo, hi); tt = T(d)
    return n * (1 - np.exp(-tt / atk)) * np.exp(-tt / tau)

def bell_env(d, peak=0.5, p=2.0):
    a = np.linspace(0, 1, int(d * SR))
    e = np.where(a < peak, (a / peak) ** p, ((1 - a) / (1 - peak)) ** p)
    return e

def place(cv, x, at):
    i = int(at * SR)
    if x.ndim == 1 and cv.ndim == 2: x = np.stack([x, x], 1)
    n = min(len(x), len(cv) - i)
    if n > 0: cv[i:i + n] += x[:n]
    return cv

def padd(*xs):
    n = max(len(x) for x in xs); o = np.zeros(n)
    for x in xs: o[:len(x)] += x
    return o

def canvas(d, ch=1): return np.zeros(int(d * SR)) if ch == 1 else np.zeros((int(d * SR), 2))

def stereo_noise(rg, d, f0, f1, width, env, pan0=-0.6, pan1=0.6):
    """two decorrelated swept-noise channels + pan movement."""
    n = int(d * SR); ch = []
    for _ in range(2):
        z = rg.standard_normal(n); ch.append(sweep_filter(z, f0, f1, width))
    a = np.linspace(0, 1, n); pan = pan0 + (pan1 - pan0) * a
    gl = np.sqrt(0.5 * (1 - pan)); gr = np.sqrt(0.5 * (1 + pan))
    return np.stack([ch[0] * env * (0.4 + gl), ch[1] * env * (0.4 + gr)], 1)

def fin(x, hp_hz=60, fi=0.005, fo=0.015, peak_db=-3.0):
    x = np.asarray(x, float)
    if hp_hz: x = hp(x, hp_hz, 2)
    n = len(x); nfi, nfo = int(fi * SR), int(fo * SR)
    w = np.ones(n)
    w[:nfi] = 0.5 - 0.5 * np.cos(np.pi * np.arange(nfi) / nfi)
    w[n - nfo:] = 0.5 + 0.5 * np.cos(np.pi * np.arange(nfo) / nfo)
    x = x * (w[:, None] if x.ndim == 2 else w)
    pk = np.max(np.abs(x)); x = x / pk * 10 ** (peak_db / 20)
    return x

def write_wav(path, x):
    x = np.clip(x, -1, 1)
    if x.ndim == 1: x = x[:, None]
    ints = np.ascontiguousarray(np.round(x * 8388607).astype("<i4"))
    b = ints.view(np.uint8).reshape(-1, 4)[:, :3].tobytes()
    with wave.open(path, "wb") as w:
        w.setnchannels(x.shape[1]); w.setsampwidth(3); w.setframerate(SR); w.writeframes(b)

# ------------------------------------------------------------------ sounds
S = {}   # (category, name) -> dict(fn, variants, stereo, nohp, tags, best_for)
def reg(cat, name, variants=1, stereo=False, nohp=False, tags="", best="", fo=0.015):
    def deco(fn):
        S[(cat, name)] = dict(fn=fn, variants=variants, stereo=stereo, nohp=nohp, tags=tags, best=best, fo=fo)
        return fn
    return deco

# ---- transitions (stereo)
@reg("transitions", "whoosh_soft", 3, True, tags="soft air light", best="blur-through")
def _(v, rg):
    d = 0.7 + 0.05 * v; env = bell_env(d, 0.45, 1.8)
    return stereo_noise(rg, d, 350 + 40 * v, 2400 - 150 * v, 0.9, env, -0.5, 0.5) * 0.9

@reg("transitions", "whoosh_fast", 2, True, tags="fast sharp pan", best="whip pan")
def _(v, rg):
    d = 0.42; env = bell_env(d, 0.4, 1.5)
    return stereo_noise(rg, d, 700, 5500, 0.8, env, -0.9, 0.9)

@reg("transitions", "whoosh_air", 1, True, tags="breath airy", best="soft scene change")
def _(v, rg):
    d = 0.95; env = bell_env(d, 0.5, 2.2)
    s = stereo_noise(rg, d, 1800, 7000, 1.2, env, -0.3, 0.3)
    return hp(s, 1200)

@reg("transitions", "whoosh_up", 1, True, tags="rising", best="move up, reveal")
def _(v, rg):
    d = 0.6; env = bell_env(d, 0.7, 1.6)
    return stereo_noise(rg, d, 300, 4200, 0.8, env, 0, 0)

@reg("transitions", "whoosh_down", 1, True, tags="falling", best="move down, exit")
def _(v, rg):
    d = 0.6; env = bell_env(d, 0.3, 1.6)
    return stereo_noise(rg, d, 4200, 300, 0.8, env, 0, 0)

@reg("transitions", "swipe_glass", 1, True, tags="glassy short swipe", best="card swipe")
def _(v, rg):
    d = 0.28; env = bell_env(d, 0.35, 1.4)
    s = stereo_noise(rg, d, 2500, 8000, 0.7, env, -0.4, 0.4)
    gl = sweep_sine(2200, 5200, d) * env * 0.12
    return s + np.stack([gl, gl], 1)

@reg("transitions", "zoom_through", 1, True, tags="zoom tunnel impact", best="zoom-through")
def _(v, rg):
    d = 1.0; env = bell_env(d, 0.78, 2.0)
    s = stereo_noise(rg, d, 250, 6500, 0.9, env, 0, 0)
    sub = sweep_sine(60, 140, d, curve=2.0) * env * 0.5
    return s + np.stack([sub, sub], 1)

@reg("transitions", "push_in", 1, True, tags="soft swell low", best="slow push-in")
def _(v, rg):
    d = 0.9; env = bell_env(d, 0.6, 2.0)
    s = stereo_noise(rg, d, 150, 900, 0.9, env, 0, 0)
    return lp(s, 1400)

@reg("transitions", "riser_short", 1, True, tags="riser tension", best="hook lead-in", fo=0.02)
def _(v, rg):
    d = 1.6; tt = T(d); env = (tt / d) ** 2.2
    s = stereo_noise(rg, d, 300, 7000, 0.9, np.ones(len(tt)), 0, 0) * env[:, None]
    sw = sweep_sine(200, 1600, d, curve=1.5) * env * 0.25
    return s + np.stack([sw, sw], 1)

@reg("transitions", "downlifter", 1, True, tags="falling release", best="after a hit")
def _(v, rg):
    d = 1.2; tt = T(d); env = np.exp(-tt / 0.45)
    s = stereo_noise(rg, d, 5000, 250, 0.9, np.ones(len(tt)), 0, 0) * env[:, None]
    sw = sweep_sine(1200, 140, d) * env * 0.25
    return s + np.stack([sw, sw], 1)

# ---- ui (mono)
@reg("ui", "click_soft", 3, tags="cursor tap soft", best="cursor click")
def _(v, rg):
    tt = T(0.12)
    a = nburst(rg, 0.12, 0.004, 1800, 6000) * 0.8
    b = tone(1500 + 120 * v, 0.12, 0.012) * 0.5
    return a + b

@reg("ui", "click_tight", 1, tags="cursor tap tight", best="button press")
def _(v, rg):
    return nburst(rg, 0.08, 0.0025, 2500, 9000) * 0.9 + tone(2400, 0.08, 0.006) * 0.4

@reg("ui", "tap_glass", 1, tags="glass tap", best="touch")
def _(v, rg):
    h = ((1, 1.0), (2.76, 0.5), (5.4, 0.25))
    return padd(tone(1900, 0.22, 0.045, h) * 0.7, nburst(rg, 0.03, 0.002, 3000, 9000) * 0.3)

@reg("ui", "tick", 2, tags="tick tiny", best="CTA tick, counter")
def _(v, rg):
    return tone(3800 + 300 * v, 0.06, 0.005) * 0.7 + nburst(rg, 0.06, 0.0015, 3000, 10000) * 0.5

@reg("ui", "toggle_on", 1, tags="toggle on rising", best="switch on")
def _(v, rg):
    c = canvas(0.2); place(c, tone(1400, 0.1, 0.01), 0.0); place(c, tone(2100, 0.1, 0.012), 0.06); return c

@reg("ui", "toggle_off", 1, tags="toggle off falling", best="switch off")
def _(v, rg):
    c = canvas(0.2); place(c, tone(2100, 0.1, 0.01), 0.0); place(c, tone(1300, 0.1, 0.012), 0.06); return c

def _pop(f0, f1, d, tau, rg, extra=0.0):
    tt = T(d); y = sweep_sine(f0, f1, d, curve=0.35) * np.exp(-tt / tau)
    return y + extra * nburst(rg, d, 0.004, 1500, 5000)

@reg("ui", "pop_small", 1, tags="pop tiny", best="small element in")
def _(v, rg): return _pop(520, 980, 0.12, 0.028, rg, 0.15)

@reg("ui", "pop_pill", 2, tags="pop pill spring", best="card/pill spring in")
def _(v, rg): return _pop(380 + 40 * v, 860 + 60 * v, 0.16, 0.04, rg, 0.2)

@reg("ui", "pop_bubble", 1, tags="pop bubble", best="CTA badge")
def _(v, rg): return _pop(300, 1250, 0.2, 0.05, rg, 0.1)

@reg("ui", "type_key_soft", 2, tags="key soft", best="typing per key")
def _(v, rg):
    return nburst(rg, 0.07, 0.004, 900, 4500) * 0.8 + tone(700 + 150 * v, 0.07, 0.01) * 0.4

@reg("ui", "type_burst", 1, tags="typing burst 0.5s", best="search bar typing")
def _(v, rg):
    c = canvas(0.55); t0 = 0.0
    for i in range(7):
        k = nburst(rg, 0.07, 0.004, 900, 4500) * 0.8 + tone(650 + rg.uniform(0, 300), 0.07, 0.01) * 0.4
        place(c, k * rg.uniform(0.7, 1.0), t0); t0 += rg.uniform(0.045, 0.085)
    return c

@reg("ui", "backspace", 1, tags="delete key", best="erase text")
def _(v, rg):
    return nburst(rg, 0.09, 0.006, 500, 3000) * 0.8 + tone(420, 0.09, 0.015) * 0.5

@reg("ui", "message_send", 1, tags="send up whoosh pop", best="outgoing chat")
def _(v, rg):
    c = canvas(0.35)
    sw = sweep_sine(500, 1500, 0.18, curve=0.8) * bell_env(0.18, 0.7, 1.2) * 0.35
    place(c, sw, 0.0); place(c, _pop(700, 1250, 0.14, 0.03, rg), 0.12); return c

@reg("ui", "message_receive", 1, tags="receive two notes", best="incoming chat")
def _(v, rg):
    c = canvas(0.5); h = ((1, 1), (2, 0.25))
    place(c, tone(988, 0.25, 0.07, h), 0.0); place(c, tone(740, 0.3, 0.09, h), 0.1); return c

@reg("ui", "typing_dots", 1, tags="three dots", best="typing indicator")
def _(v, rg):
    c = canvas(0.55)
    for i in range(3): place(c, _pop(450 + 90 * i, 800 + 120 * i, 0.1, 0.022, rg), 0.02 + 0.15 * i)
    return c

@reg("ui", "notification_soft", 1, tags="notification bell", best="notification slides in")
def _(v, rg):
    c = canvas(0.9); h = ((1, 1), (2.01, 0.3), (3.02, 0.12))
    place(c, tone(1175, 0.8, 0.18, h), 0.0); place(c, tone(1760, 0.7, 0.16, h), 0.11); return c

@reg("ui", "drop_settle", 1, tags="soft landing", best="card lands")
def _(v, rg):
    return padd(tone(150, 0.25, 0.05) * 0.8, nburst(rg, 0.12, 0.012, 200, 1200) * 0.5)

# ---- feedback
@reg("feedback", "success_check", 1, tags="success check", best="checkmark")
def _(v, rg):
    c = canvas(0.7); h = ((1, 1), (2, 0.3), (3, 0.1))
    place(c, tone(659, 0.35, 0.08, h), 0.0); place(c, tone(988, 0.5, 0.13, h), 0.09); return c

@reg("feedback", "success_chime", 1, tags="success arpeggio", best="finish, complete")
def _(v, rg):
    c = canvas(1.1); h = ((1, 1), (2, 0.25), (3, 0.08))
    for i, f in enumerate([523, 659, 784, 1047]): place(c, tone(f, 0.7, 0.16, h), 0.07 * i)
    return c

@reg("feedback", "coin", 1, tags="coin ding", best="number lands, money")
def _(v, rg):
    c = canvas(0.55); h = ((1, 1), (2, 0.35), (3, 0.2))
    place(c, tone(1976, 0.12, 0.03, h), 0.0); place(c, tone(2637, 0.45, 0.11, h), 0.07); return c

@reg("feedback", "complete_ding", 1, tags="ding", best="task done")
def _(v, rg): return tone(1568, 0.9, 0.2, ((1, 1), (2.76, 0.12), (4.1, 0.05)))

@reg("feedback", "error_soft", 1, tags="soft error", best="negative state")
def _(v, rg):
    c = canvas(0.4); h = ((1, 1), (2, 0.2))
    place(c, tone(330, 0.2, 0.06, h), 0.0); place(c, tone(247, 0.28, 0.09, h), 0.1); return c

# ---- impacts (no high-pass)
def _thump(f0, f1, d, tau, rg, noise=0.25):
    tt = T(d); y = sweep_sine(f0, f1, d, curve=0.25) * np.exp(-tt / tau)
    return y + noise * nburst(rg, d, tau * 0.35, 40, 600)

@reg("impacts", "hit_soft", 1, nohp=True, tags="soft hit", best="big number lands", fo=0.03)
def _(v, rg): return _thump(120, 48, 0.45, 0.1, rg)

@reg("impacts", "hit_sub_deep", 1, nohp=True, tags="sub deep", best="reveal punch", fo=0.04)
def _(v, rg): return _thump(70, 34, 1.1, 0.28, rg, 0.12)

@reg("impacts", "slam_text", 1, nohp=True, tags="slam", best="headline slam", fo=0.03)
def _(v, rg):
    c = canvas(0.4); place(c, _thump(150, 55, 0.4, 0.08, rg, 0.3), 0.0)
    return place(c, 0.5 * nburst(rg, 0.15, 0.03, 800, 6000), 0.0)

@reg("impacts", "stamp_logo", 1, nohp=True, tags="stamp", best="logo stamp", fo=0.03)
def _(v, rg):
    c = canvas(0.3); place(c, _thump(140, 60, 0.3, 0.06, rg, 0.3), 0.0)
    return place(c, 0.35 * nburst(rg, 0.04, 0.004, 1500, 7000), 0.0)

# ---- magic
def _sparkle_set(rg, d, n, f_lo, f_hi, up=True):
    c = canvas(d); h = ((1, 1), (2.7, 0.3))
    for i in range(n):
        a = i / max(n - 1, 1); a = a if up else 1 - a
        f = f_lo * (f_hi / f_lo) ** (a + rg.uniform(-0.06, 0.06))
        place(c, tone(float(f), 0.25, 0.035, h) * rg.uniform(0.5, 1.0), (i / n) * (d - 0.3) + rg.uniform(0, 0.02))
    return c

@reg("magic", "sparkle_up", 1, tags="sparkle rising", best="success sparkle")
def _(v, rg): return _sparkle_set(rg, 0.8, 14, 2200, 8500, True)

@reg("magic", "sparkle_down", 1, tags="sparkle falling", best="fade away")
def _(v, rg): return _sparkle_set(rg, 0.8, 14, 2200, 8500, False)

@reg("magic", "twinkle", 1, tags="twinkle", best="small highlight")
def _(v, rg): return _sparkle_set(rg, 0.45, 4, 3500, 7000, True)

@reg("magic", "shimmer", 1, tags="shimmer air", best="logo settle", fo=0.05)
def _(v, rg):
    d = 1.6; env = bell_env(d, 0.3, 1.4)
    n = hp(sweep_filter(rg.standard_normal(int(d * SR)), 5000, 9000, 0.6), 3500) * env * 0.5
    return n + _sparkle_set(rg, d, 10, 3000, 9000, True) * 0.7

@reg("magic", "glow_swell", 1, tags="pad swell", best="hook text glow", fo=0.06)
def _(v, rg):
    d = 1.3; tt = T(d); env = bell_env(d, 0.6, 1.8)
    y = sum(np.sin(2 * np.pi * f * tt + rg.uniform(0, 6)) * a
            for f, a in [(220, 1), (221.3, 0.8), (330, 0.6), (331.7, 0.5), (440, 0.4), (659, 0.2)])
    return lp(y, 2400) * env

# ---- text
@reg("text", "text_in_soft", 1, tags="text blur-in", best="hook text")
def _(v, rg):
    d = 0.4; env = bell_env(d, 0.55, 1.6)
    return sweep_filter(rg.standard_normal(int(d * SR)), 900, 2600, 0.8) * env * 0.8 + tone(520, d, 0.1) * 0.15

@reg("text", "text_in_pop", 1, tags="text pop", best="word pop-in")
def _(v, rg): return _pop(450, 900, 0.14, 0.03, rg, 0.2)

@reg("text", "word_swap", 1, tags="swap tick", best="word swap")
def _(v, rg):
    c = canvas(0.25); place(c, sweep_filter(rg.standard_normal(int(0.16 * SR)), 1200, 3500, 0.8) * bell_env(0.16, 0.4, 1.5), 0)
    place(c, tone(2600, 0.06, 0.006) * 0.7, 0.14); return c

@reg("text", "highlight_swipe", 1, tags="swipe highlighter", best="highlight on key word")
def _(v, rg):
    d = 0.28; return sweep_filter(rg.standard_normal(int(d * SR)), 1000, 5000, 0.7) * bell_env(d, 0.5, 1.3)

@reg("text", "underline_draw", 1, tags="draw line", best="underline draw")
def _(v, rg):
    d = 0.32; env = bell_env(d, 0.7, 1.2)
    return sweep_filter(rg.standard_normal(int(d * SR)), 1500, 6000, 0.6) * env * 0.8 + sweep_sine(900, 2400, d) * env * 0.12

@reg("text", "caption_tick", 1, tags="caption tick", best="caption word-by-word")
def _(v, rg): return tone(2200, 0.05, 0.005) * 0.6 + nburst(rg, 0.05, 0.002, 2000, 8000) * 0.3

@reg("text", "erase_swipe", 1, tags="erase swipe", best="erase text")
def _(v, rg):
    d = 0.3; return sweep_filter(rg.standard_normal(int(d * SR)), 4500, 900, 0.7) * bell_env(d, 0.35, 1.3)

# ---- camera foley
@reg("camera_foley", "shutter_click", 1, tags="shutter", best="camera beat")
def _(v, rg):
    c = canvas(0.2)
    place(c, nburst(rg, 0.05, 0.005, 1200, 7000) + tone(1100, 0.05, 0.008) * 0.5, 0.0)
    place(c, nburst(rg, 0.06, 0.006, 800, 6000) * 0.8 + tone(800, 0.06, 0.01) * 0.4, 0.06)
    return c

# ---- retro / digital
def _crush(x, bits, hold):
    q = 2 ** (bits - 1); x = np.round(x * q) / q
    return np.repeat(x[::hold], hold)[:len(x)]

@reg("retro_pixel", "glitch_short", 1, tags="glitch stutter", best="glitch cut")
def _(v, rg):
    c = canvas(0.35)
    for i in range(5):
        d = rg.uniform(0.02, 0.05); b = _crush(rg.uniform(-1, 1, int(d * SR)) * 0.8, 5, int(rg.integers(2, 9)))
        place(c, b * np.hanning(len(b)), i * 0.06 + rg.uniform(0, 0.015))
    return c

@reg("retro_pixel", "digital_dissolve", 1, tags="grain dissolve", best="pixel dissolve")
def _(v, rg):
    d = 0.9; c = canvas(d)
    for i in range(34):
        f = 5500 * (0.25 ** (i / 34)) * rg.uniform(0.8, 1.2)
        place(c, tone(float(f), 0.05, 0.01) * rg.uniform(0.4, 1.0), (i / 34) * (d - 0.1) + rg.uniform(0, 0.012))
    return c

# ---- countdown
for _n in range(10):
    def _mk(n):
        @reg("countdown", f"count_pop_{n:02d}", 1, tags=f"count pop pitched step {n}", best=f"countdown number {n}")
        def f(v, rg):
            sc = 2 ** ([0, 2, 4, 7, 9, 12, 14, 16, 19, 21][n] / 12)
            return _pop(420 * sc, 820 * sc, 0.15, 0.035, rg, 0.12)
        return f
    _mk(_n)

@reg("countdown", "zero_hit", 1, nohp=True, tags="zero hit bell", best="final zero", fo=0.05)
def _(v, rg):
    c = canvas(1.3); place(c, _thump(120, 45, 0.5, 0.12, rg), 0.0)
    place(c, tone(1047, 1.1, 0.3, ((1, 1), (2.76, 0.12), (4.1, 0.05))) * 0.35, 0.02); return c

@reg("countdown", "tick_clock", 1, tags="clock tick", best="timer")
def _(v, rg): return tone(1800, 0.09, 0.012) * 0.6 + nburst(rg, 0.09, 0.004, 1000, 6000) * 0.5

# ---- logo (impacts) layered
@reg("impacts", "logo_hit", 1, nohp=True, tags="logo settle hit", best="logo settles (after 0.3 s silence)", fo=0.06)
def _(v, rg):
    c = canvas(1.8)
    place(c, _thump(110, 46, 0.6, 0.14, rg), 0.0)
    d = 1.5; env = bell_env(d, 0.25, 1.4)
    sh = hp(sweep_filter(rg.standard_normal(int(d * SR)), 5000, 9000, 0.6), 3500) * env * 0.12
    place(c, sh, 0.05); place(c, tone(1319, 1.3, 0.35, ((1, 1), (2.76, 0.1))) * 0.18, 0.04)
    return c

# ---- ambience (loopable stereo)
@reg("ambience", "room_tone_soft", 1, True, tags="room tone loop", best="glue bed under scenes", fo=0.0)
def _(v, rg):
    d = 12.0; xfade = 1.0; n = int(d * SR); extra = int(xfade * SR)
    ch = []
    for _ in range(2):
        z = rg.standard_normal(n + extra); z = lp(z, 420, 2) + 0.4 * lp(z, 140, 2)
        ch.append(hp(z, 40, 2))
    y = np.stack(ch, 1)
    w = np.linspace(0, 1, extra)[:, None]
    loop = y[:n].copy(); loop[:extra] = y[:extra] * w + y[n:n + extra] * (1 - w)
    return loop

# ------------------------------------------------------------------ build
def build():
    os.makedirs(OUT, exist_ok=True); rows = []
    for (cat, name), s in sorted(S.items()):
        os.makedirs(os.path.join(OUT, cat), exist_ok=True)
        for v in range(s["variants"]):
            rg = RG(cat + name, v)
            x = s["fn"](v, rg)
            if s["stereo"] and x.ndim == 1: x = np.stack([x, x], 1)
            if not s["stereo"] and x.ndim == 2: x = x.mean(1)
            if name == "room_tone_soft":
                x = x / np.max(np.abs(x)) * 10 ** (-3 / 20)   # no fades, loops
            else:
                x = fin(x, None if s["nohp"] else 60, 0.005, s["fo"] if s["fo"] else 0.015)
            fn = name if name.startswith("count_pop_") else f"{name}_{v + 1:02d}"
            path = os.path.join(OUT, cat, fn + ".wav"); write_wav(path, x)
            rows.append([fn + ".wav", cat, round(len(x) / SR, 3), "", s["tags"], s["best"]])
    return rows

if __name__ == "__main__":
    rows = build()
    with open(os.path.join(OUT, "_cue_sheet_partial.csv"), "w", newline="") as f:
        csv.writer(f).writerows([["file", "category", "length_s", "loudness", "tags", "best_for"]] + rows)
    print(len(rows), "files written to", OUT)
