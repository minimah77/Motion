# SFX_PACK (Essential v1) - original synthesized sounds

Every sound is generated from math (sine/noise/filters) by `tools/make_sfx.py`. No samples, no recordings, nothing from any video. Free to use in any project.
Rebuild: `python3 tools/make_sfx.py SFX_PACK` then check: `python3 tools/check_sfx.py SFX_PACK`.

## Format (per 03_SFX_ZIP_SPEC.md)
WAV, 48 kHz, 24-bit. Mono: ui, feedback, impacts, magic, text, camera_foley, retro_pixel, countdown. Stereo: transitions, ambience.
5 ms fade in, 15 ms fade out (impacts 30-60 ms), every file peaks at -3.0 dBFS, 60 Hz high-pass on all except impacts/zero_hit/room tone. `room_tone_soft_01` is a 12 s seamless loop (no fades).

## Names
`<descriptor>_NN.wav` in category folders. Variants: whoosh_soft 01-03, whoosh_fast 01-02, click_soft 01-03, pop_pill 01-02, tick 01-02, type_key_soft 01-02. Countdown is `count_pop_00` ... `count_pop_09` (pitched steps up a pentatonic scale), plus `zero_hit_01`.
`_cue_sheet.csv` lists length, loudness (RMS dBFS, measured) and best use for every file. `_measurements.csv` has peak, RMS and brightness per file.

## Cue map (from spec, names as in this pack)
Hook text: text/text_in_soft_01 (-3 f) + magic/glow_swell_01 | Blur-through: transitions/whoosh_soft (-4 f) | Whip pan: whoosh_fast (-3 f) | Zoom-through: zoom_through_01 (-5 f) | Card/pill in: ui/pop_pill (0 f) | Click: ui/click_soft (exact frame) | Typing: ui/type_burst_01 | Chat: message_send / message_receive | Success: feedback/success_check + magic/sparkle_up | Big number: impacts/hit_soft + feedback/coin | Countdown: countdown/count_pop_NN | Glitch: retro_pixel/glitch_short | Logo: impacts/logo_hit after 0.3 s silence | CTA badge: ui/pop_bubble + ui/tick | Video hook: transitions/riser_short | Erase: text/erase_swipe or ui/backspace | Shutter: camera_foley/shutter_click

## Mix levels (put these on the timeline, not in the files)
UI clicks -20 to -16 dBFS, whooshes -18 to -12, impacts -10 to -6, room tone about -32.

## Honesty note
These files were checked with measurements only (format, peak, clipping, DC, edge clicks, loop seam, sub-bass, cross-check with ffmpeg). Nobody has listened to them yet. Listen and approve before using; tell the next Claude which ones to redo.

## Not in Essential v1 (expand later)
Folders from the full spec still empty: more variants, mech/glass keys, drawers/modals, level_up, boom_cinematic, 8-bit set, other ambiences, music stems.
