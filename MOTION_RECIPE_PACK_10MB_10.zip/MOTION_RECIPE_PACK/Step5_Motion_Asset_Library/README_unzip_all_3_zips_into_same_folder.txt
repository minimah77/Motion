Step 5C - Loading & Progress Animations
Unzip all 3 zips into the same folder (merge when asked). Result:

Step5_Motion_Asset_Library/
  05_Loaders_Progress/            colour versions (5 loaders: .webm .mov _still.png)
    Mono_White/                   white versions (for dark backgrounds)
    Mono_Black/                   black versions (for light backgrounds)
  00_Part_C_Previews_and_Manifest/  previews, contact sheets, manifests, QC reports (colour + mono)

Zip 1 of 3: previews/manifests/QC + colour (except 2 big MOVs) + Mono_Black
Zip 2 of 3: the 2 big colour MOVs (loader_orbiting_dot.mov, loader_percentage_count.mov)
Zip 3 of 3: Mono_White
