# STEP 5 (v4, complete) - SCENES, EMOJI, 3D OBJECTS, SHADOWS, PANELS + PROMPT PACK

Unzip into the same pack root as Steps 1 to 4 (so `assets/devices/device_specs.json` is found). Run the tools after that.

## WHAT IS IN HERE
| Path | What |
|---|---|
| assets/scenes/ | 60 code-built files: sky, clouds, hills, sunset, studio floors, paper, flat panels, contact shadows, plates.json |
| assets/scenes/plates.json | every plate with layer order, text color, UI safe zone, overlays that fit, overlays to avoid, archetype, motion |
| 08_CHATGPT_PROMPTS_STEP5_3D_AND_PHOTOREAL.md | ONE prompt pack, style lock first: 48 emoji, 24 + 6 objects, mascot (design + 12 poses), 8 photoreal green-screen devices |
| tools/build_plates.py | rebuilds every plate, and makes any flat color panel: `python3 tools/build_plates.py panel "#FF7A2E" brand_orange` |
| tools/make_device_from_photo.py | photoreal device PNG to hole, green, glare, preview and a device_specs.json entry |
| tools/ingest_cutouts.py | ChatGPT sheet or single image to clean transparent PNGs, named in order |
| assets/emoji, objects3d, characters, devices_photo/_raw | empty folders, the prompt pack tells you what goes in each |

Formats: `_169` = 1920x1080, `_916` = 1080x1920. Pick the suffix that matches the video. Never crop one into the other.
Opaque plates are JPG. Layers with transparency are WebP (alpha), which Remotion's Chromium renders natively.

## 1. SKY STACK (archetype C, bright product hero)
Layer order, back to front: `sky_blue` + `clouds_soft` + `hill_far` + `hill_near`.
Ready flattened versions: `sky_greenhill`, `sky_clouds`, `sky_clouds_dense`.
- Cloud layers are 2x the frame width (169: 3840x1080, 916: 2160x1920) and tile seamlessly. Loop: translateX 0 to minus one frame width over 30 to 60 s.
- Parallax: hill_far moves 0.5x, hill_near 1.5x of the camera push. Whole stack push-in 1.00 to 1.05.
- Keep the UI in the empty zone (see `ui_zone` in plates.json), for example a search bar at center, 60 percent of frame width.
- Text color #0F1B2D. Good overlays: godrays 30 to 50, sparkles on a reveal, flare_white 0.3 s, sweep_glass on cards. Avoid vignette_deep, fog, dust.

## 2. SUNSET STACK (warm finale, brand reveal)
`sky_sunset` + `clouds_sunset` + `hill_sunset`, flattened as `sky_sunset_hill`. Text #FFFFFF.
Overlays: flare_amber, leak_warm_1/2/3 on cuts, godrays 30, sparkles. Avoid leak_cool, flare_blue, beam_blue.

## 3. STUDIO FLOORS (product on a surface)
`studio_light` (cool white), `studio_warm` (cream), `studio_dark` (charcoal with a soft light pool).
- Floor line sits near 58 to 60 percent of the height, blended soft, no hard horizon.
- Object base at y = 0.80 (169) or 0.76 (916) of the frame.
- Shadow PNGs (black with alpha): `shadow_ellipse_wide` for laptop and monitor, `shadow_ellipse_phone` for phone and tablet, `shadow_ellipse_round` for 3D objects and mascot, `shadow_card_soft` for floating cards.
- Shadow opacity 35 to 45 percent on light plates, 55 to 65 on dark. Center the ellipse on the object base. When the object bobs up, shrink the shadow 8 percent and drop its opacity.
- Light plates: text #0E1330, glow #2F6BFF. Dark plate: text #F5F7FF, grain_medium 6 to 8 percent, bokeh_cool or dust allowed.

## 4. PAPER (archetypes D, I, K, Persian typographic films)
`paper_cream` (#F4F2EC base), `paper_white`, plus 1024 px seamless tiles `paper_cream_tile_1024`, `paper_white_tile_1024`, `paper_kraft_tile_1024`.
Text #111111, accents #FF3B30 and #2F6BFF. Use grain_coarse 4 to 6 percent. No flares, beams, bokeh or fog on paper. Move the content, not the paper.

## 5. FLAT PANELS (archetype G, app promo)
`panel_pop_pink` #FF84C6, `panel_pop_blue` #1F4FE0, `panel_pop_green` #16D84A, `panel_pop_yellow` #FFE23A, `panel_pop_red` #D4170F, `panel_paper_cream` #F4F2EC, `panel_ink_black` #0B0B0B, `panel_white` #FFFFFF, `panel_frost` #F1F3FA.
plates.json lists the right text color for each (checked for contrast). Switch panel color on the same frame as the headline slam. Brand color not listed: run the panel command above.

## 6. 3D AND PHOTOREAL (ChatGPT pack, file 08)
Order: style lock, emoji A1 to A8, objects B1 to B5, mascot C1 then C2a and C2b, devices D1 to D8.
Every image has a flat magenta #FF00FF background and no text. Then run section E of file 08:
- devices: `python3 tools/make_device_from_photo.py assets/devices_photo/_raw/device_*_green.png`
- sheets: `python3 tools/ingest_cutouts.py sheet <sheet>.png --bg magenta --prefix emoji_ --out assets/emoji --names <names line>`

Device script output, per device (stem `photo_<name>`): `_hole.png`, `_green.png`, `_glare.png`, `_preview.jpg`, and a device_specs.json entry with `screen_quad` (TL, TR, BR, BL), `screen` bbox + radius, `corner_radius`, `perspective`, `rotation_deg`, `content_size`, `css_matrix3d`, `files`.
How to use an entry in code: render the content at `content_size`, clip with the corner radius, apply `css_matrix3d` with transform-origin 0 0, put `_hole` on top, then `_glare` on top of that. When `perspective` is false, place the content at `screen` instead. A camera island that is black on the green screen stays opaque.
Tested on synthetic front and angled phone and laptop images: screen corners within 1.5 px of the truth, matrix3d maps the content box onto the quad exactly.

Naming: `emoji_<name>.png`, `obj3d_<name>.png`, `mascot_<name>_<pose>.png`, `photo_<name>_*.png`.

## 7. ADDED BY ME (not on your list)
- Contact shadows (4 PNG), loopable cloud layers, kraft paper tile, plates.json with UI zones and overlay rules.
- Sheet slicer and background keyer (`ingest_cutouts.py`), because ChatGPT returns sheets, not single files.
- Cultural note in the emoji section: no thumbs-up, ok-hand or alcohol, for Persian audiences.

## 7B. PHOTOREAL PLATES (v2, replaces the clay look)
Photoreal by file name (same names as before): sky_blue, sky_clouds, sky_clouds_dense, sky_greenhill, sky_sunset, sky_sunset_hill, studio_light, studio_warm, studio_dark, paper_cream, paper_white (all _169 and _916), plus hill_near and hill_far (alpha WebP).
- Old code versions: assets/scenes/_code_fallback/. To switch back, copy a file out and delete its name from assets/scenes/photoreal.lock.json.
- Prompts: 09_CHATGPT_PHOTOREAL_PLATES_STEP5B.md. Import tool: tools/ingest_photoreal_plates.py.
- build_plates.py now skips every file in photoreal.lock.json, so a rebuild cannot overwrite the photos.
- Parallax stack for the green hill is now sky_blue + hill_far + hill_near (hill_far is already lifted so the ridge shows). Do not use clouds_soft with photoreal plates, it looks soft next to a photo. sky_clouds, sky_clouds_dense and sky_sunset_hill are flat photos: animate with a push-in 1.00 to 1.05.
- Studio floor line is no longer 58 to 60 percent: see floor_y in plates.json (light 0.65 wide and 0.61 tall, warm 0.66 and 0.69, dark 0.59 and 0.60). Object base y stays 0.80 and 0.76.
- studio_warm has soft window light stripes on the left. Keep text and cards to the right two thirds, or use studio_light.
- sky_sunset_hill: white text needs a dark glass card or vignette_soft 30 percent on the orange band.
- Photos are cropped from 1536x1024 and 1024x1536 and upscaled 1.25x. Fine for video, soft if you zoom past 1.1.

## 7C. IPHONE-STYLE EMOJI (replaces the ChatGPT 3D emoji sheets A1 to A8)
- assets/emoji/emoji_<name>.png: 47 transparent PNGs (48 asked, coin left out on purpose, it carries text and a slogan), exported from the owner's Mac, cut out and defringed.
- assets/emoji/emoji.json maps each character to its file, with when to use it, when not to, size cap, motion and Persian RTL rules.
- Sharp up to about 260 px (source is about 190 to 200 px wide). For bigger hero emoji re-export a block at a larger font size and re-run tools/ingest_cutouts.py.
- Own promo videos only. Keep these images out of anything you sell.
- Section A of file 08 is no longer needed. B (objects), C (mascot) and D (devices) stay.


## 7D. 3D OBJECTS (DONE in v4)
- assets/objects3d/obj3d_<name>.png: 24 transparent PNGs, soft 3D look, each with its own natural color, cleaned of magenta spill. Raw sheets kept in assets/objects3d/_raw/, preview in assets/objects3d/_preview.jpg.
- Names: shopping-bag, coin-stack, piggy-bank, gift-box, price-tag, credit-card, shield-check, padlock, key, trophy, target, star, heart, paper-plane, chat-bubble, bell, envelope, megaphone, lightbulb, calendar, location-pin, magnifier, stopwatch, gear.
- assets/objects3d/objects3d.json: size and use_for per object. Items are about 210 to 265 px wide: sharp up to about 300 px on screen.
- Shadow: shadow_ellipse_round from assets/scenes, base at y 0.80 (169) or 0.76 (916).
- Still open: topic objects sheet (B5, 12 items for the product topic).


## 7F. MASCOT: YOUR ROBOT (DONE, replaces section C of file 08)
- assets/characters/robot/<clip>/NNN.webp: 304 transparent frames, 720x720, 7 clips: idle (60), wave (54), point_left (48), talk_calm (36), talk_energetic (36), shake (30), celebrate (40).
- assets/characters/robot/robot.json: frames per clip, suggested 30 fps, when to use each clip, missing poses.
- assets/characters/mascot_robot_<clip>.png: 7 stills (middle frame of each clip), for static scenes and thumbnails.
- Look: white robot, black tie, cyan eyes. Content is about 450 x 560 px inside the 720 frame, sharp up to about 600 px high.
- Every clip starts and ends on the idle pose, so clips chain (idle, wave, idle). In Remotion use the frame number as the file index.
- point_right: mirror point_left with scaleX(-1). Not yet made: think, surprised, error. Section C of file 08 (ChatGPT mascot sheets) is no longer needed unless you want those 3 poses.
- Shadow: shadow_ellipse_round from assets/scenes.
- This robot is the owner's own character. Keep it in the owner's videos. For a pack that is sold, swap in a generic original robot.


## 7G. PHOTOREAL GREEN-SCREEN DEVICES (DONE, 12 devices)
Files in assets/devices_photo/ per device `photo_<n>`: `_hole.webp` (device, transparent screen, content goes BEHIND it), `_green.webp` (flat #00FF00 screen, for keying), `_glare.png` (sheen, goes ON TOP of the content), `_preview.jpg` (proof).
Devices: phone_front, phone_34_left, phone_34_right, laptop_front, laptop_34, tablet_portrait, tablet_landscape, monitor_front, camera_back, camera_34 (black and silver), camera_blue_back, camera_blue_34 (pastel light blue, for photo, social and lifestyle topics).
assets/devices/device_specs.json now holds the old vector entries AND the 12 new `photo_*` entries (screen_quad, corner_radius, perspective, content_size, css_matrix3d, files). Let it overwrite the Step 4 copy.
How to use: render the content at content_size, clip with corner_radius, apply css_matrix3d with transform-origin 0 0, then _hole, then _glare. When perspective is false, place the content at `screen` instead.
Tested: the matrix3d maps the content box onto the screen quad within 0.05 px for all 12. Edge pixels carry no pink or green on light or dark backgrounds.
Script fixes: make_device_from_photo.py now removes the pink and green rim (defringe) and writes WebP for hole and green, so the pack stays small. The raw ChatGPT images are not in the zip (size).
Camera note: the blue camera has tiny printed labels on two buttons (a word and icons). Keep it under 400 px wide on screen, or ask ChatGPT for a version with blank buttons.
Use the cameras for photo, social, travel and creator topics. Keep phone, laptop, tablet and monitor for serious product videos.

## 7E. STEP 5 STATUS
COMPLETE (v4). Done: plates, emoji (47), 3D objects (24), robot mascot (7 clips, 304 frames), photoreal devices (12). plates.json, photoreal.lock.json, emoji.json, objects3d.json, robot.json and device_specs.json all parse and every file they list is present. Skipped on purpose: topic objects (B5), they depend on a product topic and are optional.

## 8. LIMITS
- Still code-built (stylized): clouds_soft, clouds_dense, clouds_sunset, hill_sunset, paper tiles, panels, shadows.
- The device script needs a flat green screen and a flat magenta (or transparent) background. It reports clearly when it cannot find the screen.

## NEXT
Step 6: SFX map and the script that scans your SFX zip.
