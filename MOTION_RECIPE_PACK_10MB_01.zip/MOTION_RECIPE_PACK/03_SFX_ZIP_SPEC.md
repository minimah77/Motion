# 03 — SFX ZIP SPEC (what to put in the zip you'll send)

Build one zip called **`SFX_PACK.zip`** with exactly this structure so the recipe/AI can call sounds **by name**.

## Technical
- WAV, 48 kHz, 24-bit (MP3 320 acceptable for SFX under 1 s), mono for UI sounds, stereo for whooshes/risers/ambience.
- Trim silence, 5–20 ms fade in/out, peaks −3 dBFS, no clipping.
- Naming: `category_descriptor_NN.wav` (lowercase, underscores, 2-digit variant number).
- Provide **2–4 variants** of each frequently used sound (click, whoosh, pop) to avoid repetition.

## Folder → file list (target ≈ 150 files)

```
SFX_PACK/
├─ transitions/            (3–5 variants each)
│   whoosh_soft · whoosh_fast · whoosh_air · whoosh_up · whoosh_down · whoosh_left · whoosh_right
│   swish_light · swipe_glass · slide_card · push_in · zoom_through · spin_whoosh
│   blur_sweep · reverse_swell · riser_short(1–2 s) · riser_long(3–5 s) · downlifter
├─ ui/
│   click_soft · click_tight · click_mouse · tap_glass · tap_phone · tick · toggle_on · toggle_off
│   pop_small · pop_bubble · pop_pill · hover_soft · select · deselect · drag_start · drop_settle
│   type_key_soft · type_burst(0.5 s) · type_mech · backspace · caret_blink · enter_key
│   message_send · message_receive · typing_dots · notification_soft · notification_ping
│   card_flip · card_stack · drawer_open · drawer_close · modal_in · modal_out
├─ feedback/
│   success_chime · success_check · complete_ding · level_up · error_soft · error_buzz · warning · progress_loop · progress_done · upload_whoosh · download_thunk · coin
├─ impacts/
│   hit_sub_deep · hit_soft · hit_cinematic · boom_short · thud_wood · stamp_logo · logo_hit · glass_hit · slam_text · sting_short
├─ magic/
│   shimmer · sparkle_up · sparkle_down · glow_swell · bloom_burst · twinkle · ai_think · ai_done · scan_beam · energy_charge
├─ text/
│   text_in_soft · text_in_pop · word_swap · highlight_swipe · underline_draw · caption_tick · letter_scatter · letter_gather · erase_swipe
├─ camera_foley/
│   shutter_click · camera_flash · film_projector · record_scratch · tape_stop · vinyl_crackle · typewriter_return
├─ retro_pixel/            (for archetypes E/K)
│   coin_8bit · jump_8bit · powerup_8bit · select_8bit · laser_8bit · glitch_short · glitch_long · static_burst · bit_crush_down · digital_dissolve
├─ countdown/
│   tick_clock · beep_low · beep_high · count_pop(0–9 pitched set) · zero_hit
├─ ambience/               (loopable 10–30 s, stereo)
│   room_tone_soft · air_hum · studio_dark · city_night_far · wind_gentle · space_drone · office_far
├─ music_stems/ (optional)
│   pulse_100bpm · pulse_120bpm · pad_warm · piano_minimal · lofi_bed · cinematic_swell
└─ _cue_sheet.csv          (optional, see below)
```

## Which SFX goes with which visual event (cue map the AI will follow)

| Visual event | SFX (start offset) |
|---|---|
| Hook text blur-reveal | `text/text_in_soft` (−3 f) + `magic/glow_swell` |
| Scene blur-through | `transitions/whoosh_soft` (−4 f) |
| Fast pan / whip | `transitions/whoosh_fast` (−3 f) |
| Zoom-through | `transitions/zoom_through` (−5 f) |
| Card/pill springs in | `ui/pop_pill` (0 f) |
| Cursor click | `ui/click_soft` (exact frame) |
| Typing in a search bar | `ui/type_burst` or `type_key_soft` per burst |
| Chat message out / in | `ui/message_send` / `message_receive` |
| Typing dots | `ui/typing_dots` |
| Success / checkmark | `feedback/success_check` + `magic/sparkle_up` |
| Big number lands | `impacts/hit_soft` + `feedback/coin` (optional) |
| Countdown number | `countdown/count_pop_N` |
| Glitch / pixel dissolve | `retro_pixel/glitch_short` / `digital_dissolve` |
| Logo settles | `impacts/logo_hit` + `magic/shimmer` (after 0.3 s silence) |
| CTA badge appears | `ui/pop_bubble` + `ui/tick` |
| Hook of whole video | `transitions/riser_short` leading into first hit |
| Erase / delete text | `text/erase_swipe` / `ui/backspace` |
| Camera shutter beat | `camera_foley/shutter_click` |

## Optional `_cue_sheet.csv` (lets the AI auto-place sounds)
```
file,category,length_s,loudness,tags,best_for
whoosh_soft_01.wav,transitions,0.6,-18,"soft air light",blur-through
click_soft_01.wav,ui,0.12,-20,"cursor tap",cursor-click
```

## Mixing numbers
- UI clicks −20 to −16 dBFS · whooshes −18 to −12 · impacts −10 to −6 · music bed −22 LUFS-ish · VO −16 LUFS.
- High-pass 60 Hz on all SFX except impacts. Ducking: music −6 dB when SFX peak, −10 dB under voice.

If you don't have enough sounds yet, tell me the folders you're missing and I'll write the exact search keywords (Freesound / Zapsplat / Epidemic / Envato) or a synthesis script that generates simple UI SFX locally.
