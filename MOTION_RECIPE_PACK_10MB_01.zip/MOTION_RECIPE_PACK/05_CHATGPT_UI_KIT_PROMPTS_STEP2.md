# 05 — CHATGPT PROMPTS, STEP 2: UI KIT, ATMOSPHERE, MOTION & TYPOGRAPHY
Run this **after** Step 1 (file 04), in the **same ChatGPT chat** so the style lock carries over. If it's a new chat, paste PROMPT 0 from file 04 first.

Contents: ① Glass cards ② Pills & highlight badges ③ Vector iconography (line + solid) ④ Minimal data indicators ⑤ Minimal device outlines ⑥ Backgrounds ⑦ Overlays & atmosphere ⑧ Glows ⑨ Gradients ⑩ Grain & noise ⑪ Motion mechanics (spec + code) ⑫ Typography system

Output rules (all prompts): transparent PNG (or SVG when asked), 2048 px+, centered, equal padding, consistent radius/stroke. Save into `/assets/ui-kit/` unless noted.

---

## ① GLASS CARDS  → `glass_card_*.png`
```
Create a UI kit sheet of 12 frosted-glass cards, each as a separate transparent PNG, 1600×1000 and 1000×1000 variants: (1) light glass, white 70% fill, soft blur, thin white inner stroke, soft shadow; (2) dark glass, #FFFFFF 8% fill, subtle blue edge-light, deep shadow; (3) glass with colored bloom behind (blue); (4) glass with orange bloom; (5) notification card (app icon slot left, 2 text lines, timestamp right — leave all text as gray placeholder bars); (6) chat bubble outgoing (accent blue); (7) chat bubble incoming (gray); (8) map card with rounded corners and an empty green area; (9) stat card with a big-number placeholder bar and a small trend line; (10) list card with 4 rows (icon dot + two bars); (11) input/search card capsule with magnifier left and mic right; (12) modal card with title bar, two bars of text and two buttons. Radius 44 px at 1080 base, 1 px top-light stroke, realistic refraction softness, no real text, no logos.
```
**Variants to ask next:** "Make the same 12 in dark mode / frost-blue / ember (orange-red) / primary-pop flat (no blur, thick black outline)."

## ② PILLS & HIGHLIGHT BADGES  → `pill_*.png`, `badge_*.png`
```
Create a set of 24 pill-shaped UI elements and highlight badges on transparent background, equal height 120 px, varying widths, consistent style: 6 solid pills (blue, orange, green, pink, black, white), 6 glass pills (light/dark), 4 gradient pills with soft outer glow, 4 outlined pills (2 px stroke), 4 "tag" badges with a tiny colored dot at left. Include 6 highlight badges: "NEW", "FREE", "TOP", "LIVE", "PRO", "+1" shapes (use abstract placeholder letter shapes, leave real wording blank), a verified-check badge, a sticker-style starburst badge, a tilted ribbon, a notification dot with number placeholder, a corner-fold label, and a circular "comment" CTA badge. Soft shadow, crisp edges.
```
```
Create 8 "keyword highlight boxes" for kinetic text: a rounded rectangle with a 2 px white stroke and four small square corner handles (vector-editor selection look), in 4 colors, plus a filled variant, plus an underline-swipe brush stroke in 4 colors. Transparent background.
```

## ③ VECTOR ICONOGRAPHY — LINE ART & SOLID  → SVG preferred
```
Design a cohesive icon system of 96 icons in TWO styles — (A) line art, 2 px stroke on a 24 px grid, round caps/joins; (B) solid/filled with the same silhouettes. Categories (12 each): Navigation & actions (home, search, back, forward, close, plus, minus, menu, share, download, upload, external-link); Communication (chat, mail, phone, bell, send, mic, camera, video, at, link, comment, heart); Commerce & money (bag, cart, card, wallet, coin, receipt, tag, gift, bank, chart-up, percent, piggy); Productivity (calendar, clock, folder, file, note, check, checklist, pin, bookmark, filter, edit, trash); Tech & AI (spark, cpu, code, terminal, cloud, wifi, battery, lock, key, shield, magic-wand, robot); Place & travel (map-pin, route, car, plane, train, compass, globe, building, store, coffee, ticket, luggage); People & social (user, users, avatar, follow, like, star, trophy, flag, eye, smile, hand, thumbs-up); Media (play, pause, stop, music, image, film, book, mic-voice, headphones, volume, record, layers). Output as a clean contact sheet PNG and ALSO as SVG code for each icon (single path, currentColor), so I can recolor them.
```
Ask for: "Duotone version (solid shape + 40 % tint layer) and a 3D-glossy version of the 24 most important icons."

## ④ MINIMAL DATA INDICATORS  → `data_*.png/svg`
```
Create a minimalist data-visualization kit on transparent background, thin-line + one accent color, lots of whitespace: progress bars (thin 8 px, thick pill 24 px, segmented), progress ring (25/50/75/100 %), loading spinners (ring, dots, bars), battery/level meter, slider with handle, toggle switches on/off, checkbox & radio (checked/unchecked), step-indicator dots (1–5), stat tiles with big-number placeholder + delta arrow, sparkline (rising), area chart (smooth), bar chart (7 bars, one highlighted), donut chart (3 segments), line chart with a highlighted tooltip dot, calendar heat grid, countdown timer capsule, percentage badge (76%/99%), rating stars, upload progress rows with green checkmarks, a clean "Success" check circle with glow. No real numbers/text; use gray bars as placeholders.
```
```
Create a typographic number set 0–9 in a clean light mono and a heavy grotesque, each digit as a separate transparent PNG, plus accent-color versions, for the countdown archetype.
```

## ⑤ MINIMAL DEVICE OUTLINES  → `outline_*.svg/png`
```
Draw minimal device outlines as thin 3 px line-art (no fill, round joins), on transparent background, in black AND white versions: phone front, phone 3/4, laptop open, laptop closed, tablet landscape, tablet portrait, monitor with stand, smartwatch, browser window, notification banner, keyboard (simple), earbuds + case, camera, game controller. Equal visual weight, 2048 px, exportable as SVG paths.
```

## ⑥ BACKGROUNDS  → `/assets/scenes/` (see file 04 for photoreal plates)
```
Create 12 minimal abstract backgrounds in 16:9 and 9:16: (1) frost white-lavender soft mesh; (2) pure black with a bottom blue glow arc (planet-rim); (3) deep black with orange-red radial bottom glow; (4) black with vertical hourglass light beam (orange to red); (5) cream paper with faint grid; (6) dark charcoal grid dots; (7) soft dotted halftone gradient; (8) glass-blue to white vertical gradient; (9) midnight blue to black radial; (10) pastel peach-pink sunset gradient; (11) flat solid with subtle grain (give 5 colors); (12) subtle diagonal light rays on dark.
```

## ⑦ OVERLAYS & ATMOSPHERE  → `/assets/overlays/`
(ChatGPT makes still frames; I use them as PNG/JPG layers in blend modes. For animation, ask for sprite sheets/sequences as noted.)
```
Create overlay elements for compositing, each on PURE BLACK background (for Screen/Add blend) unless noted, 3840×2160 and 2160×3840: (1) 6 warm light leaks (orange, red, amber, pink edges); (2) 6 cool light leaks (blue, cyan, violet); (3) 4 anamorphic horizontal lens flares; (4) 4 round bokeh fields (soft, large); (5) floating dust particles field, fine; (6) glitter/sparkle field; (7) volumetric god-rays from top-left; (8) soft fog/haze drifting; (9) vertical hourglass light beam; (10) light sweep streak (diagonal glossy sweep) ; (11) lens dirt/smudge; (12) film burn edges. Then on WHITE background for Multiply: (13) paper fibers; (14) ink splatter (3 shapes); (15) paint streak brushes (6); (16) torn paper edges. Then as transparent PNG: (17) vignette (soft black edge, 20 % and 40 %); (18) scanlines; (19) halftone dot gradient (left→right fade); (20) pixel-mosaic dissolve pattern (squares of varied size, orange-yellow).
```
```
Create a 4×4 SPRITE SHEET (16 frames, equal cells, black background) showing a smooth sequence: (a) a flash burst expanding and fading; (b) a lens flare sweeping left to right; (c) sparkle twinkle cycle; (d) a ring ripple expanding and fading. Make each as its own sheet so I can play it as a frame sequence.
```

## ⑧ GLOWS  → `/assets/overlays/glow_*.png`
```
Create glow assets on pure black, center-aligned, 2048×2048: soft radial glow in blue (#2F6BFF), cyan, violet, orange (#FF7A2E), red, magenta, green (#34D399), white; each in 3 intensities (soft / medium / hot core). Then: rim-light arcs (blue, orange) curving like a planet horizon; neon line glow strips (horizontal, vertical); a soft "bloom burst" starburst; a button halo ring; a glass edge-light stroke (white to transparent); a drop-glow underlay shaped like a rounded rectangle (to sit behind cards) in each color.
```

## ⑨ GRADIENTS  → `/assets/ui-kit/grad_*.png`
```
Create 24 premium gradient swatches 2048×2048, smooth with zero banding: 8 pastel mesh gradients (frost, peach, lilac, mint, sky, rose, lemon, ice), 8 vivid duotones (blue→violet, orange→red, pink→orange, green→teal, blue→cyan, red→black, purple→black, orange→black), 4 glass-sheen gradients (white 80%→transparent), 4 chrome/metallic gradients. Provide each as PNG and list their hex stops.
```
Ask: "Give me CSS/SVG definitions for each gradient (hex stops + angle) so I can use them in code."

## ⑩ GRAIN & NOISE  → `/assets/textures/grain_*.png`
```
Create seamless tileable textures 2048×2048: (1) fine monochrome film grain (neutral gray, to overlay at 4–8%); (2) coarse film grain; (3) digital noise (RGB subtle); (4) paper fibers; (5) canvas weave; (6) halftone dots 20 lpi; (7) VHS static band; (8) soft cloudy noise (for gradient breaking); (9) dust & scratches (black bg); (10) risograph speckle (cream). Provide on mid-gray (#808080) for Overlay/Soft-Light use.
```
Usage: Overlay/Soft-Light at 4–8 %, one pass on top of the final comp.

## ⑪ MOTION MECHANICS  (ChatGPT can't render video — ask it for specs + code)
Paste this to get **ready-to-use motion code and presets**:
```
Act as a motion-graphics engineer. Produce a "Motion Mechanics" library for my video style, for BOTH (a) Remotion/React (TypeScript) and (b) CSS/GSAP. Include, with exact parameters and copy-paste code:
1. SNAP-AND-SETTLE (spring) presets: hero (stiffness 170, damping 18), snappy (260/20), soft (100/16) + helper `useSpring(frame, fps, preset)`.
2. BLUR-REVEAL text (per word & per letter): opacity 0→1, blur 30→0 px, y 16→0, stagger 3 f/word; accent word delayed 6 f.
3. SNAP-AND-ERASE: backspace erase of text with caret, and masked left-to-right soft-edge wipe erase.
4. SMOOTH CAMERA PAN with parallax layers (0.5×, 1×, 1.5×) and easeInOutCubic over 24–40 f.
5. SCALE ZOOMS: always-on push-in (1→1.06), punch zoom (1→1.25 in 8 f), zoom-through transition (scale 1→6 then 0.3→1).
6. 3D TILT card/device with perspective 1200 px, rotateX/Y ±12–25° and floating bob.
7. GLOW BREATHE loop (opacity 35↔60 %, 60 f sine) and hue drift.
8. CURSOR: eased arc path, hover, click scale 0.88 + ripple ring.
9. STAGGERED CARD STACK enter/exit and "flip-through" scrub.
10. TYPE-ON with caret and selection highlight.
11. COUNTER roll-up (number animates with easeOutExpo and tabular figures).
12. PROGRESS BAR / RING fill and SUCCESS CHECK stroke-draw.
13. GRAIN overlay, vignette and chromatic aberration pulse on beat.
14. TRANSITIONS: blur-through, push, whip-pan, glass-wipe, zoom-through, pixel-dissolve, flash-cut — each as a reusable component with `duration` and `easing` props.
Deliver as a single well-commented file per target, a README with a table of every preset name → parameters, and a small demo composition that shows each effect for 2 seconds.
```
Also paste this to get **After Effects / CapCut / Premiere equivalents**:
```
For every mechanic above, give me the equivalent in After Effects (expressions & property values; e.g. overshoot spring expression), CapCut (keyframe + graph settings) and Premiere (Transform keyframes + Bezier handles). Format as a table: mechanic | AE | CapCut | Premiere.
```

## ⑫ PROFESSIONAL TYPOGRAPHY SYSTEM
```
Design a professional typography system for motion videos for brand [PRODUCT_NAME]. Output a spec sheet as an image AND as a table I can copy:
- Font pairings (3 options), all free for commercial use (Google Fonts/Open Foundry): Option 1 = heavy grotesque display (Archivo Black / Bricolage Grotesque ExtraBold) + neutral UI sans (Inter Tight / Geist) + italic serif accent (Instrument Serif Italic); Option 2 = clean Swiss grotesque (Inter / Schibsted Grotesk) + mono (Space Mono / JetBrains Mono) + pixel (Silkscreen / Press Start 2P); Option 3 = geometric (DM Sans / Plus Jakarta Sans) + serif (Playfair Display Italic / Fraunces) + mono.
- Type scale for 1080×1920 AND 1920×1080: Hero, H1, H2, Body, Caption, Label (size px, weight, line-height, tracking %).
- Caption styles: word-by-word highlight (active word accent + scale 105%), 2-line max, safe-zone positions, stroke/shadow rules for photoreal backgrounds.
- Rules: max words per line, text color/contrast on light vs dark, accent-word treatments (color, italic serif swap, glow, highlight box, underline swipe), numeral style (tabular, mono), uppercase label style (+8% tracking).
- 12 specimen cards showing the type in use: hero headline, 2-line headline with accent word, UI label, big number, caption, CTA pill text, quote, lower-third, countdown digits, search-bar text, code card text, wordmark lockup.
- Animation notes per style (entry, exit, stagger).
```
Typography generator add-on:
```
Create a wordmark for "[PRODUCT_NAME]" in 6 treatments on transparent background: heavy grotesque, soft rounded, serif italic, mono, pixel, outline. Each in black and white versions, plus a glossy-glass 3D version and a blurred-glow version for the reveal animation (letters sharp, and the same letters blurred/glowing).
```

---

## FINAL KIT CHECK (paste at the very end)
```
Create a master ASSET MANIFEST table of everything generated in this chat: file name, category, size, transparent? (Y/N), recommended layer blend mode, and which video archetype (A–K) uses it. Then list anything still missing for a professional 9:16 + 16:9 product video and give me a prompt for each.
```
