# 08 CHATGPT PROMPTS, STEP 5
3D emoji, 3D objects, mascot poses, photoreal green-screen devices.
Everything here is what code cannot make. Scenes, icons, glass, cursors and vector devices are already in the pack.

Result: 48 emoji, 24 to 30 objects, 1 mascot with 12 poses, 8 photoreal devices, all named, keyed and registered by two scripts.

---

## HOW TO RUN (read once)
1. Open ONE new ChatGPT chat with image generation on. Paste PROMPT 0 first. Stay in that chat for the whole step, so every image matches.
2. Paste one prompt at a time. Fill the [BRACKETS] once (brand colors, mascot name, topic objects).
3. Every image has a flat pure magenta #FF00FF background. Magenta is the only color the scripts remove, and nothing in the pack uses it.
4. Sheets: one image holds 6 items in a 3 by 2 grid. The script slices the sheet into separate PNGs and names them from the `names:` line under each prompt, in reading order (top row left to right, then bottom row).
5. Save each result with the file name shown in `save as`. Put sheets in a work folder, then run section E.
6. Open the contact sheet or preview the script writes. If an item is wrong, regenerate only that sheet.
7. No text anywhere in any image. Persian text, numbers and product names are always added in code.

---

## PROMPT 0: STYLE LOCK (paste first, once)
```
You are my art director and asset generator for a motion design studio. For this whole chat follow this style lock.

LOOK: glossy soft 3D render, round smooth forms, bright saturated gradients, soft specular highlight from the top left, gentle rim light, tiny inner glow, clean and friendly. Premium and minimal, never cluttered.
COLOR: brand primary [#2F6BFF], brand accent [#FF7A2E], neutrals #F1F3FA, #0B0B0B, #FFFFFF. Use the brand colors as main materials unless I name another color.
ORIGINAL ONLY: never copy any real brand, logo, app, emoji set, character or screenshot. Invent fictional stand-ins.
NO TEXT: no letters, numbers, Persian or Latin script, logos or watermarks anywhere. Signs, screens and badges stay blank.
BACKGROUND: every image has a flat, uniform, pure magenta #FF00FF background. No floor, no gradient, no vignette, no cast shadow, no reflection on the background.
LAYOUT: when I ask for a sheet, put exactly the number of items I give in a grid, equal size, centered in their cells, with big empty gaps (at least 15 percent of an item's width) so nothing touches or overlaps.
DETAIL: sharp edges, high resolution, consistent lighting and perspective across all items.
Reply only with the image, and one line with the file name in lowercase_snake_case.png.
Confirm with "Style lock ready" and wait for my first request.
```

---

## A. 3D EMOJI (8 sheets, 48 items)  save to `assets/emoji/`  file names `emoji_<name>.png`
Look: original glossy 3D emoji. Not copies of any platform's emoji.
Culture note for Persian audiences: no thumbs-up, no ok-hand and no alcohol are included, because they can read as rude or off in some Persian contexts. Swap in your own if your audience is different.

Use this wrapper for every sheet (replace the list):
```
One image, landscape 3:2, flat pure magenta #FF00FF background. Six original glossy 3D emoji in a 3 by 2 grid, equal size, large gaps, nothing touching. Round smooth forms, bright gradients, soft specular highlight top left, expressive simple faces, no text. Left to right, top to bottom: [LIST]
```
| Sheet | [LIST] | save as | names: |
|---|---|---|---|
| A1 | grinning face, laughing with tears of joy, winking face, heart eyes, star struck eyes, cool face with sunglasses | emoji_sheet_1.png | grin,joy,wink,heart-eyes,star-struck,cool |
| A2 | thinking face with hand on chin, shocked face with open mouth, mind blown face with exploding head, sad face with one tear, angry red face, party face with party hat | emoji_sheet_2.png | thinking,shocked,mind-blown,sad,angry,party-face |
| A3 | clapping hands, victory hand, waving hand, handshake, flexed arm, two raised hands | emoji_sheet_3.png | clap,victory,wave,handshake,muscle,raised-hands |
| A4 | hand with index finger pointing up, folded hands, fire, sparkles, red heart, blue heart | emoji_sheet_4.png | point-up,folded-hands,fire,sparkles,heart-red,heart-blue |
| A5 | green check mark, red cross mark, warning triangle, padlock, golden key, light bulb | emoji_sheet_5.png | check-mark,cross,warning,lock,key,light-bulb |
| A6 | rocket, golden trophy, money bag, gold coin, chart going up, gift box with ribbon | emoji_sheet_6.png | rocket,trophy,money-bag,coin,chart-up,gift |
| A7 | wall calendar, alarm clock, smartphone, laptop, camera, headphones | emoji_sheet_7.png | calendar,clock,phone,laptop,camera,headphones |
| A8 | coffee cup with steam, globe, sun, crescent moon, cloud, green leaf | emoji_sheet_8.png | coffee,globe,sun,moon,cloud,leaf |

Rules: faces are blank of any text. Phone, laptop and calendar screens stay blank. No brand shapes.

---

## B. 3D OBJECTS (DONE: 24 objects, only the topic sheet B5 is open)  save to `assets/objects3d/`  file names `obj3d_<name>.png`
Wrapper:
```
One image, landscape 3:2, flat pure magenta #FF00FF background. Six glossy soft 3D objects in a 3 by 2 grid, equal size, large gaps, nothing touching. Main materials in brand blue [#2F6BFF] and brand orange [#FF7A2E] with white and soft grey details, one dominant color per object. Soft specular highlight top left, gentle rim light, no text, no logos, no cast shadow. Left to right, top to bottom: [LIST]
```
| Sheet | [LIST] | save as | names: |
|---|---|---|---|
| B1 | shopping bag, stack of coins, piggy bank, gift box, price tag, blank credit card | obj_sheet_1.png | shopping-bag,coin-stack,piggy-bank,gift-box,price-tag,credit-card |
| B2 | heart, paper plane, chat bubble, notification bell, envelope, megaphone | obj_sheet_2.png | heart,paper-plane,chat-bubble,bell,envelope,megaphone |
| B3 | shield with check mark, padlock, key, trophy, target with arrow, star | obj_sheet_3.png | shield-check,padlock,key,trophy,target,star |
| B4 | light bulb, calendar page, location pin, magnifying glass, stopwatch, gear | obj_sheet_4.png | lightbulb,calendar,location-pin,magnifier,stopwatch,gear |
| B5 (your topic) | [OBJECT 1], [OBJECT 2], [OBJECT 3], [OBJECT 4], [OBJECT 5], [OBJECT 6] | obj_sheet_5.png | [name1],[name2],[name3],[name4],[name5],[name6] |

For B5 pick 6 things a viewer of your product topic recognizes in half a second (for a food app: pizza box, bowl, delivery scooter, receipt, cup, fork and spoon).

---

## C. MASCOT (DONE: owner robot clips are in assets/characters/robot, skip this section)  save to `assets/characters/`  file names `mascot_<name>_<pose>.png`

**C1: design** (save as `mascot_design.png`, for review only, not keyed)
```
Design an original cute 3D mascot named [MASCOT_NAME] for a [PRODUCT CATEGORY] product. Friendly rounded character, simple large eyes, small body, soft matte white ceramic body with brand blue [#2F6BFF] and orange [#FF7A2E] accents, a blank round badge on the chest, no text. Show a turnaround sheet on flat magenta #FF00FF: front, three quarter, side, same height, large gaps.
```
Keep the best result. Do not change the character after this point.

**C2: poses.** Wrapper:
```
Same mascot as the design sheet above, exactly the same proportions, colors and materials. One image, landscape 3:2, flat pure magenta #FF00FF background, six poses in a 3 by 2 grid, equal height, large gaps, nothing touching, no text, blank signs and blank phone screens. Left to right, top to bottom: [LIST]
```
| Sheet | [LIST] | save as | names: |
|---|---|---|---|
| C2a | standing idle, waving, pointing to the left, pointing to the right, thinking with hand on chin, surprised with both hands up | mascot_sheet_1.png | idle,wave,point-left,point-right,think,surprised |
| C2b | happy jump, sad with head down, holding a blank sign board, holding a blank phone, presenting with one open hand, celebrating with both arms up | mascot_sheet_2.png | happy-jump,sad,hold-sign,hold-phone,present,celebrate |

Run the slicer with `--prefix mascot_[MASCOT_NAME]_`.

---

## D. PHOTOREAL GREEN-SCREEN DEVICES (DONE: 12 devices, see manifest 7G)  save to `assets/devices_photo/_raw/`  file names `device_<name>_green.png`
These add real photographic devices next to the vector frames in `assets/devices`. One device per image.

Wrapper (fill [DEVICE]):
```
Photoreal studio product photograph of [DEVICE]. The device is centered and fills about 80 percent of the frame, fully visible, sharp focus, soft studio light, realistic materials. The screen is a perfectly flat, uniform, unlit, pure #00FF00 green area with no reflection, no glare, no gradient, no UI, no content, and no green glow spilling onto the frame. No logos, no brand names, no text anywhere on the device. Background: flat uniform pure magenta #FF00FF, no floor, no shadow, no reflection, no gradient. Original fictional design.
```
| Id | [DEVICE] | save as | name |
|---|---|---|---|
| D1 | a modern flagship smartphone, perfectly front facing, slim black titanium frame, black pill shaped camera island at the top of the screen, subtle side buttons | device_phone_front_green.png | phone_front |
| D2 | the same smartphone rotated 25 degrees around the vertical axis, left edge nearer the camera, three quarter view | device_phone_34_left_green.png | phone_34_left |
| D3 | the same smartphone rotated 25 degrees the other way, right edge nearer the camera | device_phone_34_right_green.png | phone_34_right |
| D4 | a thin aluminum laptop, open about 105 degrees, straight front view at screen height, thin black bezel, keyboard and base visible, no notch | device_laptop_front_green.png | laptop_front |
| D5 | the same laptop rotated 30 degrees around the vertical axis, three quarter view from the left | device_laptop_34_green.png | laptop_34 |
| D6 | a modern tablet in portrait, perfectly front facing, thin rounded bezel | device_tablet_portrait_green.png | tablet_portrait |
| D7 | a modern tablet in landscape, perfectly front facing, thin rounded bezel | device_tablet_landscape_green.png | tablet_landscape |
| D8 | a slim 27 inch desktop monitor on a minimal stand, perfectly front facing | device_monitor_front_green.png | monitor_front |

Keep D2 and D3 in the same chat as D1 so the phone matches. Same for the laptop and the tablet.
Angled views are supported: the script fits the four screen corners with perspective.

---

## E. AFTER YOU DOWNLOAD (run from the pack root)
Needs Python 3 with `pip install numpy opencv-python pillow`.

**Devices** (one command for all):
```
python3 tools/make_device_from_photo.py assets/devices_photo/_raw/device_*_green.png
```
Per device you get `photo_<name>_hole.png`, `photo_<name>_green.png`, `photo_<name>_glare.png`, `photo_<name>_preview.jpg`, and one entry in `assets/devices/device_specs.json` with the screen quad, corner radius, content size and a ready CSS `matrix3d`. A black camera island on the screen is kept opaque.

**Emoji, objects, mascot** (one command per sheet, copy the `names:` line):
```
python3 tools/ingest_cutouts.py sheet emoji_sheet_1.png --bg magenta --prefix emoji_ --out assets/emoji --names grin,joy,wink,heart-eyes,star-struck,cool
python3 tools/ingest_cutouts.py sheet obj_sheet_1.png --bg magenta --prefix obj3d_ --out assets/objects3d --names shopping-bag,coin-stack,piggy-bank,gift-box,price-tag,credit-card
python3 tools/ingest_cutouts.py sheet mascot_sheet_1.png --bg magenta --prefix mascot_pom_ --out assets/characters --names idle,wave,point-left,point-right,think,surprised
```
A single image: `python3 tools/ingest_cutouts.py single in.png out.png --bg magenta`

Check every time: open `_contact_sheet.jpg` (sheets) or `photo_*_preview.jpg` (devices). If the script warns about the item count, regenerate that sheet.

---

## F. QUICK FIXES
| Problem | Say this to ChatGPT |
|---|---|
| Checkerboard or white background | "Same image on a flat pure magenta #FF00FF background, nothing else." |
| Shadow or floor under items | "Remove all shadows, floor and reflections. Items float on flat magenta." |
| Items touch or overlap | "Same items, but 30 percent smaller with large gaps between them." |
| Wrong number of items | "Exactly six items, 3 by 2 grid, no extras." |
| Letters or numbers appear | "Remove all text and symbols. Blank surfaces only." |
| Device screen is not flat green | "The screen must be one flat unlit #00FF00, no gradient, no reflection, no content." |
| Green spill on device frame | "No green light on the frame or bezel. Only the screen is green." |
| Mascot drifted | "Match the design sheet exactly: same head shape, eyes, colors and badge." |
| Script finds no green screen | The screen is too dark or too small. Regenerate the device larger and brighter green. |
