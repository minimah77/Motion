# 01 — MASTER RECIPE: "Your Signature Motion Video"

One recipe file. Feed it to an AI (Claude, ChatGPT) or follow it by hand in After Effects / CapCut / Premiere / Figma / Remotion.
It is built from a frame-by-frame study of your 17 reference videos (9–120 s). It describes the **grammar** behind them, not their content, so everything you make with it is your own style.

> Honesty note: numbers below (durations, easings, springs, hex colors) are my reconstruction from the frames, cut timing and audio of your files. They are accurate enough to reproduce the *feel*; tune ±10–20 % by eye.

---

## 0. THE STYLE DNA (true of all 17 videos)

1. **One idea per beat.** Each beat shows ONE thing (a word, a card, a device, an icon) for 0.5–4 s. Never two competing focal points.
2. **Words are tiny.** On-screen text is 2–6 words per beat. Highlight 1 word with color, italic serif, glow or box.
3. **Hero object + clean world.** A single hero (phone, laptop, card, mascot, logo, search bar) sits in a calm environment: soft pastel gradient, deep black with a colored glow, flat solid color, or a sky/landscape plate.
4. **Glass + glow.** UI floats as frosted-glass cards with 1 px light edge, soft shadow and a colored bloom behind them.
5. **Everything arrives with a spring and leaves with a blur.** Snap-and-settle in (slight overshoot), blur + fade/scale out. Nothing pops in linearly.
6. **A cursor tells the story.** For software/product videos an animated cursor moves, hovers, clicks (scale-down 90 %), and the UI reacts.
7. **Camera is always alive.** Slow push-in, 3D tilt, pan, or scale-zoom happens under every static moment (3–8 % scale drift over the shot).
8. **Sound on every motion.** Each movement, click, text appearance and cut has an SFX; music is quiet bed (see §9).
9. **Blur is a transition tool.** Gaussian/directional blur (20–60 px) bridges almost every change between scenes.
10. **Punch ending.** Last 1.5–3 s = logo / CTA / "Comment X" with a settle and a short hold.

---

## 1. OUTPUT SPECS

| Item | Value |
|---|---|
| Masters | 9:16 = 1080×1920 (your refs: 720×1280) · 16:9 = 1920×1080 (refs: 1280×720) · 1:1 = 1080×1080 · 4:3 = 1440×1080 |
| Frame rate | **30 fps** default. 60 fps for UI-heavy/clean motion (ref 43ac was 60). 24 fps only for cinematic/photoreal. |
| Codec | H.264, High profile, 12–20 Mbps (1080p), AAC 48 kHz 320 kbps, yuv420p, `-movflags +faststart` |
| Color | sRGB / Rec.709, no HDR |
| Loudness | integrated ≈ **-14 LUFS**, true peak ≤ -1 dBTP (your refs average ≈ -16 dB mean, peaks ≈ 0 dB, i.e. punchy) |
| Safe zones 9:16 | keep text inside x 8–92 %, y 12–80 % (bottom 20 % = platform UI) |
| Safe zones 16:9 | 5 % margins; lower-third band y 78–92 % |
| Design once | Build in **1080×1920 and 1920×1080 layouts from the same scene JSON**; never just crop. |

Length targets (from your refs): **Hook 10–16 s** (logo/UI loop), **Explainer 15–25 s**, **Story 30–75 s**, **Long 2 min** (talking head + motion cutaways).

---

## 2. THE 11 VIDEO ARCHETYPES (pick ONE per video)

For each: beat structure, cut rhythm, typical length. "Ref" = which of your videos shows it.

| # | Archetype | Looks like | Rhythm | Length | Ref |
|---|---|---|---|---|---|
| A | **Brand Reveal + Design System** | Dark glow → glossy shape morphs → wordmark blurs in letter-by-letter → light "design board" (type specimen, color circles, icon grid) → mockup | slow, 1 cut | 12 s | Kristal |
| B | **UI Flow Story** | Chat bubbles → single UI card per step (search → choose → confirm → arriving) → map/car → logo | 1 card per 1.5–2.5 s | 20–25 s | Uber, Drive |
| C | **Sky-Plate Product Hero** | Photoreal sky/hill plate, a glass search bar or laptop floats, type-on, then results grid/zoom | calm 3–5 s shots | 15–25 s | Pinterest, laptop-in-clouds |
| D | **Kinetic Typography** | Words animate on a plain background, one accent word swaps (wander/ask/build…), 3D tilting image cards, stacked repeating word | 0.7–3 s | 15–35 s | "Design is like a game", Bewegung |
| E | **Pixel / Voxel Storyworld** | Low-poly 3D room + pixel character, giant bold words slam in between | 1.5–2 s | 60–120 s | Miftahul |
| F | **Talking Head + Motion Cutaways** | Face cam (dark warm), cut away to UI screenshots / graphics with word-by-word captions and short labels | 0.9–5 s | 50–120 s | Claude & invideo videos |
| G | **App Promo (flat color panels)** | Solid color background per beat (pink/blue/green/yellow/red), 3D phone rotates, pills/cards fly in, 2-line headline | 1.2–2 s | 16–25 s | Moolah |
| H | **3D Mascot Explainer** | Glossy 3D mascot left/right + dark glass cards with one fact each, big numbers, code cards | 2–4 s | 40–70 s | Brud Code |
| I | **Typographic Countdown** | White page, numbers fan out in a ring/grid, count from N→0 with one accent-color number | 1 s per number | 12–16 s | 15→0 |
| J | **Screen-in-Setup POV** | A real desk, monitor + keyboard + red glow ball, motion piece plays on the monitor; caption on top "POV: …" | continuous | 15 s | Apple Intelligence |
| K | **Icon Ring / Object Montage** | Pixel/3D objects (vinyl, camera, heart, coin, game pad) orbit/stack on cream, giant black type in dark inserts | 0.7 s | 15–25 s | curiosity/love |

---

## 3. THE UNIVERSAL TIMELINE (works for any archetype)

**30-second template** (scale proportionally):

| Time | Beat | What happens | Cut/Transition |
|---|---|---|---|
| 0.0–1.5 | **HOOK** | Question or bold claim (≤6 words) + movement already in progress. No logo yet. | none (start mid-motion) |
| 1.5–6 | **PROBLEM / SETUP** | Show the pain or the "before": messy, slow, plain. | blur-through |
| 6–20 | **SOLUTION STEPS** (3–5 beats) | One UI state / one feature per beat. Cursor drives. Each beat = headline word + hero UI. | spring-swap, push, zoom-through |
| 20–25 | **PROOF / WOW** | Big number, result, before/after, happy state. | scale-punch + glow burst |
| 25–30 | **PAYOFF + CTA** | Logo settle, tagline, "Try it / Comment X / Follow". Hold 1.2 s. | fade-to-solid or blur-out |

15-second version: Hook 1.5 · Steps 3 × 2.5 s · Payoff 4 s.
60-second version: add 2 more steps and a mid "reset" beat (color/background change) at ~50 % to refresh attention.

**Retention rule:** change *something* (background color, camera angle, layout, accent) every 2–4 s even if the content continues.

---

## 4. DESIGN TOKENS

### 4.1 Palettes (pick 1 per video; accents max 2)
Extracted moods from your files — replace hexes with your product colors.

| Palette | Background | Surface | Accent 1 | Accent 2 | Text |
|---|---|---|---|---|---|
| **Frost Blue** (Kristal, Drive, Pinned) | `#F1F3FA` → `#E6EAF7` | `#FFFFFF` @ 70 % glass | `#2F6BFF` | `#7FB2FF` | `#0E1330` |
| **Midnight Glass** (Drive dark, Brud, ChatGPT) | `#07080C` → `#0E1118` | `#161A24` @ 60 % | `#2F6BFF` / `#FF7A2E` | `#34D399` | `#F5F7FF` |
| **Ember** (Apple POV, Claude hero) | `#0A0306` | `#1B0B08` | `#FF4A1C` | `#FFB000` | `#FFF3E8` |
| **Primary Pop** (Moolah) | solids `#FF84C6` `#1F4FE0` `#16D84A` `#FFE23A` `#D4170F` | `#FFFFFF` / `#0B0B0B` | `#0B0B0B` | `#FFFFFF` | `#0B0B0B` |
| **Sky** (hills, clouds) | `#7EC4FF` → `#EAF6FF` | `#FFFFFF` @ 60 % | `#2FB86B` (grass) | `#FFFFFF` | `#0F1B2D` |
| **Paper & Ink** (typography films) | `#F4F2EC` | `#FFFFFF` | `#FF3B30` | `#2F6BFF` | `#111111` |

Always add: **1 neutral dark `#0B0B0B`**, **1 pure white**, **1 glow tint** = accent @ 35–60 % opacity.

### 4.2 Typography (details in file 05)
- Display: heavy grotesque, tight tracking (-3 to -5 %), line-height 0.9–1.0 (ref: "Tailored to you", "Save the Vibe").
- UI/body: neutral grotesque (Neue Haas / Inter-class), tracking -1 %, 400/500/600.
- Accent: italic **serif** for 1 emotional word ("beautiful", "videos"), or **mono** for technical/labels.
- Pixel font only inside pixel archetypes (E, K).
- Scale (1080 wide): Hero 160–240 px · H1 96–132 · H2 56–72 · Body 36–44 · Label 24–28 (mono, uppercase, +8 % tracking).

### 4.3 Shape & surface
- Corner radius: cards 36–48 px (1080 base), pills = fully round, device = 0.12 × width.
- Glass: fill white 55–75 % (light) or `#FFFFFF` 6–10 % (dark); backdrop-blur 24–40 px; 1 px inner stroke white 60 % top / 10 % bottom; shadow `0 30 80 -20 rgba(15,25,60,.25)`; colored bloom behind (accent, blur 120 px, 40 %).
- Grain: monochrome noise 3–6 % over everything (dark scenes up to 8 %).
- Vignette: 12–20 % on dark/photoreal scenes only.

---

## 5. MOTION LANGUAGE (the "feel")

### 5.1 Easing & spring constants
| Name | Use | Value |
|---|---|---|
| **Settle (hero spring)** | anything arriving | spring stiffness 170, damping 18, mass 1 → ~6 % overshoot, ~450 ms |
| **Snappy** | pills, badges, cursor targets | stiffness 260, damping 20 → ~3 % overshoot, ~300 ms |
| **Soft** | big cards, devices | stiffness 100, damping 16 → ~8 % overshoot, ~700 ms |
| easeOutExpo | text/camera moves | `cubic-bezier(0.16, 1, 0.3, 1)` |
| easeInOutCubic | pans, slow drift | `cubic-bezier(0.65, 0, 0.35, 1)` |
| easeOutBack | stamps, stickers | `cubic-bezier(0.34, 1.56, 0.64, 1)` |
| Anticipation | before big moves | pull back 4–6 % for 4–6 frames, then go |

### 5.2 Timing atoms (30 fps)
- Enter: 12–18 f · Exit: 8–12 f · Cursor move: 18–30 f · Click: 4 f down + 6 f up · Text per-word stagger: 3–4 f · per-letter: 1–2 f · Card stack stagger: 4–6 f.
- Hold after settle: min 12 f (0.4 s) before next change; reading time = 0.3 s per word + 0.4 s.
- Blur-out: 0 → 24–40 px over 8–10 f while opacity 1 → 0.

### 5.3 The 7 motion mechanics (recreate each exactly)
1. **Snap-and-settle (spring)** — element scales 0.85 → 1.04 → 1.00 and moves 20–40 px, no linear anywhere.
2. **Blur-in text** — opacity 0→1, blur 30→0 px, y +16→0, per word/letter stagger; accent word is delayed 6 f.
3. **Erase / scrub-out** — text deleted with a backspace caret (type-on in reverse) or masked wipe left→right with a 6 px soft edge.
4. **Smooth camera pan** — container translates 80–240 px with easeInOutCubic over 24–40 f while parallax layers move 0.5×/1.5×.
5. **Scale zoom (push-in / zoom-through)** — 1.0 → 1.06 over the whole shot (always-on) · punch zoom 1.0 → 1.25 in 8 f on a beat · zoom-through: scale 1 → 6 into a hole/screen, cut, scale 0.3 → 1 on the next scene.
6. **3D tilt** — rotateX/Y ±12–25°, perspective 1200 px, slight floating y-bob ±8 px over 90 f.
7. **Glow breathe** — bloom opacity 35 % ↔ 60 % on 60-f sine loop, hue shift ±8°.

---

## 6. TEXT ANIMATION RECIPES

| Recipe | Steps |
|---|---|
| **Blur-reveal wordmark** (Kristal) | letters start as glowing blue blur, sharpen from left, glow trails 10 f, final color flips to dark ink |
| **Type-on with caret** (search bars, Pinterest/ChatGPT) | 2–3 chars per frame bursts, caret blink 16 f, text selection highlight on key word |
| **Word-swap stack** ("to wander / ask / build is to resist") | vertical list of verbs, current one lit accent color, rest 25 % opacity, list scrolls 1 line per 6 f |
| **Slam-in headline** (Moolah) | headline enters from the side, 10 % overshoot, background color switches same frame |
| **Letter orbit** (L-O-V-E) | letters spawn as dots, float to ring, thin ellipse stroke draws around them, then rejoin |
| **Caption word-by-word** (talking head) | 2–3 words lit white, active word accent color + 105 % scale, line fades out in 6 f |
| **Countdown dispersal** (15→0) | each number multiplies/disperses into ring, one outlier turns accent color, final 0 scatters |
| **Highlight box** | 2 px stroke + 4 corner handles (vector-editor look) around the key word, then fill flips to accent |

---

## 7. UI & CURSOR RECIPES

- **Cursor:** arrow + hand variants, 36–44 px at 1080 base, white fill/black stroke or glass pointer; always eased path (a slight arc), settles 10 f before clicking.
- **Click:** cursor scale 1 → 0.88, ripple ring (accent, scale 0.6→1.8, opacity .5→0, 14 f), target button scale 0.96 → 1.
- **Chat bubbles:** typing-dots bubble (3 dots, 400 ms) → bubble springs in; incoming left grey, outgoing right accent.
- **Search bar:** capsule 120 px high, icon left, mic/camera right, glass; on click focus-glow ring.
- **Card stack:** 4–6 cards, each 8 % smaller & 12 px lower, scrub to flip through; selected card lifts + gets colored bloom.
- **Progress / success:** bar fills with ease-out, checkmark draws (stroke dash) + green glow + "Success!!" blur-in.
- **Map beat:** rounded-rect map, blue dot with pulse, route line draws (stroke dash 30 f), pin pops with spring.
- **Notification:** slides from top with spring, 2-line, app icon left, timestamp right.

---

## 8. CAMERA & CUT RULES

- Shot length by archetype: slow 4–19 s (A, B, J) · medium 3–5 s (C, F) · fast 0.5–1.8 s (D, E, K).
- Cuts land **on the beat or on the stressed word**, never between.
- Prefer **motion-matched cuts**: the exit direction of shot A = entry direction of shot B.
- Never hold a static frame > 1.2 s without drift/zoom/parallax.
- Full catalog with timings: see file **06_TRANSITIONS_CUTS_OVERLAYS.md**.

---

## 9. AUDIO RECIPE

Layers (bottom → top):
1. **Music bed** −22 LUFS-ish, modern minimal / lo-fi pulse / soft cinematic, BPM 90–125; duck −6 dB under SFX peaks and −10 dB under voice.
2. **Ambience** (optional) room tone, air, soft hum at −32 dB to glue scenes.
3. **Transition SFX** whoosh/swish on every blur-through or pan: start 3–5 f *before* the visual move.
4. **UI SFX** click, tap, pop, tick, toggle, type, send/receive, success on *exact frame*.
5. **Accent SFX** impact/sub-hit/riser at the hook, the reveal and the logo.
6. **Voiceover** (if used) −16 LUFS, de-esser, light compression, EQ high-pass 80 Hz.

Rules: max 1 riser per video · every cut has an audio event or a deliberate silence · leave 0.3 s of near-silence before the final logo hit · trim all SFX tails with 20 ms fades.
SFX naming & cue mapping → file **03_SFX_ZIP_SPEC.md**.

---

## 10. PRODUCTION PIPELINE

### Option A — AI-coded (repeatable, 1 prompt per product)
1. Fill **02_PRODUCT_PROMPT_TEMPLATE.md** (one prompt).
2. AI outputs a **scene JSON** + a **Remotion (React) project** (or HTML/GSAP) that follows this recipe.
3. You drop your **assets/** (from files 04 & 05) and **sfx/** (your zip) into the project folders.
4. Render: `npx remotion render Main out/final.mp4 --codec=h264 --crf=16` (9:16 and 16:9 as two compositions).
5. QA with §11.

### Option B — Manual (After Effects / CapCut / Premiere)
1. Create a comp 1080×1920 @ 30 fps (and 1920×1080).
2. Import assets, build each beat as a pre-comp, use the spring/easing table, add transitions from file 06, lay SFX, export.

### Project folder (both options)
```
/product-name/
  brief.md              ← filled template
  scenes.json           ← beats, text, timings, transitions
  assets/
    devices/  scenes/  icons/  emoji/  characters/  ui-kit/  overlays/  textures/  fonts/  cursors/
  sfx/                  ← your SFX zip unpacked
  music/
  vo/
  renders/
```

### scenes.json schema (minimal)
```json
{
  "meta": {"name": "", "format": "9:16", "fps": 30, "duration": 30,
           "palette": "Frost Blue", "archetype": "B", "font": "Inter Tight"},
  "scenes": [
    {"id": "hook", "start": 0.0, "end": 1.6,
     "bg": "gradient.frost",
     "elements": [{"type": "text", "text": "Still doing it by hand?", "style": "blur-reveal", "accentWord": "hand"}],
     "camera": {"move": "push-in", "scale": [1.0, 1.06]},
     "transition_out": {"type": "blur-through", "dur": 0.35},
     "sfx": [{"at": 0.0, "file": "whoosh_soft_01"}]}
  ]
}
```

---

## 11. QUALITY CHECKLIST (do before export)
- [ ] Hook has motion in frame 1 and a claim ≤ 6 words
- [ ] ≤ 6 words per text beat; 1 accent word
- [ ] Every element enters with spring, exits with blur
- [ ] No linear easing anywhere
- [ ] Something changes every 2–4 s
- [ ] Cursor eased + click feedback on every interaction
- [ ] Each cut/motion has an SFX; silence before logo
- [ ] Contrast ≥ 4.5:1 on text; safe zones respected
- [ ] Grain applied once on top, not per layer
- [ ] Loudness −14 LUFS, peak ≤ −1 dBTP
- [ ] CTA holds ≥ 1.2 s
- [ ] Exported 9:16 and 16:9 from the same JSON

---

## 12. ORIGINALITY RULES (so it becomes YOUR style)
1. Use **your product name, colors, icons and mascot**. Never use real brand logos/UI (Uber, Pinterest, Apple, Google…) in videos you publish for clients or sell — redraw as fictional "stand-ins" (the prompts in files 04/05 do this).
2. Keep the **grammar** (springs, blur, glass, cursor, camera drift) but change **palette + typography pair + hero object** per brand.
3. Pick **one signature move** and repeat it in every video (e.g. your blur-reveal + glow-breathe + a specific cursor), so viewers recognize you.
4. Apple-style emoji: Apple's emoji artwork is proprietary. Use the **original glossy 3D emoji** generated from file 04, or the viewer's system emoji for personal projects only.
5. Fonts/music/SFX: use licensed or free-for-commercial only.
