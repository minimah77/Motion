# STEP 5B: PHOTOREAL SCENE PLATES (ChatGPT)

These replace the clay-looking code plates. Final file names stay identical, so nothing else in the pack changes.

## HOW TO RUN
1. Open a new ChatGPT chat with image generation on.
2. Paste P0 and wait for "Photoreal lock ready".
3. Paste one plate prompt at a time. For each plate ask twice: "Make it wide 3:2" then "Make it tall 2:3".
4. Name the files <plate>_169 (wide) and <plate>_916 (tall), for example sky_greenhill_169.png.
5. Run: python3 tools/ingest_photoreal_plates.py <folder>. It crops wide to 16:9 (1920x1080) and tall to 9:16 (1080x1920), keeps the old code plate in assets/scenes/_code_fallback/, and locks the new files.

Composition rule for every plate: keep everything important inside the center 16:9 band (wide) or center 9:16 band (tall).

## P0: PHOTOREAL LOCK (paste first)

For this whole session you generate background plates for product motion videos. Follow this lock:
- Real photograph look, shot on a full-frame camera, natural light, natural color, fine real texture. Never clay, plastic, cotton, CGI, cartoon or painterly.
- No text, no logos, no people, no animals, no birds, no watermark, no frames, no borders.
- Soft gentle contrast, no heavy HDR, no oversaturation, no strong vignette.
- Large calm empty area in the center-middle (about 60 percent of the width, 30 percent of the height) so a UI card or search bar can sit there. Detail lives only at the edges.
- Sharp and clean, no noise, no banding, no compression artifacts.
- Each image is a single flat frame, not a collage.
Reply only: "Photoreal lock ready."

## PLATE 1: sky_blue
Clean real blue daytime sky photograph. Deeper blue at the top fading to a pale hazy blue-white near the bottom, as if the horizon is just below the frame. Only two or three tiny faint wisps of cirrus far at one edge. Center completely clear. Natural atmospheric haze, no sun disc.

## PLATE 2: sky_clouds
Real photograph of a bright blue sky with a band of soft cumulus clouds across the upper third. Clouds have real wispy fading edges, fine detail, natural soft shadows on their undersides, and thin translucent gaps showing blue through them. Lower half is clear pale hazy blue fading to near white. Sun is above frame at top-left, light is warm-white. Center-middle stays clear.

## PLATE 3: sky_clouds_dense
Real photograph looking down over a thick layer of white clouds, as seen from an airplane window, with the sea of clouds filling the lower 55 percent and a clear blue sky above with a few small cirrus wisps. Cloud tops have realistic soft texture, gentle blue-grey shadows in the valleys, bright sunlit highlights. Center-middle area is a smooth flat cloud surface, calm and uncluttered.

## PLATE 4: sky_greenhill
Real photograph of a blue sky with a few soft real cumulus clouds, and a gently rolling green grass hill across the bottom 25 percent of the frame. The grass has real texture: individual blades visible at the front, a few tiny white wildflowers, sun-lit patches and soft shadowed patches. A second farther ridge behind it is hazier and bluer-green from atmospheric distance. Warm sunlight from the top-left. Shallow depth of field, the nearest grass slightly soft. Sky and middle of the frame are empty.

## PLATE 5: sky_sunset
Real photograph of a clear sunset sky, no landscape. Deep violet-blue at the top, blending through magenta-pink and coral into warm orange and a pale golden glow near the bottom. A soft sun glow just below the center-bottom, no hard sun disc. Two or three thin, wispy, backlit high clouds catching pink light at the far edge only. Smooth natural gradient, no banding.

## PLATE 6: sky_sunset_hill
Real photograph of a sunset sky (violet at top, pink and coral in the middle, golden orange at the horizon) over two layered dark silhouette hills across the bottom 20 percent. The far hill is hazy purple-blue, the near hill is deep dark indigo with a thin warm rim light on the ridge line and tiny grass detail. A few thin backlit clouds at the top corner. Center-middle is calm open sky.

## PLATE 7: studio_light
Real photograph of an empty seamless photo studio: a smooth cool-white matte floor sweeping up into a wall with no visible horizon line. Soft large softbox light from the top-left. Very subtle gradient, brighter in the center, slightly darker at the edges. Faint natural floor texture. The floor and wall blend softly at about 58 percent of the height. Nothing else in the frame.

## PLATE 8: studio_warm
Same empty seamless photo studio, but warm cream and soft beige matte surfaces, like plaster or painted paper sweep. Soft window-like light from the left, gentle falloff to the edges, no visible horizon line, floor and wall blending at about 58 percent of the height. Subtle natural material texture. Nothing else in the frame.

## PLATE 9: studio_dark
Same empty seamless photo studio, but dark charcoal matte surfaces. A soft pool of cool blue-grey light on the floor in the center and a very soft glow on the back wall behind it, falling off to near-black at the edges. No visible horizon line, floor and wall blending at about 58 percent of the height. Subtle fine floor texture. Nothing else in the frame.

## PLATE 10: paper_cream
Top-down real photograph of a sheet of cream uncoated paper (#F4F2EC tone) lying flat on a table, filling the whole frame. Visible fine paper fibers, a very faint grain, extremely soft uneven daylight with a barely visible shadow gradient at one corner. No folds, no creases, no stains, no objects, no text.

## PLATE 11: paper_white
Top-down real photograph of a sheet of bright white uncoated paper lying flat, filling the whole frame. Fine paper fibers, a very faint grain, soft even daylight with a barely visible shadow gradient at one corner. No folds, no creases, no stains, no objects, no text.

## HILL LAYERS (alpha, for parallax)
Send these on flat magenta. The ingest script keys them to transparent and removes the magenta edge.

hill_near:
Real photograph of a rolling green grass hill with real grass texture, tiny white flowers, and sunlit and shadowed patches, filling the bottom 25 percent of the frame. Everything above the hill ridge line is flat solid pure magenta #FF00FF. Hard clean ridge edge, no magenta spill on the grass.

hill_far:
Real photograph of a distant hazy blue-green ridge of hills, soft atmospheric haze, filling the bottom 20 percent of the frame. Everything above the ridge line is flat solid pure magenta #FF00FF. Clean ridge edge, no magenta spill.

## NOT IN THIS FILE
- Clouds as separate transparent layers (clouds_soft, clouds_dense, clouds_sunset) and hill_sunset stay code-built: ChatGPT cannot make clean alpha clouds.
- Seamless paper tiles, flat color panels and contact shadows stay code-built.
