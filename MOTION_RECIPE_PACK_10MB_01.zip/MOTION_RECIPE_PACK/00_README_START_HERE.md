# YOUR MOTION VIDEO RECIPE PACK

Built from a study of your 17 reference videos (9–120 s; 9:16, 16:9, 1:1, 4:3; 11 distinct video archetypes; shots from 0.5 s to 19 s; ~ −16 dB average loudness). It recreates the **grammar** of those videos so everything you make is your own style.

| File | What it is |
|---|---|
| **01_MASTER_RECIPE.md** | THE recipe: style DNA, specs, 11 archetypes, timeline, design tokens, motion language, text/UI recipes, audio, pipeline, QA, originality rules |
| **02_PRODUCT_PROMPT_TEMPLATE.md** | ONE prompt, personalized per product (brief form + prompt + filled example) |
| **03_SFX_ZIP_SPEC.md** | Exact folder/file structure for the SFX zip you'll send + cue map |
| **04_CHATGPT_ASSET_PROMPTS_STEP1.md** | ChatGPT prompts: style lock, green-screen devices, scenes (blue sky + green hill…), icons, Apple-style emoji, mascots, cursors, textures |
| **05_CHATGPT_UI_KIT_PROMPTS_STEP2.md** | ChatGPT prompts (next step): glass cards, pills & badges, line/solid icons, data indicators, device outlines, backgrounds, overlays, glows, gradients, grain, motion mechanics, typography system |
| **06_TRANSITIONS_CUTS_OVERLAYS.md** | 24 transitions with timings, cut grammar, overlay stack, choice matrix, per-tool build notes |
| **07_MISSING_THINGS_CHECKLIST.md** | Everything else you'll need (assets, audio, tools, process, legal) + extra prompts |

## ORDER OF WORK
1. Read 01 (10 min).
2. Run ChatGPT: file 04 → then file 05 (same chat). Save assets using the folder names.
3. Gather/send your SFX zip following file 03.
4. For each product: fill the brief in 02 → paste the one prompt + file 01 into Claude → get beat sheet, scenes.json and project.
5. Add transitions from 06, run the QA list, export 9:16 + 16:9.

When your assets and SFX zip are ready, send them to me with a product brief and I'll build the video project (or any missing asset) directly.
