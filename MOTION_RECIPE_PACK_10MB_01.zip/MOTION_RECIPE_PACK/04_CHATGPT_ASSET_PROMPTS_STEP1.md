# 04 — CHATGPT PROMPTS, STEP 1: CORE ASSETS
(devices/green screens · scenes · icons · Apple-style emoji · 3D objects · mascot · cursors · textures)

## HOW TO RUN THIS
1. Open ChatGPT (image generation on). Paste **PROMPT 0 (Style Lock)** first. It sets one consistent look for the whole session.
2. Paste each numbered prompt **one at a time**. Replace `[BRACKETS]` with your brand values (colors, product category).
3. For cut-outs ask for **"transparent background PNG"**. If ChatGPT returns a background anyway, re-ask: *"Same image on a flat pure #00FF00 background, no shadows touching the green"*, then remove green in your editor (Keyer / Ultra Key / CapCut chroma).
4. Save to the folder named in each prompt. File names are what the recipe/AI will call.
5. Generate at the largest size offered (≥ 2048 px). Ask for 4 variants when it helps.
6. When done, paste **PROMPT Z (Gap Audit)** at the end of this file.

Rule for all prompts: **original designs only — no real logos, brand names, copyrighted characters or screenshots.**

---

## PROMPT 0 — STYLE LOCK (paste first, once)

```
You are my art director and asset generator for a motion-design studio. For this entire session follow this style lock:
- Look: modern, premium, minimal, soft-realistic with glassmorphism and gentle glow. Clean vector-like edges, no clutter, no text unless I ask.
- Light: soft top-left key light, subtle rim light, soft long shadows. Colors: brand primary [#2F6BFF], accent [#FF7A2E], neutrals #F1F3FA / #0B0B0B / #FFFFFF.
- Everything is ORIGINAL. Never reproduce real brands, logos, UI screenshots or copyrighted characters; invent fictional stand-ins.
- Deliver production assets: centered, generous padding, high resolution (≥2048 px), crisp edges, PNG with transparent background unless I request a scene.
- When I ask for a set, make all items match in size, perspective, line weight and lighting.
- Reply only with the image(s) and a 1-line file name suggestion (lowercase_snake_case.png).
Confirm with "Style lock ready" and wait for my first request.
```

---

## SECTION A — DEVICES & GREEN-SCREEN FRAMES  → `/assets/devices/`

The screen of each device is a flat **#00FF00** so you can replace it with any UI recording.

**A1 — Phone, front, green screen** → `device_phone_front_green.png`
```
A modern flagship smartphone, perfectly front-facing, slim bezels, dynamic-island pill at top, thin matte titanium frame, subtle side buttons. The screen is a flat uniform pure #00FF00 green with no glare, no reflection, no UI. Soft studio lighting, tiny contact shadow below on transparent background. Square-corner screen area exact and clean for keying. Original fictional design, no logos.
```
**A2 — Phone, 3/4 angle (left & right)** → `device_phone_34_left_green.png`, `device_phone_34_right_green.png`
```
Same smartphone as before, rotated 25° around the vertical axis (3/4 view, left side toward camera), slight perspective, screen flat #00FF00, soft shadow, transparent background. Also produce the mirrored right version.
```
**A3 — Phone floating, tilted isometric** → `device_phone_iso_green.png`
```
Same smartphone floating in isometric-style tilt (rotateX 55°, rotateZ -30°), screen pure #00FF00, soft shadow far below, transparent background.
```
**A4 — Laptop open, front** → `device_laptop_front_green.png`
```
A thin modern aluminum laptop, open at 110°, front view, black keyboard keys softly visible, display shows a flat pure #00FF00 screen with thin black bezel and a tiny camera dot, no logos, soft studio light, subtle floor reflection, transparent background.
```
**A5 — Laptop 3/4 on cloud/sky or desk** → `device_laptop_34_green.png`
```
Same laptop in a 3/4 perspective view from the left, screen pure #00FF00, soft shadow, transparent background.
```
**A6 — Monitor / desktop display** → `device_monitor_green.png`
```
A slim 27-inch desktop monitor on a minimal stand, front view, screen pure #00FF00, thin bezel, original design, transparent background.
```
**A7 — Tablet** → `device_tablet_green.png` · **A8 — Smartwatch** → `device_watch_green.png`
```
A modern tablet in landscape, front view, screen flat #00FF00, rounded corners, transparent background.
```
```
A modern square-ish smartwatch with rounded corners and a sports band, front view, display flat pure #00FF00, transparent background.
```
**A9 — Browser window frame (no content)** → `frame_browser_light.png`, `frame_browser_dark.png`
```
A minimal browser window frame, empty content area flat #00FF00, three traffic-light dots at top-left, a rounded address pill at top center (empty), soft shadow, transparent background. Make a light version and a dark version.
```
**A10 — Phone + laptop + tablet "device family" hero** → `device_family_green.png`
```
A group of the three devices (phone, tablet, laptop) arranged in a clean overlapping composition, all screens flat #00FF00, soft shadows, transparent background.
```
**A11 — 3D floating UI panels (blank)** → `panel_float_[1-6].png`
```
Six blank floating glass app panels (16:10, 1:1, 9:16, 4:3, 3:2, 21:9), slight perspective tilt, thin white edge, content area pure #00FF00, transparent background.
```

---

## SECTION B — SCENES / ENVIRONMENT PLATES  → `/assets/scenes/`
(16:9 3840×2160 and 9:16 2160×3840; no people, no text, calm center for UI to sit on)

**B1 — Blue sky + green hill** → `scene_sky_greenhill_169.png`, `scene_sky_greenhill_916.png`
```
A serene photoreal-stylized scene: vivid blue sky with soft volumetric clouds, a gently rolling bright-green grassy hill in the foreground with tiny white flowers, shallow depth of field, soft sunlight from the top-left, clean empty space in the center-middle for a UI search bar, no text, no people, ultra high resolution, cinematic color grade. Make it in 16:9 and in 9:16.
```
**B2 — Cloud sky (for laptops floating)** → `scene_clouds_blue.png`
```
Vast bright blue sky filled with large soft white cumulus clouds, depth and layering, center clear, golden-white highlights, no text, 16:9 and 9:16.
```
**B3 — Golden sand dunes** → `scene_dunes_gold.png`
```
Soft golden-hour desert dunes with silky ripples and a pastel peach sky, a tiny lone tree far away, peaceful and minimal, empty center, no text.
```
**B4 — Blue water waves / ocean silk** → `scene_water_blue.png`
```
Smooth glossy deep-blue rolling water surface with soft highlights, bright sky haze at horizon, minimal and calm, empty center.
```
**B5 — Pink fuzzy hill** → `scene_pinkfur_hill.png`
```
A surreal soft hill of fuzzy hot-pink fur/grass under a clear blue sky with a few small clouds, playful and clean, empty center.
```
**B6 — Golden hour mountains** → `scene_mountains_golden.png`
```
Epic warm mountain range at golden hour, soft haze, cinematic, empty sky area for headline text.
```
**B7 — Space / planet horizon (blue rim glow)** → `scene_space_horizon_blue.png`
```
Dark deep-space scene with a planet's curved horizon at the bottom emitting a bright blue atmospheric rim-light, tiny stars, no text.
```
**B8 — Moon / night** → `scene_moon_night.png`
```
A highly detailed realistic moon on a pure-black sky with subtle blue vignette, centered.
```
**B9 — Dark creator desk with red/orange glow** → `scene_desk_dark_glow.png`
```
A moody dark desk setup: slim monitor (screen flat #00FF00), mechanical keyboard, a glowing red sphere lamp on the left, deep red curtains in the background, soft rim lights, shallow depth of field, cinematic, no brand logos.
```
**B10 — Cozy voxel / low-poly room (pixel storyworld)** → `scene_voxel_room.png`
```
An isometric voxel-style cozy room with a desk, monitor (flat #00FF00 screen), warm lamp, bookshelf, plant, rug, red-brown palette, soft game-like lighting, chunky 3D pixels, no text.
```
**B11 — Cream paper board** → `scene_paper_cream.png`
```
Seamless warm cream paper texture with very subtle fibers and soft vignette, empty, 4K.
```
**B12 — Frost gradient mesh (light UI world)** → `bg_frost_gradient_[1-4].png`
```
Four ultra-soft pastel mesh gradients in cool white-lavender-blue, clean and airy, no noise, 16:9 and 9:16.
```
**B13 — Flat solid color panels** → `bg_solid_[color].png`: produce pure flat PNGs for `#FF84C6` pink, `#1F4FE0` blue, `#16D84A` green, `#FFE23A` yellow, `#D4170F` red (or just make these in your editor).

---

## SECTION C — ICONS (APP ICONS & 3D ICONS)  → `/assets/icons/`

**C1 — 3D glossy app-icon set (12 fictional apps)** → `icon3d_[name].png`
```
A set of 12 fictional rounded-square app icons in glossy soft-3D style with subtle inner glow and soft shadow: camera, music, chat bubble, notes, calendar, mail, folder, maps pin, calculator, settings gear, photos flower, wallet. No real app branding. Equal size, transparent background, arranged on a clean grid, then give each as a separate PNG.
```
**C2 — Brand mark placeholder (your logo concept)** → `logo_mark_[name].png`
```
Design a simple, memorable logo mark for a [PRODUCT CATEGORY] app named "[PRODUCT_NAME]": a bold geometric symbol with a soft glossy glass finish, in [#2F6BFF] with a lighter highlight, on transparent background; also provide a flat 1-color version and a light/dark wordmark lockup using a clean heavy grotesque typeface.
```
**C3 — Glossy 3D hero objects (topic-specific)** → `obj3d_[name].png`
```
Create 12 glossy, soft 3D rendered objects relevant to [YOUR PRODUCT TOPIC] — [LIST 12: e.g., shopping bag, coin, piggy bank, heart, paper plane, lightbulb, calendar, location pin, checkmark badge, gift box, star, chat bubble] — in a consistent playful-premium style with pastel-saturated color, soft shadows, transparent background, each as a separate PNG.
```
**C4 — Pixel-art object set** → `pixel_[name].png`
```
A set of 16 pixel-art objects at 128×128 scaled up crisp (no blur): vinyl record, film camera, heart, coin, gamepad, cap, plant, skateboard, clapperboard, cash bundle, cat, music notes, keyboard, headphones, star, speech bubble. Limited palette, 1 px dark outline, transparent background.
```
**C5 — Flat vector sticker pack (Memphis/Primary-pop)** → `sticker_[name].png`
```
A pack of 20 flat bold geometric vector illustrations/stickers in primary-pop colors (pink, cobalt blue, green, yellow, red, black): abstract shapes, stars, sparkles, coins, cocktail glass, suitcase, shopping bags, trophy, calendar, lightbulb, clouds. Thick shapes, no gradients, transparent background.
```
**C6 — Sparkles & stars** → `fx_sparkle_[1-6].png` (4-point stars, glints, twinkles, white and accent versions).

---

## SECTION D — APPLE-STYLE EMOJI (ORIGINAL)  → `/assets/emoji/`
(Apple's real emoji art is proprietary; this prompt creates an ORIGINAL set in that glossy, rounded style.)

**D1 — Emoji set, 64 pieces**
```
Create 64 ORIGINAL glossy 3D-style emoji (not copies of any platform's emoji) with soft gradients, subtle specular highlights, rounded forms, gentle drop shadow and a friendly look, each on transparent background, equal size, consistent lighting. List: grinning, smiling-with-eyes, laughing, wink, heart-eyes, star-struck, cool, thinking, melting, shocked, crying-laughing, sad, angry, sleeping, party-face, nerd, mind-blown, hug, clap, fire, sparkles, heart red/blue/pink, thumbs-up, victory, ok-hand, wave, pray, muscle, eyes, rocket, light-bulb, money-bag, coin, chart-up, trophy, gift, balloon, party-popper, coffee cup, burger, beer mugs, soccer ball, camera, music note, headphones, phone, laptop, calendar, clock, check mark, cross, warning, lock, key, map pin, globe, sun, moon, cloud, rainbow, leaf, flower. Deliver as separate PNGs plus one contact sheet.
```
**D2 — Round "place pin" emoji badges (map style)** → `pin_[name].png`
```
12 circular emoji map-pin badges: each is an original glossy emoji inside a soft round badge with a thin white border and a tiny pointer below, transparent background: coffee, burger, drinks, soccer, music, art, book, gym, shopping, park, movie, party.
```
**D3 — Emoji row component** → `emoji_row_glow.png`
```
A horizontal row of 5 overlapping round glossy emoji badges with soft colored glow behind each (orange, amber, brown, grey, yellow), transparent background.
```

---

## SECTION E — MASCOT / CHARACTERS  → `/assets/characters/`
**E1 — 3D mascot character sheet** → `mascot_[name]_sheet.png`
```
Design an ORIGINAL cute 3D mascot for [PRODUCT_NAME]: a friendly glossy robot-like character with a soft round head, simple large eyes, small body, a logo badge on the chest, material = soft matte white ceramic + brand-color accents, halftone/dotted shading texture, studio lighting. Provide a turnaround sheet (front, 3/4, side) on neutral background.
```
**E2 — Pose / expression set (transparent)** → `mascot_pose_[1-12].png`
```
Same mascot in 12 poses: idle, waving, pointing left, pointing right, thinking, surprised, happy-jump, sad, holding a sign (blank), holding a phone, thumbs up, celebrating. Transparent background, consistent proportions.
```
**E3 — Pixel mascot + pixel hero character** → `char_pixel_[a-b].png` (small orange blob mascot with a hat; a chibi pixel person with a hat/coat) — 6 poses each, transparent.
**E4 — Avatar set** → `avatar_[1-8].png` (round 3D-style avatars, varied, original, face-forward, glossy).

---

## SECTION F — CURSORS & POINTERS  → `/assets/cursors/`
```
Create a cursor/pointer set on transparent background, each 256×256: (1) classic arrow white with black outline, (2) arrow black with white outline, (3) hand pointer, (4) open hand, (5) closed grab hand, (6) text I-beam, (7) a glass-style round touch indicator (translucent white circle with soft ring), (8) click ripple ring (accent blue, transparent). Crisp vector-like edges and a soft drop shadow, consistent line weight.
```

---

## SECTION G — TEXTURES & PHOTO ELEMENTS  → `/assets/textures/`
- `tex_paper_cream.png`, `tex_watercolor_pink.png` → *"Seamless watercolor wash texture in hot pink on cream paper with visible pigment blooms, 4K."*
- `tex_halftone_dots.png`, `tex_film_grain_gray.png` (see file 05 for the full overlay pack).
- `photo_cards_[1-9].png` → *"Nine varied rounded-corner 'pin' cards (4:5) showing original stylized 3D toys, plants, fashion items and posters, soft pastel backgrounds, no brand names."* (for masonry/grid reveals)
- `illus_botanical_[1-4].png` → *"Vintage botanical illustration plates of flowers/butterfly on aged paper, no text."* (for editorial/paper archetype)

---

## PROMPT Z — GAP AUDIT (paste last)
```
Here is my master recipe and the list of assets I have so far: [PASTE FILE LIST]. Audit what is still missing to produce a [ARCHETYPE] motion video for [PRODUCT_NAME] in 9:16 and 16:9. Return a table: asset name, category, why it's needed, and a ready-to-paste image-generation prompt for each missing item in the same style lock.
```
