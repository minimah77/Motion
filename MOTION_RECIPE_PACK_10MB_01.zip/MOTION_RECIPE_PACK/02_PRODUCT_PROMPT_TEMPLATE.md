# 02 — ONE PROMPT, PERSONALIZED PER PRODUCT

How to use: (1) copy the **PROMPT** block, (2) replace everything in `[BRACKETS]`, (3) paste it into Claude (or ChatGPT) **together with 01_MASTER_RECIPE.md**, (4) attach/mention your asset folders and SFX zip.
Use the *same* prompt for every product — only the bracket values change.

---

## STEP 1 — PRODUCT BRIEF (fill this per product)

| Field | Your answer |
|---|---|
| PRODUCT_NAME | |
| ONE_LINER (≤ 12 words) | |
| WHO IT'S FOR | |
| MAIN PAIN (what hurts today) | |
| 3–5 KEY FEATURES / BEATS (verb + result) | |
| PROOF / WOW NUMBER (optional) | |
| CTA (exact words) | e.g. "Comment GUIDE", "Try it free", "Download now" |
| ARCHETYPE (A–K from recipe §2) | |
| FORMAT | 9:16 / 16:9 / 1:1 (or both) |
| LENGTH | 15 / 30 / 45 / 60 s |
| PALETTE (recipe §4.1 or your hexes) | |
| FONT PAIR | Display / UI / Accent |
| HERO OBJECT(S) | phone / laptop / mascot / logo / card / search bar |
| SCENE PLATE | sky+hill / dark studio / flat color / paper / none |
| MUSIC MOOD + BPM | |
| VOICEOVER? | none / AI voice / my voice (+ script) |
| ASSETS I ALREADY HAVE | list from folders |
| SFX I HAVE | "my zip, structure per file 03" |

---

## STEP 2 — THE PROMPT (copy everything in the box)

```
ROLE
You are a senior motion designer and creative technologist. You will design and build a professional product motion video in MY signature style, strictly following the attached MASTER RECIPE (01_MASTER_RECIPE.md). Do not copy any existing video; recreate the grammar (springs, blur transitions, glass UI, cursor storytelling, camera drift, SFX on every motion) with my product's identity.

PRODUCT
- Name: [PRODUCT_NAME]
- One-liner: [ONE_LINER]
- Audience: [WHO IT'S FOR]
- Pain: [MAIN PAIN]
- Beats (in order): [BEAT 1] / [BEAT 2] / [BEAT 3] / [BEAT 4] / [BEAT 5]
- Proof/wow: [PROOF]
- CTA (exact text): "[CTA]"

CREATIVE DIRECTION
- Archetype: [A–K and name]
- Format & length: [FORMAT], [LENGTH] s, 30 fps (60 fps for pure UI motion)
- Palette: [PALETTE or hexes]; add glow tint = accent @ 40 %
- Typography: Display [FONT], UI [FONT], Accent [FONT]; type scale from recipe §4.2
- Hero object(s): [HERO]
- Scene plate/background: [PLATE]
- Mood: [3 adjectives, e.g. calm, premium, playful]
- Music: [MOOD], [BPM] BPM

ASSETS (use only these; if one is missing, list it under MISSING ASSETS and use a clean placeholder)
- /assets/devices, /scenes, /icons, /emoji, /characters, /ui-kit, /overlays, /textures, /fonts, /cursors: [LIST WHAT YOU HAVE]
- /sfx: my SFX zip, structured as in 03_SFX_ZIP_SPEC.md (use exact file names)
- /music: [FILE or "none yet"]

WHAT TO PRODUCE (in this order)
1. BEAT SHEET — table: time-in, time-out, on-screen text (≤ 6 words, accent word marked), visual, camera move, transition-out (name from file 06), SFX file names, notes. Follow the universal timeline (hook 0–1.5 s, setup, steps, proof, CTA with ≥ 1.2 s hold).
2. scenes.json — using the schema in recipe §10, one object per beat, every element with entry/exit animation (spring names from recipe §5.1).
3. BUILD — a complete Remotion (React + TypeScript) project, or HTML+GSAP if I say so, with: reusable components (GlassCard, Pill, Badge, Cursor, SearchBar, ChatBubble, Phone/Laptop frame, Counter, ProgressBar, BlurText, TypeOn, Grain, GlowBloom, CameraRig), springs & easings as constants, an SFX timeline that triggers by file name, and compositions for 9:16 and 16:9 from the same JSON.
4. MISSING ASSETS LIST — exact file names + the one-line ChatGPT prompt for each.
5. RENDER COMMANDS and a final QA checklist result against recipe §11.

HARD RULES
- No linear easing. Everything enters with a spring (snap-and-settle) and exits with blur/scale.
- One focal point per beat; ≤ 6 words per text beat; one accent word.
- Something changes at least every 3 s; no static frame > 1.2 s (always add drift/zoom/parallax).
- Every motion/cut has an SFX or intentional silence; SFX starts 3–5 frames before the visual hit.
- Respect safe zones (recipe §1). Export loudness −14 LUFS, peak ≤ −1 dBTP.
- Use my product identity only; never use real third-party brand logos or UI.
- If any information is missing, make the most reasonable choice, state it in one line, and continue.

OUTPUT FORMAT
Return: (a) the beat sheet table, (b) scenes.json, (c) the project file tree + all code, (d) missing assets list, (e) render commands. No extra commentary.
```

---

## STEP 3 — FILLED EXAMPLE (fictional product "Orbit Notes")

```
PRODUCT
- Name: Orbit Notes
- One-liner: Notes that organize themselves while you talk.
- Audience: busy founders and students
- Pain: scattered notes, lost ideas
- Beats: Speak an idea / It becomes a clean note / Auto-tags and links / Ask your notes anything / Everything in sync
- Proof/wow: "10,000 notes searched in 0.3 s"
- CTA: "Comment ORBIT for the link"

CREATIVE DIRECTION
- Archetype: B — UI Flow Story (with a C-style sky plate for the final shot)
- Format & length: 9:16 and 16:9, 30 s, 30 fps
- Palette: Frost Blue (#2F6BFF accent) + glow tint
- Typography: Display "Archivo Black", UI "Inter Tight", Accent "Instrument Serif Italic"
- Hero objects: glass phone (green-screen device), floating note cards, a round blue "orbit" logo mark
- Scene plate: pastel frost gradient, final shot blue sky + green hill
- Mood: calm, premium, smart
- Music: minimal pulse, 100 BPM
```

---

## QUICK VARIANTS (append one line to the prompt)
- **Faster/hyper:** "Use the fast-rhythm profile: shots 0.5–1.8 s, kinetic typography, hard cuts on beat."
- **Calm/premium:** "Use the slow profile: shots 4–8 s, long blur-through transitions, large negative space."
- **Talking head:** "Insert my face-cam footage; cut away to motion graphics every 3–6 s with word-by-word captions."
- **Series consistency:** "Reuse the same signature move: blur-reveal wordmark + glow-breathe + cursor click ripple."
