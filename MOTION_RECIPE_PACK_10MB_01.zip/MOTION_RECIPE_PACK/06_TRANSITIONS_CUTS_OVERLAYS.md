# 06 — SMOOTHEST TRENDING TRANSITIONS, CUTS & OVERLAYS

All timings at 30 fps. "f" = frames. Easing names refer to recipe §5.1.
Each transition has: **look · when to use · duration · build recipe · SFX**.
Seen-in notes point to your reference videos by theme (so you can re-watch them).

---

## PART 1 — THE 24 TRANSITIONS

### Tier 1 — Signature (use in almost every video)
| # | Name | Look | Duration | Build recipe | SFX |
|---|---|---|---|---|---|
| 1 | **Blur-Through** | Scene A blurs out (0→40 px) + slight scale 1→1.05; scene B starts blurred (40→0) + scale 0.97→1. 50 % overlap. | 10–14 f | Gaussian blur keyframes on both clips + cross-dissolve on frames 4–10. *Everything in your refs uses this.* | `whoosh_soft` −4 f |
| 2 | **Spring-Swap (card replace)** | Card shrinks 1→0.9 + blur, next card springs in from 0.85→1.03→1. | 14–18 f | Settle spring on B, blur-out on A. | `pop_pill` |
| 3 | **Zoom-Through** | Camera scales into an element/screen (1→6), cut at white/dark peak, next scene scales out from 0.3→1. | 16 f + 16 f | Scale + motion-blur, optional 3-f flash at the swap point. | `zoom_through` |
| 4 | **Glass Wipe** | A frosted glass panel slides across, revealing scene B through it, edge has bright 1 px light. | 18–22 f | Panel w/ backdrop blur 40 px, easeInOutCubic left→right, mask B. | `swipe_glass` |
| 5 | **Whip Pan** | Fast horizontal slide with strong directional blur, B whips in from the opposite side. | 8–10 f | Offset ±1920, directional blur 60–100 px, ease-in on A / ease-out on B. | `whoosh_fast` |
| 6 | **Match-Move Cut** | Object exits frame-right in A; same-size object enters from left in B (same y). | 0 f cut | Align object position at the cut; add 2 f motion blur. | `whoosh_soft` short |

### Tier 2 — Dimensional / premium
| # | Name | Look | Duration | Build recipe | SFX |
|---|---|---|---|---|---|
| 7 | **3D Card Flip** | Current card rotates Y 0→90°, back card continues 90→0° | 18 f | perspective 1200, easeInOut | `card_flip` |
| 8 | **Push-Slide with Parallax** | New scene pushes old scene out; background moves 0.5×, foreground 1.5× | 20 f | easeOutExpo | `slide_card` |
| 9 | **Scale-Punch + Flash** | Zoom 1→1.25 in 6 f, 2-f white flash 60 %, settle 1.25→1.0 in new scene | 8 f | Overshoot spring | `hit_soft` |
| 10 | **Stack Fan-out** | Cards stacked 8 % smaller each; top card flies away, others advance | 20 f | stagger 4 f | `card_stack` |
| 11 | **Device Rotate-Through** | Phone rotates (rotateY 0→180°); back side becomes new scene/color | 24 f | Soft spring | `spin_whoosh` |
| 12 | **Screen-In-Screen Dive** | Camera dives into the device screen until UI fills frame | 30 f | scale 1→8 on device, UI cross-fade | `zoom_through` |
| 13 | **Hourglass Light Beam** | Vertical orange/red beam pinches at the center, text/scene swaps behind it | 16–20 f | beam overlay (file 05 ⑧), mask swap | `energy_charge` |

### Tier 3 — Type & graphic
| # | Name | Look | Duration | Build recipe | SFX |
|---|---|---|---|---|---|
| 14 | **Word-Swap Scroll** | Verb list scrolls 1 line, active word lit | 6 f/line | vertical offset + opacity | `word_swap` |
| 15 | **Letter Scatter-Gather** | Letters fly out as dots, regroup into new word | 24 f | per-letter random vector, easeOutBack | `letter_scatter` |
| 16 | **Giant Word Slam** | Oversized headline hits from side with 10 % overshoot, background color switches same frame | 10 f | spring snappy | `slam_text` |
| 17 | **Underline-Swipe Highlight** | Brush stroke swipes under the key word, then box handles appear | 12 f | mask wipe | `highlight_swipe` |
| 18 | **Typewriter Erase → Retype** | Text backspaces, new text types | 20–36 f | caret + per-char | `backspace` + `type_burst` |
| 19 | **Pixel-Mosaic Dissolve** | Frame breaks into squares of varied size, dissolving into next | 18 f | mosaic overlay (file 05 ⑦-20) + threshold | `digital_dissolve` |
| 20 | **Countdown Dispersal** | Number multiplies into a ring, next number replaces | 24 f/num | radial copy | `count_pop` |

### Tier 4 — Atmosphere
| # | Name | Look | Duration | Build recipe | SFX |
|---|---|---|---|---|---|
| 21 | **Light-Leak Dissolve** | Warm leak sweeps across the cut, cross-dissolve under it | 14–20 f | Screen blend, 70 % | `shimmer` |
| 22 | **Ink / Paint Splat Reveal** | Splat shape masks the next scene | 18 f | splat sprite as track matte | `bloom_burst` |
| 23 | **Dip-to-Solid (brand color)** | Fade to solid brand color for 3–4 f then new scene | 10 f | Use on chapter breaks | `riser_short` |
| 24 | **Glitch Cut** | RGB-split, horizontal slices, 3–5 f | 5 f | displacement + chromatic aberration | `glitch_short` |

---

## PART 2 — CUT GRAMMAR

| Cut type | Rule | Example use |
|---|---|---|
| **On-beat hard cut** | cut lands on kick/snare or the stressed word | kinetic type, voxel/story |
| **Jump cut (talking head)** | remove pauses, 1.05–1.1× punch-in every other cut | face-cam videos |
| **J-cut / L-cut** | audio of next scene starts 6–10 f earlier (J) or previous audio tails 6–10 f (L) | UI → talking head |
| **Speed ramp** | 100 % → 35 % at a beat → 100 %, with whoosh | product reveal |
| **Punch-in cut** | same shot, scale 100 → 112 % | emphasizes a claim |
| **Match cut** | similar shape/position across scenes (circle → logo, screen → screen) | A → B |
| **Smash cut to black / solid** | 1–2 f of silence then hit | before a big claim |
| **Hold-and-drift** | 4–8 s calm shot with 3–6 % push-in | premium reveals |

Rhythm profiles: **Slow** 4–8 s per shot · **Medium** 2.5–4 s · **Fast** 0.5–1.8 s · Mix: slow open → medium body → fast climax → slow CTA.

---

## PART 3 — TRANSITION CHOICE MATRIX

| Archetype | Primary | Secondary | Avoid |
|---|---|---|---|
| A Brand Reveal | Blur-Through, Letter blur | Light-Leak | Glitch |
| B UI Flow | Spring-Swap, Blur-Through | Glass Wipe, Zoom-Through | Whip |
| C Sky-Plate | Zoom-Through, Light-Leak | Blur-Through | Pixel |
| D Kinetic Type | Giant Slam, Word-Swap, Scatter-Gather | Whip Pan | Long dissolves |
| E Voxel Story | Slam, Pixel-Mosaic, Glitch | Zoom-Through | Soft fades |
| F Talking Head | Jump + Punch-in, Match-Move | Glass Wipe, Dip-to-Solid | Heavy 3D |
| G App Promo | Giant Slam + color switch, Device Rotate | Stack Fan-out | Light leaks |
| H Mascot | Spring-Swap, Scale-Punch | Hourglass Beam | Glitch |
| I Countdown | Countdown Dispersal | Dip-to-Solid | Everything else |
| J Setup POV | Screen-In-Screen Dive, Hourglass Beam | Push-Slide | Flash |
| K Icon Montage | Match-Move, Scale-Punch | Light-Leak | Slow fades |

---

## PART 4 — OVERLAYS (what to stack, in order, top → bottom)

1. **Grain/noise** (Overlay/Soft-light, 4–8 %) — always last, applied once.
2. **Vignette** (Multiply, 12–20 %) — dark/photoreal only.
3. **Light leak / flare** (Screen, 40–70 %) — only on transitions or the hero hit.
4. **Glow bloom** (Screen/Add, 35–60 %) — behind cards; "breathing".
5. **Dust/sparkles** (Screen, 20–35 %) — hero shots, drifting slowly.
6. **Camera rig** (the whole comp inside a null: push-in / pan / tilt).
7. **UI & type layers.**
8. **Background / plate.**

**Overlay prompts:** use file 05 ⑦–⑩ (light leaks, lens flares, bokeh, dust, haze, sweep, burn, vignette, scanlines, halftone, mosaic, paper, ink, grain).
**Transition-specific overlay prompt:**
```
Create transition plates for compositing, 3840×2160 and 2160×3840, each as a set of 4 frames (start, 33%, 66%, end) on PURE BLACK: (1) a white flash expanding from center; (2) a warm light leak sweeping left→right; (3) a vertical hourglass light beam pinching to the center; (4) a ring shockwave; (5) horizontal streak blur bars; (6) pixel-mosaic dissolve in orange/yellow; (7) paint/ink splat shapes (black on white, 6 variants, as masks); (8) glass-panel wipe edge with white light stroke; (9) 3 diagonal glossy sweeps; (10) sparkle burst. No text, no logos.
```

---

## PART 5 — DO / DON'T
**Do:** overlap clips 50 %, always combine blur + scale, add SFX 3–5 f before, match direction, give one hero transition per video and repeat it.
**Don't:** use more than 3 different transition types per 30 s; use linear dissolves; use stock "preset" slides that ignore easing; put a transition on every cut (let 30–40 % be hard cuts); let two heavy transitions touch.

---

## PART 6 — BUILD CHEAT-SHEET (per tool)
- **After Effects:** one precomp per scene; transition = animate Gaussian Blur + Scale + Opacity on both comps; use `ease out expo` keyframe influence 85 %/ speed 0 at the end; spring expression for overshoot; Directional Blur for whip.
- **CapCut:** keyframes on Scale/Position/Opacity; Graph → "Ease out" custom curve (fast start, long tail); Effects → Blur + "Zoom lens"; Overlay track with Screen blend for leaks.
- **Premiere:** Transform keyframes with Bezier handles; Adjustment-layer Gaussian Blur ramps; Lumetri for color; Screen blend overlays.
- **Remotion/Code:** `<TransitionSeries>` with custom presentations (blur, push, glass wipe); springs from `spring({fps, frame, config:{stiffness:170, damping:18}})`.
