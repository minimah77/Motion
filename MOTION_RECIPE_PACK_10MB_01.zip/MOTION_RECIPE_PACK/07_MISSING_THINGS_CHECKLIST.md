# 07 — EVERYTHING ELSE YOU NEED (things you didn't mention)

Tick these off before your first video. Each row says what it is, why, and where to get it (or the prompt).

## A. ASSETS
| ☐ | Item | Why | How |
|---|---|---|---|
| ☐ | **Brand kit** (logo, colors, 2–3 fonts) per product | identity | file 02 brief + file 04 prompt C2 |
| ☐ | **Real product screen recordings** (9:16 + 16:9), clean, no cursor, 60 fps | go inside the green-screen devices | record with QuickTime/OBS/Screen Studio |
| ☐ | **Fictional UI stand-ins** (search bar, chat, map, list, success) | replace real brand UIs | file 05 ①–④ |
| ☐ | **Cursor pack** | storytelling | file 04 §F |
| ☐ | **Fonts installed** (Inter Tight, Archivo Black, Instrument Serif, Space Mono, Silkscreen) | typography | Google Fonts |
| ☐ | **Caption style** | talking-head videos | file 05 ⑫ |
| ☐ | **Lower-thirds / name tags** (glass pill + avatar circle) | F-archetype | prompt: "Design 6 lower-third name tags, glass pill with a circular avatar slot and two text bars" |
| ☐ | **Comment-CTA badges** ("Comment X", "Follow", "Link in bio") | conversion endings | file 05 ② |
| ☐ | **Avatar/profile circle with ring** | social proof beats | file 04 E4 |
| ☐ | **Social cards** (post, comment box, follow button, like heart) — fictional | social beats | prompt: "Fictional social-media UI kit, original design: post card, comment input, follow button states, like burst, notification dot" |
| ☐ | **Charts/number tiles** | proof beat | file 05 ④ |
| ☐ | **Map style** (clean light map with green parks/blue water + route line + pin) | location stories | prompt: "A clean fictional city map tile, pastel colors, roads, green parks, blue river, no real labels; plus a route line and 3 map pins, transparent PNG" |
| ☐ | **Particles/confetti** | celebration beats | prompt: "Confetti burst, 4 frames on black, colorful paper pieces" |
| ☐ | **Shadows & reflections floor** | grounded devices | prompt: "Soft contact-shadow and floor-reflection PNG for objects, black-to-transparent" |
| ☐ | **Mockup scenes with hands** (hand holding phone, optional) | realism | prompt: "A hand holding a smartphone (screen #00FF00), neutral skin tone, transparent bg, 3 angles" |
| ☐ | **Hand/gesture cursors** | touch beats | file 04 §F |
| ☐ | **Social avatars of "people"** for testimonials (AI-generated, no real faces of real people) | proof | original illustrated avatars |

## B. AUDIO
| ☐ | Item | Note |
|---|---|---|
| ☐ | **SFX zip** | per file 03 |
| ☐ | **Music** (3–6 tracks, royalty-free: minimal, lo-fi pulse, cinematic swell, playful pop) | Epidemic, Artlist, YouTube Audio Library, Pixabay |
| ☐ | **Voiceover** (optional) | your voice or AI TTS; record at 48 kHz, −12 dB peaks |
| ☐ | **Audio template** (music −22 LUFS, SFX buses, ducking) | build once in your editor |

## C. TOOLS
| ☐ | Editor: **After Effects** or **CapCut** (fast) or **Premiere** | motion building |
| ☐ | **Remotion** (+ Node 18+) for code-driven repeatable videos | file 01 §10 |
| ☐ | **FFmpeg** | batch convert, loudness normalize, 9:16/16:9 exports |
| ☐ | **Figma** | design cards/UI once, export SVG/PNG |
| ☐ | **Rive/Lottie** (optional) | tiny reusable icon animations |
| ☐ | **Background remover** (remove.bg / Photoshop) | cut-outs, green-screen keying |
| ☐ | **Audio tools**: Audacity / Adobe Podcast / iZotope for VO cleanup |

## D. PROCESS
| ☐ | Scripts: 1 hook + 3–5 beats + CTA per video | file 02 |
| ☐ | Storyboard (6–10 thumbnails) before building | quick sketch / Figma |
| ☐ | Naming convention + folder template (file 01 §10) |
| ☐ | Export presets (H.264 1080p 30 / 60 fps, 9:16 + 16:9) |
| ☐ | Thumbnail/cover frame (first or best frame with big text) |
| ☐ | Subtitles file (.srt) — accessibility + reach |
| ☐ | Version log (v1, v2…) and one "final QA" pass with file 01 §11 |

## E. LEGAL / SAFETY
- Never ship real brand logos/UIs (Uber, Pinterest, Apple, Google, ChatGPT…) inside client or monetized videos without permission. Use stand-ins.
- Apple emoji art is Apple's property → use original glossy emoji from file 04 §D.
- Licenses for fonts, music, SFX, stock photos. Keep license receipts in `/product-name/licenses/`.
- Faces: use your own, licensed models, or illustrated avatars.

## F. EXTRA PROMPTS (copy/paste to ChatGPT if you need more)
**Storyboard writer**
```
Write a 30-second storyboard for [PRODUCT_NAME] in 9:16: 8 frames. For each: time range, visual, on-screen text (≤ 6 words), camera move, transition, SFX idea. Follow: hook 0–1.5 s, problem, 3 solution steps, proof, CTA.
```
**Script + captions**
```
Write a punchy 60–80 word voiceover for [PRODUCT_NAME] aimed at [AUDIENCE], with a 6-word hook, 3 benefit beats and the CTA "[CTA]". Then split it into caption chunks of 2–3 words with timing at 2.5 words/second.
```
**Copy variants**
```
Give me 10 hook lines (≤ 6 words) for a motion video about [PRODUCT_NAME], mixing question, bold claim, number, and "POV:" formats.
```

## G. WHAT I CAN DO FOR YOU WHEN YOU ASK
I can generate, in code, without ChatGPT: the **icon set (SVG)**, **glass cards**, **pills/badges**, **gradients/grain/glow textures**, **cursor and device outlines**, **UI components for Remotion**, **the full Remotion project from your filled brief**, and **a synthesized SFX starter pack** (clicks, pops, whooshes). Just say which one, plus your brand colors and product name.
