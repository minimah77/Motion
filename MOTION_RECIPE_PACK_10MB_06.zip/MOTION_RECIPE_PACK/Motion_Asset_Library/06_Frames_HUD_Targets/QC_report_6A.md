# Step 6A QC Report - Film Frames & Camera Viewfinders

Assets: 10  |  all checks passed: 10/10

Checks per asset (run on the delivered PNG files): file is in the right folder with the requested lowercase filename; mode RGBA and exactly 1080x1920; alpha contains both 0 and 255; the picture/clear zone has alpha exactly 0 in every pixel; compositing over magenta leaves the clear zone exactly magenta (so nothing is baked in, no checkerboard); fully transparent pixels carry no colour; at least 40% of the canvas is transparent (20% for the letterbox, whose 2.39:1 window is 23.5% of a 9:16 canvas by definition); viewfinder graphics keep at least 40 px from every edge.

| asset | folder | alpha min/max | transparent | opaque | semi | clear zone tested | clear zone alpha max | margin | KB | result |
|---|---|---|---|---|---|---|---|---|---|---|
| frame_35mm_film.png | 01_Film_Frames | 0/255 | 63.5% | 34.5% | 2.0% | 728x1608 px rect at (176,156) | 0 | 0 px (bleeds by design) | 720.2 | PASS |
| frame_film_negative.png | 01_Film_Frames | 0/255 | 51.2% | 46.7% | 2.1% | 768x1248 px rect at (156,336) | 0 | 0 px (bleeds by design) | 1111.6 | PASS |
| frame_vintage_camera.png | 01_Film_Frames | 0/255 | 50.3% | 47.2% | 2.5% | 772x1232 px rect at (154,344) | 0 | 0 px (bleeds by design) | 1291.1 | PASS |
| frame_cinematic_widescreen.png | 01_Film_Frames | 0/255 | 23.2% | 75.4% | 1.4% | 960x332 px rect at (60,794) | 0 | 0 px (bleeds by design) | 837.7 | PASS |
| frame_polaroid_outline.png | 01_Film_Frames | 0/255 | 71.5% | 15.8% | 12.7% | rotated 830x830 picture window, eroded 6 px (669163 px) | 0 | 0 px (bleeds by design) | 557.5 | PASS |
| viewfinder_digital_camera.png | 02_Viewfinders | 0/255 | 96.9% | 0.2% | 2.9% | 760x1100 px rect at (160,410) | 0 | 48 px | 83.3 | PASS |
| viewfinder_focus_brackets.png | 02_Viewfinders | 0/255 | 98.0% | 0.2% | 1.8% | 300x300 px rect at (390,810) | 0 | 63 px | 44.2 | PASS |
| viewfinder_recording.png | 02_Viewfinders | 0/255 | 96.4% | 0.3% | 3.3% | 760x1100 px rect at (160,410) | 0 | 49 px | 96.4 | PASS |
| viewfinder_camcorder_retro.png | 02_Viewfinders | 0/255 | 93.5% | 0.9% | 5.6% | 760x1100 px rect at (160,410) | 0 | 43 px | 195.8 | PASS |
| viewfinder_minimal_pro.png | 02_Viewfinders | 0/255 | 98.2% | 0.1% | 1.7% | 760x1100 px rect at (160,410) | 0 | 43 px | 59.3 | PASS |

## Measured details

- frame_35mm_film.png: 13 sprocket holes counted in the left band.
- frame_film_negative.png: 14 sprocket holes counted in the left band.
- frame_cinematic_widescreen.png: clear picture window at x=540: rows 735-1184 = 450 px tall (2.39:1 of 1080 = 452 px).
- frame_polaroid_outline.png: the picture window is a rotated square (3 degrees); the test uses the exact rotated polygon eroded by 6 px, so the antialiased edge is excluded.
- Frames bleed to the canvas edge on purpose (borders). Viewfinder graphics were also checked against edge clipping (margin column above).

## Visual review

Each asset was composited over a synthetic test scene and viewed at reduced size, and four areas were checked at 100% (vintage top plate, 35mm lower band, camcorder date block, digital-camera exposure row). Problems found and fixed before export: the 35mm picture window was initially filled (now punched clear); the focus-bracket labels collided with a tracked-subject bracket and the aiming ticks (moved/removed); the recording card icon overlapped its time-left text; the camcorder text touched its corner brackets; the minimal-pro text sat too close to its corner ticks; the digital-camera shot counter touched a corner bracket. The clear-zone test also caught a real defect: the digital-camera thirds plus marks sat inside the central area (alpha 205 found); they were replaced by ticks on the screen edges and the asset re-tested clean. Final composites show no overlaps or clipped text.

## Failures

none

## Limitations

- Not tested inside CapCut, Premiere, DaVinci or Instagram; checks were made on the PNG files themselves.
- All graphics and text are baked into the PNGs (fixed colours, fixed numbers and dates). Nothing is editable or animated.
- All ten are 9:16 (1080x1920) only. For 16:9 or 1:1 projects they need scaling or recomposing; no other sizes were made.
- Instagram Reels and TikTok cover parts of the bottom and right edges with their own interface. Bottom data rows of the viewfinders sit at about y=1640 to 1760 and may sit under the caption area; nudge the layer up if needed.
- The film frames and the vintage camera are original designs; no brand names or logos are used. The polaroid card is inspired by instant-photo cards and carries no logo.
- The 35mm window is taller than a real still-photo frame so that vertical video is not cropped heavily.
- Fonts used (Inter, DejaVu Sans, DejaVu Sans Mono) are already rendered into the pixels; nothing needs to be installed to use the PNGs. No missing dependencies were found.
- Existing packs (Steps 1 to 5D) are not present in this workspace, so they were neither read nor changed; this batch only adds new files under Motion_Asset_Library/06_Frames_HUD_Targets/.
