# Motion Asset Library - Step 6A: Film Frames & Camera Viewfinders

Ten transparent 1080x1920 PNG overlays for vertical video (Reels, TikTok, Shorts). Place a layer on top of your clip at 100% scale, blend mode Normal. The picture area stays transparent, so your video shows through.

## Folder layout

```
Motion_Asset_Library/06_Frames_HUD_Targets/
  01_Film_Frames/   frame_35mm_film.png, frame_film_negative.png, frame_vintage_camera.png,
                    frame_cinematic_widescreen.png, frame_polaroid_outline.png
  02_Viewfinders/   viewfinder_digital_camera.png, viewfinder_focus_brackets.png, viewfinder_recording.png,
                    viewfinder_camcorder_retro.png, viewfinder_minimal_pro.png
  contact_sheet_6A.png, manifest_6A.csv, QC_report_6A.md, README_6A.md
```

Unzip into the folder that holds your existing Motion_Asset_Library; this batch only adds new files and replaces nothing.

## Assets

| file | what it is | clear area |
|---|---|---|
| frame_35mm_film.png | Vertical 35mm strip border with real-proportion sprocket holes (transparent) and amber edge print; picture shows through the window | 728x1608 px rect at (176,156) |
| frame_film_negative.png | Orange-mask colour-negative strip with square sprockets, neighbouring exposures above and below, DX-style bars, dust and scratches on the rebate | 768x1248 px rect at (156,336) |
| frame_vintage_camera.png | Vintage rangefinder-style body: leather, stitching, shutter dial, rangefinder windows, frame counter, shutter button, strap lugs and a chrome bezel around the picture | 772x1232 px rect at (154,344) |
| frame_cinematic_widescreen.png | Elegant 2.39:1 letterbox for vertical video: near-black bars, gold hairlines, ornaments and corner ticks inside the picture | 960x332 px rect at (60,794) |
| frame_polaroid_outline.png | Tilted instant-photo card with a square transparent picture area, paper edge, soft drop shadow and tape strip; no logo | rotated 830x830 picture window, eroded 6 px (669163 px) |
| viewfinder_digital_camera.png | Compact-camera screen: mode, AF mode, 4K 30p, battery, histogram, thirds marks, exposure scale, shutter, aperture, ISO, shots left, card icon | 760x1100 px rect at (160,410) |
| viewfinder_focus_brackets.png | Main yellow AF box with two tracked-subject brackets and light screen-corner guides | 300x300 px rect at (390,810) |
| viewfinder_recording.png | REC indicator and timecode, resolution and fps, battery, card time left, stereo audio meters, ISO, shutter, aperture and white balance | 760x1100 px rect at (160,410) |
| viewfinder_camcorder_retro.png | Chunky 90s camcorder OSD: REC, tape counter, battery, zoom bar, date and time stamp, auto focus, with a slight colour fringe and glow | 760x1100 px rect at (160,410) |
| viewfinder_minimal_pro.png | Hairline corner and edge marks, thirds ticks, fps and shutter angle, clip name, ISO and white balance, lens data, timecode and a level indicator | 760x1100 px rect at (160,410) |

## Using them

- Full-frame overlays: set the project to 1080x1920 and drop the PNG on the track above your clip. Do not stretch it.
- Viewfinders: add a quick fade-in at the start. For recording, keyframe the red dot's opacity (for example on and off every half second) by masking or duplicating the layer.
- Focus brackets: scale and move the layer to land on your subject; the centre of the yellow box is empty.
- Polaroid: the card and shadow are part of the PNG; you can scale the whole layer if you want a smaller card.
- Reels/TikTok interface covers the bottom and right edge; viewfinder data rows near the bottom may need a small upward nudge.

## Notes

- All colours and text are baked in. No fonts are needed to use the files.
- No brand names or logos are used. Existing packs were not touched.
- See QC_report_6A.md for the measured checks and limitations, and manifest_6A.csv for per-asset data.
