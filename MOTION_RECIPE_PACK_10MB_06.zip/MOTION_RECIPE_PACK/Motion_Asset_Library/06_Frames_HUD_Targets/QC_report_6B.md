# Step 6B QC Report - Target Graphics & HUD Overlays

Assets: 10 (+5 standalone crops)  |  all checks passed: 15/15 files

Checks per file (run on the delivered PNG files, not on in-memory renders): file is in the right folder with the requested lowercase filename; mode RGBA; exactly 1080x1920 for the ten full-frame assets; alpha contains 0 and reaches at least 200; the clear zone has alpha exactly 0 in every pixel; compositing over magenta leaves every transparent pixel and the whole clear zone exactly magenta (so nothing is baked in, no checkerboard); fully transparent pixels carry no colour (RGB 0); no large opaque grey areas (checkerboard heuristic, under 0.5% of pixels); at least 80% of a full-frame canvas is transparent (85% for targets, 40% for standalone crops); distance from the nearest visible pixel (alpha 8 or more) to the canvas edge is at least 48 px for HUDs, 100 px for full-frame targets and 10 px for standalone crops.

| asset | folder | alpha min/max | transparent | opaque | semi | clear zone tested | clear zone alpha max | margin | KB | result |
|---|---|---|---|---|---|---|---|---|---|---|
| target_simple_crosshair.png | 03_Target_Graphics | 0/255 | 98.4% | 0.08% | 1.5% | disc r=40 px at (540,960) | 0 | 311 px | 44.9 | PASS |
| target_lock_on.png | 03_Target_Graphics | 0/255 | 95.3% | 0.33% | 4.4% | disc r=100 px at (540,960) | 0 | 143 px | 155.5 | PASS |
| target_corner_brackets.png | 03_Target_Graphics | 0/255 | 97.8% | 0.22% | 2.0% | 512x672 px rect at (284,624) | 0 | 234 px | 30.0 | PASS |
| target_radar_scan.png | 03_Target_Graphics | 0/255 | 90.3% | 0.28% | 9.5% | disc r=70 px at (540,960) | 0 | 122 px | 294.0 | PASS |
| target_tracking_box.png | 03_Target_Graphics | 0/255 | 95.5% | 0.42% | 4.1% | 400x560 px rect at (340,680) | 0 | 136 px | 69.5 | PASS |
| hud_minimal_tech.png | 04_HUDs | 0/255 | 96.9% | 0.14% | 3.0% | 840x1260 px rect at (120,330) | 0 | 49 px | 39.4 | PASS |
| hud_data_panels.png | 04_HUDs | 0/255 | 84.2% | 0.51% | 15.3% | 620x1220 px rect at (230,380) | 0 | 51 px | 107.6 | PASS |
| hud_circular_interface.png | 04_HUDs | 0/255 | 89.2% | 0.56% | 10.2% | disc r=340 px at (540,960) | 0 | 67 px | 318.7 | PASS |
| hud_technical_grid.png | 04_HUDs | 0/255 | 86.2% | 0.11% | 13.7% | 780x1320 px rect at (150,300) | 0 | 50 px | 150.8 | PASS |
| hud_sci_fi_overlay.png | 04_HUDs | 0/255 | 89.0% | 0.53% | 10.4% | 740x1240 px rect at (170,360) | 0 | 54 px | 149.2 | PASS |
| target_simple_crosshair_standalone.png | 03_Target_Graphics/standalone | 0/255 | 86.5% | 0.69% | 12.8% | disc r=40 px at (540,960) (translated to crop) | 0 | 19 px | 34.0 | PASS |
| target_lock_on_standalone.png | 03_Target_Graphics/standalone | 0/255 | 83.9% | 1.13% | 15.0% | disc r=100 px at (540,960) (translated to crop) | 0 | 19 px | 144.7 | PASS |
| target_corner_brackets_standalone.png | 03_Target_Graphics/standalone | 0/255 | 91.2% | 0.88% | 7.9% | 512x672 px rect at (284,624) (translated to crop) | 0 | 19 px | 22.9 | PASS |
| target_radar_scan_standalone.png | 03_Target_Graphics/standalone | 0/255 | 72.8% | 0.78% | 26.4% | disc r=70 px at (540,960) (translated to crop) | 0 | 19 px | 279.4 | PASS |
| target_tracking_box_standalone.png | 03_Target_Graphics/standalone | 0/255 | 87.3% | 1.19% | 11.5% | 400x560 px rect at (340,680) (translated to crop) | 0 | 19 px | 60.4 | PASS |

## Measured details

- target_simple_crosshair.png: clear zone 5025 px tested, all alpha 0; visible content spans x 312-769, y 733-1190; magenta composite exact on every transparent pixel.
- target_lock_on.png: clear zone 31417 px tested, all alpha 0; visible content spans x 143-937, y 616-1299; magenta composite exact on every transparent pixel.
- target_corner_brackets.png: clear zone 344064 px tested, all alpha 0; visible content spans x 234-846, y 575-1347; magenta composite exact on every transparent pixel.
- target_radar_scan.png: clear zone 15373 px tested, all alpha 0; visible content spans x 123-958, y 556-1365; magenta composite exact on every transparent pixel.
- target_tracking_box.png: clear zone 224000 px tested, all alpha 0; visible content spans x 182-944, y 544-1345; magenta composite exact on every transparent pixel.
- hud_minimal_tech.png: clear zone 1058400 px tested, all alpha 0; visible content spans x 50-1030, y 51-1871; magenta composite exact on every transparent pixel.
- hud_data_panels.png: clear zone 756400 px tested, all alpha 0; visible content spans x 51-1029, y 107-1806; magenta composite exact on every transparent pixel.
- hud_circular_interface.png: clear zone 363145 px tested, all alpha 0; visible content spans x 67-1013, y 412-1508; magenta composite exact on every transparent pixel.
- hud_technical_grid.png: clear zone 1029600 px tested, all alpha 0; visible content spans x 51-1029, y 52-1870; magenta composite exact on every transparent pixel.
- hud_sci_fi_overlay.png: clear zone 917600 px tested, all alpha 0; visible content spans x 54-1026, y 54-1866; magenta composite exact on every transparent pixel.
- target_simple_crosshair_standalone.png: 496x498 px, cut from the full-frame file at (292,711)-(788,1209), centred on the target.
- target_lock_on_standalone.png: 834x726 px, cut from the full-frame file at (123,597)-(957,1323), centred on the target.
- target_corner_brackets_standalone.png: 650x812 px, cut from the full-frame file at (215,554)-(865,1366), centred on the target.
- target_radar_scan_standalone.png: 874x850 px, cut from the full-frame file at (103,535)-(977,1385), centred on the target.
- target_tracking_box_standalone.png: 846x870 px, cut from the full-frame file at (117,525)-(963,1395), centred on the target.

## Visual review

Each asset was composited over a synthetic dusk scene and a bright daylight scene (a standing silhouette, sky and hills; not part of the pack) and viewed at reduced size, then at 100% in the areas listed below, and its alpha matte was reviewed on the contact sheet. A dark scene was not rendered separately; all colours are light and saturated, so they were judged safe on dark footage but not viewed there.

Problems found and fixed before export:

- Legibility on bright footage: in the first renders, white lines and text (crosshair, "LOCKED") nearly vanished on the pale sky. A tight dark outline plus a soft shadow is now built into every graphic's edge pixels; re-checked on both scenes.
- The simple crosshair read too small against the frame; it was enlarged (arms to r=184, outer arcs at r=238).
- The radar sweep wedge was heavy over a bright background; its opacity was reduced from 50% to 36%.
- hud_circular_interface: the SCAN 74% label collided with the north pointer; both labels were moved outside the pointers.
- hud_minimal_tech: the SIG label overlapped its signal bars; the bars were re-laid out to the right of the label.
- hud_technical_grid: ruler numbers were struck through by the major grid lines (offset beside the lines), the grid was a little busy (line opacity lowered), and the grid bled to the canvas edge. That last one failed the edge-margin test (0 px); the grid is now contained inside its ruler frame (margin 50 px).
- hud_sci_fi_overlay: the energy bar ran into the bottom tab, then into the corner's inner line (both fixed by moving and shortening it), and the coordinate readout touched the inner line (lifted). The glow reached within 42 px of the canvas edge and failed the margin test; the frame was moved inward (margin now 54 px).
- The edge-margin test and the clear-zone test are measured on the final files: no clear zone contains a single non-zero alpha value.

Final composites show no overlapping or clipped text. Areas inspected at 100%: crosshair, lock-on top and bottom readouts, radar sweep and labels, tracking-box tag and rulers, minimal-tech corners and footer, data-panel SYSTEM / SIGNAL / PWR / STATUS modules, circular-interface top label, technical-grid top-left ruler and dimension line, sci-fi top tab and bottom tab.

## Existing assets

The 14 files of Step 6A (10 PNGs, contact sheet, manifest, README, QC report) were compared by MD5 before and after this batch: all 14 are identical. The 6B zip contains none of them, so unzipping it next to your library cannot overwrite 6A.

## Failures

none (after the fixes listed above; both failures found during testing were corrected and the full suite was re-run)

## Limitations

- Not tested inside CapCut, Premiere, DaVinci or Instagram; checks were made on the PNG files themselves.
- All graphics and text are baked into the PNGs (fixed colours, numbers and labels). Nothing is editable or animated; the radar sweep is a still wedge, and rotating the whole radar layer also rotates its labels.
- The full-frame files are 9:16 (1080x1920) only. For 16:9 or 1:1 projects the standalone target crops can be placed directly; the HUDs need scaling or recomposing, and no other sizes were made.
- Reels and TikTok cover parts of the bottom and right edges. HUD footers sit at about y=1660 to 1860 and may sit under the caption area; nudge the layer up if needed.
- hud_minimal_tech uses hairlines (1.5 to 2.5 px) in ice white; the built-in outline keeps it readable, but on very bright footage it is the subtlest asset in the batch by design.
- Text sizes are 16 to 26 px at 1080 wide, which is small on a phone; this is typical for HUD graphics but means the readouts are decoration more than information.
- The semi-transparent outline/shadow pixels around lines (a few percent of the canvas) are intentional; they are not stray background.
- Fonts used (DejaVu Sans Mono and DejaVu Sans) are already rendered into the pixels; nothing needs to be installed to use the PNGs. No missing dependencies were found.
- Steps 1 to 5D are not present in this workspace, so they were neither read nor changed; this batch only adds new files under Motion_Asset_Library/06_Frames_HUD_Targets/.

## Package check

The final zip was extracted to a clean folder and re-tested: all 15 PNGs are byte-identical (SHA-256) to the files that were validated, and the full check suite passes 15/15 on the extracted copy. The zip contains 19 files (15 PNGs, contact sheet, manifest, README, QC report) and no Step 6A files.
