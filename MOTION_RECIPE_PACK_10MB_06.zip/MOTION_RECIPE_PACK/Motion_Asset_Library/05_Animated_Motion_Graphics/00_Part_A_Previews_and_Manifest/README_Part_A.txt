STEP 5A - ANIMATED UNDERLINES & CURVED ARROWS  (10 assets)
Motion_Asset_Library/05_Animated_Motion_Graphics/

01_Underlines/            5 clips, 1080x270, 30 fps
02_Arrows_Pointers/       5 clips, 720x720,  30 fps
00_Part_A_Previews_and_Manifest/  manifest_part_A.csv, keyframes_dark.png, keyframes_light.png, preview_*.mp4 (over dark bg), this README

Per asset:  <name>.webm (VP9 + alpha)  |  <name>.mov (ProRes 4444 + alpha)  |  <name>_final_frame.png (transparent still)
Looping clips: arrow_bounce_pointer, arrow_dashed_travel. All others draw on once and hold.

CapCut / Premiere / DaVinci: import the .mov (ProRes 4444) if your editor ignores WebM alpha.
Browsers / web editors / OBS: use the .webm. Scale clips freely; they are authored at sizes meant to be placed over text or objects, not full 9:16 frames.
Colors are baked in (one color per asset). Recolor in your editor with a fill/tint effect on the white version (underline_wavy_reveal, arrow_sketch_direction).
