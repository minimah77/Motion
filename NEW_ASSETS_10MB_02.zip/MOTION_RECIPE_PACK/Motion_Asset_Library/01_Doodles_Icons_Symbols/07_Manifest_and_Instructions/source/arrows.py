"""
Family A - Doodle Arrows. 36 distinct designs.
Each design -> dict(slug, name, treatment, color, use, build(rng) -> Art)
"""
import numpy as np
from engine import *

HAND_W = 26.0
CLEAN_W = 24.0


# --------------------------------------------------------------- arrow heads
def add_head(art, P, kind, size, rng, hand=True, w=None, spread=30, tip=None, d=None):
    w = w or (HAND_W if hand else CLEAN_W)
    T = arr(P[-1] if tip is None else tip)
    d = end_dir(P, look=size * 0.35) if d is None else d
    if hand:
        d = rot(d, rng.uniform(-4, 4))
    back = -d
    sz = lambda: size * (rng.uniform(0.9, 1.1) if hand else 1.0)

    def limb(sign, extra=1.0, bow=0.0):
        end = T + rot(back, sign * spread) * sz() * extra
        mid = (T + end) / 2
        nrm = np.array([-(end - T)[1], (end - T)[0]])
        nrm /= max(np.linalg.norm(nrm), 1e-9)
        ctrl = mid + nrm * bow * size * (1 if sign > 0 else -1)
        P2 = qbez(end, ctrl, T, 30)
        if hand:
            P2 = wobble(P2, rng, amp=1.8, fine=0.5, step=4)
        return P2

    if kind == "open":
        art.stroke(limb(+1), w, rng=rng, pressure=0.1 if hand else 0)
        art.stroke(limb(-1), w, rng=rng, pressure=0.1 if hand else 0)
    elif kind == "curl":
        art.stroke(limb(+1, 1.1, 0.16), w, rng=rng, pressure=0.1 if hand else 0)
        art.stroke(limb(-1, 1.1, 0.16), w, rng=rng, pressure=0.1 if hand else 0)
    elif kind == "harpoon":
        art.stroke(limb(+1, 1.25, 0.06), w, rng=rng, pressure=0.1 if hand else 0)
    elif kind == "chevron2":
        for off in (0.0, 0.5):
            T2 = T + back * size * off
            for s in (+1, -1):
                e = T2 + rot(back, s * spread) * size * (1.0 - 0.15 * off)
                art.stroke(np.array([e, T2]) if not hand else wobble(np.array([e, T2]), rng, 1.5, 0.4, 4),
                           w, rng=rng)
    elif kind == "filled":
        b1 = T + rot(back, +26) * size
        b2 = T + rot(back, -26) * size
        art.poly([T, b1, b2], outline=w * (0.55 if hand else 0.5), rng=rng if hand else None,
                 wob=1.6 if hand else 0)
    elif kind == "diamond":
        n = np.array([-d[1], d[0]])
        pts = [T, T + back * size * 0.5 + n * size * 0.3, T + back * size * 0.98,
               T + back * size * 0.5 - n * size * 0.3]
        art.poly(pts, outline=w * 0.5, rng=rng if hand else None, wob=1.4 if hand else 0)
    elif kind == "dot":
        art.dot(T[0], T[1], size * 0.2)
    elif kind == "ring":
        c = T - d * size * 0.18
        ring = arc(c[0], c[1], size * 0.2, 0, 360, 60)
        art.stroke(ring, w * 0.8)
    return art


HEAD_TRIM = {"filled": 0.75, "diamond": 0.7, "dot": 0.15, "ring": 0.35}


def shaft_with_head(art, P, head, size, rng, hand=True, w=None, profile=None, spread=30,
                    both=False, start_head=None):
    """Draw shaft P (stroke) and a head at its end (and optionally at its start)."""
    w = w or (HAND_W if hand else CLEAN_W)
    Q = arr(P)
    if both:
        # start head is a head at the reversed path end
        hs = start_head or head
        Qr = Q[::-1]
        tsh = HEAD_TRIM.get(hs, 0.0) * size
        Q = trim_start(Q, tsh) if tsh else Q
        add_head(art, Qr, hs, size, rng, hand, w, spread)
    tr = HEAD_TRIM.get(head, 0.0) * size
    Qs = trim_end(Q, tr) if tr else Q
    art.stroke(Qs, w, profile=profile, rng=rng, pressure=0.12 if hand else 0)
    add_head(art, arr(P) if not both else arr(P), head, size, rng, hand, w, spread)
    return art


def H(path, rng, amp=5.0, fine=1.1):
    return wobble(path, rng, amp, fine)


# --------------------------------------------------------------- designs
D = []


def design(slug, name, treatment, color, use, head):
    def deco(fn):
        D.append(dict(slug=slug, name=name, treatment=treatment, color=color, use=use, head=head, build=fn))
        return fn
    return deco


# ---- hand-drawn -----------------------------------------------------------
@design("straight_short", "Short straight pointer", "hand-drawn", "white", "Pointing at an object", "open")
def _(rng):
    a = Art()
    P = H(np.array([[250, 560], [770, 480]]), rng, 4, 1.0)
    return shaft_with_head(a, P, "open", 135, rng)


@design("straight_long", "Long directional sweep", "hand-drawn", "pink", "Directing the viewer's eye across the frame", "open")
def _(rng):
    a = Art()
    P = H(bez([100, 620], [380, 585], [650, 500], [900, 430]), rng, 5, 1.0)
    return shaft_with_head(a, P, "open", 150, rng, spread=28)


@design("diagonal_down", "Diagonal down pointer", "hand-drawn", "yellow", "Pointing at a lower element or button", "filled")
def _(rng):
    a = Art()
    P = H(bez([190, 180], [330, 340], [560, 590], [790, 810]), rng, 5, 1.0)
    return shaft_with_head(a, P, "filled", 150, rng)


@design("curved_gentle", "Gentle curve", "hand-drawn", "electric_blue", "Guiding the eye to a subject", "open")
def _(rng):
    a = Art()
    P = H(bez([140, 720], [330, 280], [650, 250], [860, 510]), rng, 5, 1.0)
    return shaft_with_head(a, P, "open", 140, rng)


@design("curved_c", "Big C curve", "hand-drawn", "violet", "Circling back to emphasise something", "curl")
def _(rng):
    a = Art()
    P = H(arc(520, 500, 330, -50, -315, 300, r1=300), rng, 6, 1.1)
    return shaft_with_head(a, P, "curl", 150, rng, spread=34)


@design("curved_s", "S-curve rise", "hand-drawn", "white", "Showing progress or a path upward", "chevron2")
def _(rng):
    a = Art()
    P = H(bez([200, 790], [190, 430], [800, 590], [790, 210]), rng, 5, 1.0)
    return shaft_with_head(a, P, "chevron2", 120, rng, spread=32)


@design("double_straight", "Double-headed straight", "hand-drawn", "pink", "Comparing or connecting two things", "open")
def _(rng):
    a = Art()
    P = H(np.array([[170, 580], [830, 450]]), rng, 4, 1.0)
    return shaft_with_head(a, P, "open", 125, rng, both=True)


@design("double_curved", "Double-headed arch", "hand-drawn", "electric_blue", "Before/after or back-and-forth", "curl")
def _(rng):
    a = Art()
    P = H(bez([160, 640], [320, 250], [680, 250], [840, 640]), rng, 5, 1.0)
    return shaft_with_head(a, P, "curl", 130, rng, spread=34, both=True)


@design("loop_single", "Loop-the-loop", "hand-drawn", "white", "Adding playful personality / transition", "open")
def _(rng):
    a = Art()
    pts = [(110, 730), (300, 660), (440, 590), (560, 620), (640, 520), (590, 390), (470, 360),
           (400, 440), (440, 560), (590, 590), (730, 500), (870, 340)]
    P = H(spline(pts, 28), rng, 3, 0.9)
    return shaft_with_head(a, P, "open", 135, rng)


@design("circular", "Circle-around arrow", "hand-drawn", "pink", "Circling a face or key object", "open")
def _(rng):
    a = Art()
    P = H(arc(500, 500, 310, -125, 190, 320, r1=285), rng, 6, 1.1)
    return shaft_with_head(a, P, "open", 135, rng)


@design("refresh_pair", "Refresh pair", "hand-drawn", "violet", "Repeat / replay / swap reaction", "filled")
def _(rng):
    a = Art()
    for (a0, a1) in ((195, 335), (15, 155)):
        P = H(arc(500, 500, 290, a0, a1, 160), rng, 3, 0.8)
        shaft_with_head(a, P, "filled", 125, rng)
    return a


@design("bent_l", "Down-then-right bend", "hand-drawn", "yellow", "Leading the eye around a corner", "open")
def _(rng):
    a = Art()
    P = H(rounded_poly([(200, 220), (200, 720), (800, 720)], 70), rng, 4, 1.0)
    return shaft_with_head(a, P, "open", 130, rng)


@design("bent_u", "U-turn arrow", "hand-drawn", "electric_blue", "Pointing back down at a lower element", "curl")
def _(rng):
    a = Art()
    P = H(rounded_poly([(260, 780), (260, 300), (740, 300), (740, 740)], 130), rng, 4, 1.0)
    return shaft_with_head(a, P, "curl", 135, rng, spread=34)


@design("bent_stairs", "Staircase arrow", "hand-drawn", "white", "Showing growth or step-by-step", "open")
def _(rng):
    a = Art()
    P = H(rounded_poly([(140, 790), (390, 790), (390, 540), (640, 540), (640, 290), (880, 290)], 34), rng, 3, 0.8)
    return shaft_with_head(a, P, "open", 125, rng)


@design("wavy", "Wavy flow arrow", "hand-drawn", "pink", "Flow, motion, playful emphasis", "open")
def _(rng):
    a = Art()
    P = H(wave((110, 520), (880, 520), 62, 3, 500, env=lambda t: np.clip((0.76 - t) / 0.1, 0, 1)), rng, 2, 0.8)
    return shaft_with_head(a, P, "open", 130, rng)


@design("wavy_diagonal", "Diagonal wave arrow", "hand-drawn", "electric_blue", "Directing the eye diagonally up", "filled")
def _(rng):
    a = Art()
    P = H(wave((130, 790), (860, 240), 50, 4, 500, env=lambda t: np.clip((0.76 - t) / 0.1, 0, 1)), rng, 2, 0.8)
    return shaft_with_head(a, P, "filled", 140, rng)


@design("sketch_double", "Double-stroke sketch", "hand-drawn", "white", "Sketchy, energetic emphasis", "open")
def _(rng):
    a = Art()
    base = bez([140, 700], [380, 560], [600, 470], [850, 330])
    for k in range(2):
        P = wobble(base + np.array([k * 34, k * 30 - 15]), rng, 9, 1.6)
        a.stroke(P, 13, rng=rng, pressure=0.2)
        add_head(a, P, "open", 135 - 10 * k, rng, True, 13)
    return a


@design("trail_speed", "Speed-trail arrow", "hand-drawn", "violet", "Whoosh / transition / movement", "filled")
def _(rng):
    a = Art()
    P = H(np.array([[340, 500], [850, 500]]), rng, 2, 0.8)
    shaft_with_head(a, P, "filled", 140, rng)
    for y, x0, x1 in ((395, 150, 330), (605, 200, 360), (500, 100, 250)):
        T = wobble(np.array([[x0, y], [x1, y + rng.uniform(-6, 6)]]), rng, 2, 0.6)
        if y == 500:
            continue
        a.stroke(T, 22, profile="taper_start", rng=rng)
    a.stroke(wobble(np.array([[110, 500], [260, 500]]), rng, 2, 0.5), 20, profile="taper_start", rng=rng)
    return a


@design("trail_swoosh", "Brush swoosh arrow", "hand-drawn", "pink", "Transition swoosh / adding personality", "filled")
def _(rng):
    a = Art()
    P = H(bez([110, 790], [260, 470], [560, 290], [790, 310]), rng, 3, 0.8)
    shaft_with_head(a, P, "filled", 160, rng, w=44, profile="taper_start")
    return a


@design("short_hook", "Hooked pointer", "hand-drawn", "yellow", "Highlighting a face from the side", "curl")
def _(rng):
    a = Art()
    P = H(bez([320, 220], [650, 170], [720, 520], [560, 750]), rng, 4, 1.0)
    return shaft_with_head(a, P, "curl", 135, rng, spread=34)


@design("dot_tail", "Dot-tail callout", "hand-drawn", "electric_blue", "Connecting a spot to a callout", "harpoon")
def _(rng):
    a = Art()
    P = H(bez([190, 740], [360, 560], [600, 420], [830, 280]), rng, 4, 1.0)
    a.dot(P[0][0], P[0][1], 34)
    return shaft_with_head(a, trim_start(P, 20), "harpoon", 140, rng)


@design("dashed", "Dashed trajectory", "hand-drawn", "white", "Showing a path or trajectory", "open")
def _(rng):
    a = Art()
    P = bez([120, 640], [330, 450], [600, 420], [850, 520])
    P = wobble(P, rng, 4, 0.8)
    for seg in dashes(trim_end(P, 20), 70, 46, rng, 0.25):
        a.stroke(seg, HAND_W, rng=rng, pressure=0.1)
    add_head(a, P, "open", 135, rng, True)
    return a


@design("brush_tapered", "Brush stroke arrow", "hand-drawn", "pink", "Quick marker emphasis", "open")
def _(rng):
    a = Art()
    P = H(bez([110, 540], [330, 480], [560, 560], [790, 500]), rng, 5, 1.0)
    shaft_with_head(a, P, "open", 160, rng, w=34, profile="taper_start", spread=30)
    return a


@design("spiral", "Spiral-in arrow", "hand-drawn", "violet", "Pulling focus to the centre", "open")
def _(rng):
    a = Art()
    P = H(arc(500, 500, 360, 200, 200 + 520, 520, r1=130), rng, 3, 0.8)
    return shaft_with_head(a, P, "open", 105, rng, spread=34)


@design("up_flick", "Up-right flick", "hand-drawn", "electric_blue", "Positive reaction / growth", "filled")
def _(rng):
    a = Art()
    P = H(bez([190, 780], [330, 590], [540, 400], [810, 190]), rng, 4, 1.0)
    return shaft_with_head(a, P, "filled", 150, rng)


@design("down_pointer", "Straight down pointer", "hand-drawn", "pink", "Pointing down at a subtitle or button", "chevron2")
def _(rng):
    a = Art()
    P = H(np.array([[500, 130], [520, 860]]), rng, 5, 1.0)
    return shaft_with_head(a, P, "chevron2", 130, rng, spread=34)


@design("double_loop", "Double loop path", "hand-drawn", "yellow", "Playful path / personality", "open")
def _(rng):
    a = Art()
    pts = [(110, 680), (210, 560), (340, 520), (410, 600), (350, 700), (260, 640), (330, 520),
           (520, 440), (640, 500), (610, 600), (520, 560), (580, 440), (720, 340), (880, 300)]
    P = H(spline(pts, 28), rng, 2, 0.7)
    return shaft_with_head(a, P, "open", 125, rng)


@design("corner_curl", "Quarter-turn curl", "hand-drawn", "white", "Swinging the eye around a corner", "curl")
def _(rng):
    a = Art()
    P = H(arc(220, 760, 560, -90, 0, 160) * 1.0 + np.array([0, 0]), rng, 4, 1.0)
    P = P - np.array([0, 0])
    return shaft_with_head(a, P, "curl", 135, rng, spread=34)


# ---- clean graphic --------------------------------------------------------
def C():
    return np.random.default_rng(0)


@design("clean_straight", "Clean solid arrow", "clean-graphic", "white", "Pointing at data or UI element", "filled")
def _(rng):
    a = Art()
    return shaft_with_head(a, np.array([[160, 500], [840, 500]]), "filled", 120, rng, hand=False)


@design("clean_long_open", "Clean long open arrow", "clean-graphic", "electric_blue", "Directional info callout", "open")
def _(rng):
    a = Art()
    return shaft_with_head(a, np.array([[100, 540], [900, 540]]), "open", 130, rng, hand=False, spread=36)


@design("clean_curved", "Clean curved arrow", "clean-graphic", "pink", "Linking two elements on screen", "filled")
def _(rng):
    a = Art()
    P = bez([150, 720], [230, 300], [650, 200], [860, 420], 300)
    return shaft_with_head(a, P, "filled", 120, rng, hand=False)


@design("clean_double_diamond", "Clean double-diamond", "clean-graphic", "violet", "Measuring or connecting two points", "diamond")
def _(rng):
    a = Art()
    return shaft_with_head(a, np.array([[150, 500], [850, 500]]), "diamond", 110, rng, hand=False, both=True)


@design("clean_elbow_dot", "Elbow connector with dot", "clean-graphic", "yellow", "Callout line from a point of interest", "open")
def _(rng):
    a = Art()
    P = rounded_poly([(180, 760), (180, 300), (800, 300)], 60)
    a.dot(180, 760, 30)
    return shaft_with_head(a, trim_start(P, 18), "open", 120, rng, hand=False, spread=36)


@design("clean_circular", "Clean circular arrow", "clean-graphic", "white", "Replay / loop indicator", "filled")
def _(rng):
    a = Art()
    P = arc(500, 500, 320, -60, -340, 300)
    return shaft_with_head(a, P, "filled", 120, rng, hand=False)


@design("clean_dashed", "Clean dashed arrow", "clean-graphic", "pink", "Indicating a route or hidden path", "open")
def _(rng):
    a = Art()
    P = bez([120, 700], [320, 300], [620, 300], [860, 700], 300)
    for seg in dashes(trim_end(P, 20), 64, 44):
        a.stroke(seg, CLEAN_W)
    add_head(a, P, "open", 130, rng, hand=False, spread=34)
    return a


@design("clean_chevrons", "Triple chevron", "clean-graphic", "yellow", "Fast-forward / swipe / next", "none")
def _(rng):
    a = Art()
    for i, x in enumerate((230, 440, 650)):
        pts = np.array([[x, 330], [x + 150, 500], [x, 670]])
        a.stroke(resample(pts, 3), CLEAN_W + 4)
    return a
