import os, sys, csv, shutil, time
sys.path.insert(0, os.path.dirname(__file__))
from multiprocessing import Pool
import icons3d
from threed import render, THEMES

PACK = "/home/claude/Motion_Asset_Library/01_Doodles_Icons_Symbols"
MASTER_DIR = f"{PACK}/03_3D_Icons"
VAR_DIR = f"{PACK}/05_Color_Variants/icons"
PART = "/home/claude/motion_build/manifest_parts/icons.csv"
COLOR_ORDER = ["white", "black", "chrome", "electric_blue", "violet", "pink", "yellow"]


def work(args):
    i, only_master, outdir = args
    d = icons3d.ICONS[i - 1]
    parts = d["build"]()
    nn = f"{i:02d}"
    made = []
    for color in ([d["color"]] if only_master else COLOR_ORDER):
        img = render(parts, color)
        fn = f"icon_{d['slug']}_{color}_{nn}.png"
        is_master = color == d["color"]
        if outdir:
            path = f"{outdir}/{fn}"
            rel = fn
        elif is_master:
            path, rel = f"{MASTER_DIR}/{fn}", f"03_3D_Icons/{fn}"
        else:
            os.makedirs(f"{VAR_DIR}/{color}", exist_ok=True)
            path, rel = f"{VAR_DIR}/{color}/{fn}", f"05_Color_Variants/icons/{color}/{fn}"
        img.save(path, optimize=True)
        made.append((i, color, fn, rel, is_master))
    return made


if __name__ == "__main__":
    qa = "--qa" in sys.argv
    t = time.time()
    idx = list(range(1, len(icons3d.ICONS) + 1))
    if qa:
        out = "/home/claude/motion_build/_qa_icons"
        os.makedirs(out, exist_ok=True)
        with Pool(2) as p:
            p.map(work, [(i, True, out) for i in idx])
        print("qa done", round(time.time() - t))
        sys.exit()
    for d in (MASTER_DIR, VAR_DIR):
        if os.path.isdir(d):
            shutil.rmtree(d)
        os.makedirs(d)
    with Pool(2) as p:
        results = p.map(work, [(i, False, None) for i in idx])
    rows = []
    for made in results:
        for i, color, fn, rel, is_master in made:
            d = icons3d.ICONS[i - 1]
            rows.append(dict(
                asset_id=f"C{i:02d}", filename=fn, relative_path=rel, family="3D Icons", category="icon",
                style="3d-glossy", primary_color=color, intended_use=d["use"], arrowhead="",
                design_name=d["name"], variant_of="" if is_master else f"C{i:02d} master ({d['color']})",
                width_px=1024, height_px=1024, format="PNG RGBA"))
    rows.sort(key=lambda r: (r["asset_id"], r["variant_of"] != ""))
    with open(PART, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(len(idx), "icons,", len(rows), "files,", round(time.time() - t), "s")
